<?php

namespace PW\PoudlardBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PWPoudlardBundle extends Bundle
{
}
