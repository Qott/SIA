<?php

namespace PW\PoudlardBundle\Controller;

use PW\PoudlardBundle\Entity\personnages;
use PW\PoudlardBundle\Entity\utilisateurs;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Bundle\FrameworkBundle\Console\Application;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\RepeatedType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Console\Output\NullOutput;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Console\Input\ArrayInput;

class DefaultController extends Controller {

  public function createDatabase(){
    $kernel = $this->get('kernel');
    $application = new Application($kernel);
    $application->setAutoExit(false);
    $schema = $this->getDoctrine()->getConnection()->getSchemaManager();
    $output = new NullOutput();

    if(!($schema->tablesExist(array('utilisateurs'))) ||
      !($schema->tablesExist(array('personnages')))){
        $clear = new ArrayInput(array(
         'command' => 'doctrine:schema:drop',
         '--force' => true,
         '--full-database' => true,
        ));
        $application->run($clear, $output);

        $tables = new ArrayInput(array(
          'command' => 'doctrine:schema:update',
          '--force' => true,
        ));
        $application->run($tables, $output);

        $man = $this->getDoctrine()->getManager();
        $rep = $man->getRepository('PWPoudlardBundle:personnages');
        $harry = new personnages('Harry Potter', 1, "image/personnages/harry_potter.jpg",0);
        $cedric = new personnages("Cédric Diggory", 2, "image/personnages/cedric_diggory.jpg",0);
        $drago = new personnages("Drago Malefoy", 3, "image/personnages/drago_malefoy.jpg",0);
        $luna = new personnages("Luna Lovegood", 4, "image/personnages/luna_lovegood.jpg",0);
        $man->persist($harry);
        $man->persist($cedric);
        $man->persist($drago);
        $man->persist($luna);
        $man->flush();

    }
  }

  public function majNiveau(int $niveau, int $score){
    if($niveau == 1 && $score >= 20){
      return 2;
    }else if($niveau == 2 && $score >= 50){
      return 3;
    }else if($niveau == 3 && $score >= 80){
      return 4;
    }else if($niveau == 4 && $score >= 120){
      return 5;
    }else if($niveau == 5 && $score >= 200){
      return 6;
    }else if($niveau == 6 && $score >= 250){
      return 7;
    }else{
      return $niveau;
    }
  }

//num des maisons : 1 Gryffondor, 2 Poufsouffle, 3 Serpentard, 4 Serdaigle
  public function connexionAction(Request $request) {
    //on crée la base de données avec des personnages par défaut
    $this->createDatabase();

    if ($this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED')) {
      return $this->redirectToRoute('pw_poudlard_choixPerso');
    }
    $authenticationUtils = $this->get('security.authentication_utils');



    //on crée le formulaire d'inscription
    $user = new utilisateurs();
    // $formBuilderI = $this->get('form.factory')->createBuilder(FormType::class, $user);
    $formBuilderI = $this->createFormBuilder($user);
    $formBuilderI
      ->add('username', TextType::class, array(
        'label'=> 'Pseudo'
        ))
      ->add('mail', EmailType::class, array(
        'label'=> 'Email'
        ))
      ->add('password', RepeatedType::class, array(
        'type'=> PasswordType::class,
        'invalid_message'=> 'Les mots de passe ne correspondent pas',
        'required'=>true,
        'first_options'  => array('label' => 'Mot de Passe'),
        'second_options' => array('label' => 'Confirmer Mot de passe')
        ))
      ->add("S'inscrire", SubmitType::class)

    ;
    $formI = $formBuilderI->getForm();

    //on entre le nouvel utilisateur dans la base de données
    ///!\ faire un constructeur dans user pour mettre qques param par dft
    if($request->isMethod('POST')){
      $formI->handleRequest($request);
      if($formI->isValid()){
        $em = $this->getDoctrine()->getManager();
        $repP = $em->getRepository('PWPoudlardBundle:personnages');
        $em->persist($user);
        $em->flush();

        $tab = array();
        $hp = $repP->findOneBy(array('id'=>1));
        $cd = $repP->findOneBy(array('id'=>2));
        $ll = $repP->findOneBy(array('id'=>4));
        $dm = $repP->findOneBy(array('id'=>3));

        $potter = new personnages($hp->getNom(), $hp->getMaison(), $hp->getImage(), $user->getId());
        $diggory = new personnages($cd->getNom(), $cd->getMaison(), $cd->getImage(), $user->getId());
        $lovegood = new personnages($ll->getNom(), $ll->getMaison(), $ll->getImage(), $user->getId());
        $malefoy = new personnages($dm->getNom(), $dm->getMaison(), $dm->getImage(), $user->getId());

        $em->persist($potter);
        $em->persist($diggory);
        $em->persist($lovegood);
        $em->persist($malefoy);
        $em->flush();

        $request->getSession()->getFlashBag()->add('notice', 'Annonce bien enregistrée.');
        return $this->redirectToRoute('pw_poudlard_connexion');
      }
    }

    $retour = $this
      ->get('templating')
      ->render('PWPoudlardBundle:Default:connexion.html.twig', array(
          'formI'=> $formI->createView(),
          'last_username' => $authenticationUtils->getLastUsername(),
          'error'         => $authenticationUtils->getLastAuthenticationError()
      ));
    return new Response($retour);
  }

  public function accueilAction() {
    $em = $this->getDoctrine()->getManager();
    $repU = $em->getRepository('PWPoudlardBundle:utilisateurs');
    $repP = $em->getRepository('PWPoudlardBundle:personnages');
    $nom = $this->get('security.token_storage')->getToken()->getUser()->getUsername();
    $user = $repU->findOneBy(array('username'=>$nom));
    if(isset($_POST['perso'])){
      $choix = $repP->findOneBy(array('id'=>$_POST['perso']));
      $user->setActuel($choix->getId());
      $em->flush();
    }

    $actuel = $repP->findOneBy(array('id'=>$user->getActuel()));

    $cours =false;
    if(isset($_POST['cours'])){
      $actuel->setScore(10);
      $actuel->setNiveau($this->majNiveau($actuel->getNiveau(), $actuel->getScore()));
      $em->flush();
      $cours = true;
    }

    $bu = false;
    $time = true;
    if(isset($_POST['bu'])){
      if($actuel->getBibli() == 1){
        $actuel->setDate(new \DateTime());
        $actuel->setBibli(2);
        $actuel->setScore(7);
        $actuel->setNiveau($this->majNiveau($actuel->getNiveau(), $actuel->getScore()));
        $em->flush();
        $time =true;
      }else{
        $now = new \DateTime();
        $act = $actuel->getDate();
        $diff = $act->diff($now);
        if($diff->i >=5){
          $actuel->setScore(7);
          $actuel->setNiveau($this->majNiveau($actuel->getNiveau(), $actuel->getScore()));
          $actuel->setDate(new \DateTime());
          $time =true;
        }else{
          $time =false;
        }
      }
      $em->flush();
      $bu = true;
    }

    $quid = 0;
    if(isset($_POST['quid'])){
      if($_POST['quid'] == 'gain'){
        $actuel->setScore(5);
        $quid = 1;
      }
      if($_POST['quid'] == 'perte'){
        $actuel->setScore(3);
        $quid = 2;
      }
      if($_POST['quid'] == 'niv'){
        $quid = 3;
      }
      $actuel->setNiveau($this->majNiveau($actuel->getNiveau(), $actuel->getScore()));
      $em->flush();
    }


    return $this->render('PWPoudlardBundle:Default:accueil.html.twig', array(
      'niveau'=> $actuel->getNiveau(),
      'score'=> $actuel->getScore(),
      'argent'=> $actuel->getArgent(),
      'actuel'=> $actuel,
      'objets'=> $actuel->getObj(),
      'articles'=> $actuel->getArt(),
      'bu'=>$bu,
      'quid'=>$quid,
      'cours'=>$cours,
      'time'=>$time,
    ));
  }

  public function boutiqueAction() {
    $em = $this->getDoctrine()->getManager();
    $repU = $em->getRepository('PWPoudlardBundle:utilisateurs');
    $repP = $em->getRepository('PWPoudlardBundle:personnages');
    $nom = $this->get('security.token_storage')->getToken()->getUser()->getUsername();
    $user = $repU->findOneBy(array('username'=>$nom));
    $actuel = $repP->findOneBy(array('id'=>$user->getActuel()));

    $articles =$actuel->getArt();
    $niv = $actuel->getNiveau();
    if(isset($_POST['boutique'])){
      if($_POST['prix']<= $actuel->getArgent()){
        if(isset($_POST['potions'])){
          if($articles[0] != $niv){
            $articles[0]=$niv;
          }
        }
        if(isset($_POST['defense'])){
          if($articles[1] != $niv){
            $articles[1]=$niv;
          }
        }
        if(isset($_POST['divination'])){
          if($articles[2] != $niv){
            $articles[2]=$niv;
          }
        }
        if(isset($_POST['magique'])){
          if($articles[3] != $niv){
            $articles[3]=$niv;
          }
        }
        if(isset($_POST['botanique'])){
          if($articles[4] != $niv){
            $articles[4]=$niv;
          }
        }
        if(isset($_POST['sort'])){
          if($articles[5] != $niv){
            $articles[5]=$niv;
          }
        }
        if(isset($_POST['nimbus'])){
          if($articles[6] != $niv){
            $articles[6]++;
          }
        }
        if(isset($_POST['feu'])){
          if($articles[7] != $niv){
            $articles[7]++;
          }
        }
        if(isset($_POST['dragon'])){
          if($articles[8] != $niv){
            $articles[8]++;
          }
        }
        if(isset($_POST['phoenix'])){
          if($articles[9] != $niv){
            $articles[9]++;
          }
        }
        $prix = intval($_POST['prix']);
        $actuel->setArgent(-$prix);
        $actuel->setArt($articles);
        $em->flush();
        return $this->redirectToRoute('pw_poudlard_accueil');
      }else{
        return $this->redirectToRoute('pw_poudlard_boutique');
      }
    }


    return $this->render('PWPoudlardBundle:Default:boutique.html.twig', array(
      'niveau' => $actuel->getNiveau(),
      'score' => $actuel->getScore(),
      'argent'=> $actuel->getArgent(),
      'actuel'=> $actuel,
      'objets'=> $actuel->getObj(),
      'articles'=> $actuel->getArt(),
    ));
  }

  public function serviceAction() {
    $em = $this->getDoctrine()->getManager();
    $repU = $em->getRepository('PWPoudlardBundle:utilisateurs');
    $repP = $em->getRepository('PWPoudlardBundle:personnages');
    $nom = $this->get('security.token_storage')->getToken()->getUser()->getUsername();
    $user = $repU->findOneBy(array('username'=>$nom));
    $actuel = $repP->findOneBy(array('id'=>$user->getActuel()));

    $objets = $actuel->getObj();
    $visite =false;
    if(isset($_POST['visite'])){
      $actuel->setArgent(1);
      $visite = true;
      $em->flush();
    }

    $crockdur = false;
    if(isset($_POST['crockdur'])){
      if($objets[0] >=1){
        $actuel->setArgent(3);
        $objets[0] --;
        $crockdur = true;
        $em->flush();
      }
    }

    $dragon =false;
    if(isset($_POST['dragon'])){
      if($objets[1] >=1){
        $actuel->setArgent(5);
        $objets[1] --;
        $dragon = true;
        $em->flush();
      }
    }

    $hippogriffe = false;
    if(isset($_POST['hippogriffe'])){
      if($objets[2] >=1){
        $actuel->setArgent(10);
        $objets[2] --;
        $hippogriffe = true;
        $em->flush();
      }
    }

    $graup = false;
    if(isset($_POST['graup'])){
      if($objets[3] >=1){
        $actuel->setArgent(15);
        $objets[3] --;
        $graup = true;
        $em->flush();
      }
    }

    $actuel->setObj($objets);
    $em->flush();


    return $this->render('PWPoudlardBundle:Default:service.html.twig', array(
      'niveau' => $actuel->getNiveau(),
      'score' => $actuel->getScore(),
      'argent'=> $actuel->getArgent(),
      'actuel'=> $actuel,
      'objets'=> $actuel->getObj(),
      'articles'=> $actuel->getArt(),
      'visite'=>$visite,
      'crockdur'=>$crockdur,
      'dragon'=>$dragon,
      'hippogriffe'=>$hippogriffe,
      'graup'=>$graup,
    ));
  }

  public function promenerAction() {
    $em = $this->getDoctrine()->getManager();
    $repU = $em->getRepository('PWPoudlardBundle:utilisateurs');
    $repP = $em->getRepository('PWPoudlardBundle:personnages');
    $nom = $this->get('security.token_storage')->getToken()->getUser()->getUsername();
    $user = $repU->findOneBy(array('username'=>$nom));
    $actuel = $repP->findOneBy(array('id'=>$user->getActuel()));

    $objets = $actuel->getObj();
    if(isset($_POST['ecole_name'])){
      $objets[intval($_POST['ecole_name'])] += 1;
    }
    if(isset($_POST['lard_name'])){
      $objets[intval($_POST['lard_name'])] += 1;
      if($actuel->getNiveau() < 3 && $actuel->getScore()!=0){
        $actuel->setScore(-2);
      }
    }
    if(isset($_POST['foret_name'])){
      $objets[intval($_POST['foret_name'])] += 1;
      if($actuel->getScore()!=0){
        $actuel->setScore(-5);
      }
    }
    $actuel->setObj($objets);
    $em->flush();

    return $this->render('PWPoudlardBundle:Default:promener.html.twig', array(
      'niveau' => $actuel->getNiveau(),
      'score' => $actuel->getScore(),
      'argent'=> $actuel->getArgent(),
      'actuel'=> $actuel,
      'objets'=> $actuel->getObj(),
      'articles'=> $actuel->getArt(),
    ));
  }

  public function compteAction() {
    $em = $this->getDoctrine()->getManager();
    $repU = $em->getRepository('PWPoudlardBundle:utilisateurs');
    $repP = $em->getRepository('PWPoudlardBundle:personnages');
    $nom = $this->get('security.token_storage')->getToken()->getUser()->getUsername();
    $user = $repU->findOneBy(array('username'=>$nom));
    $actuel = $repP->findOneBy(array('id'=>$user->getActuel()));

    if(isset($_POST['inputFile'])){
      $user->setAvatar("image/personnages/".$_POST['inputFile']);
      $em->flush();
    }

    return $this->render('PWPoudlardBundle:Default:compte.html.twig', array(
      'niveau' => $actuel->getNiveau(),
      'score' => $actuel->getScore(),
      'argent'=> $actuel->getArgent(),
      'actuel'=> $actuel,
      'objets'=> $actuel->getObj(),
      'articles'=> $actuel->getArt(),
    ));
  }

  public function choixPersoAction() {
    $em = $this->getDoctrine()->getManager();
    $repU = $em->getRepository('PWPoudlardBundle:utilisateurs');
    $repP = $em->getRepository('PWPoudlardBundle:personnages');
    $nom = $this->get('security.token_storage')->getToken()->getUser()->getUsername();
    $user = $repU->findOneBy(array('username'=>$nom));
    $persos = $repP->findBy(array('proprio'=>$user->getId()));

    return $this->render('PWPoudlardBundle:Default:choixPerso.html.twig', array(
      'persos'=>$persos
    ));
  }

  public function changerPersoAction(Request $request) {
    $em = $this->getDoctrine()->getManager();
    $repU = $em->getRepository('PWPoudlardBundle:utilisateurs');
    $repP = $em->getRepository('PWPoudlardBundle:personnages');
    $nom = $this->get('security.token_storage')->getToken()->getUser()->getUsername();
    $user = $repU->findOneBy(array('username'=>$nom));
    $persos = $repP->findBy(array('proprio'=>$user->getId()));
    $actuel = $repP->findOneBy(array('id'=>$user->getActuel()));

    //on crée le formulaire de nv perso
    $perso = new personnages($user->getUsername(), "1", $user->getAvatar(), $user->getId());

    // $formBuilderI = $this->get('form.factory')->createBuilder(FormType::class, $user);
    $formBuilderI = $this->createFormBuilder($perso);
    $formBuilderI
      ->add('nom', TextType::class, array(
        'label'=> 'Nom'
        ))
      ->add('maison', TextType::class, array(
        'label'=> 'Maison'
        ))
      ->add("Valider", SubmitType::class)

    ;
    $formI = $formBuilderI->getForm();

    //on entre le nouv perso dans la base de données
    if($request->isMethod('POST')){
      $formI->handleRequest($request);
      if($formI->isValid()){
        $em = $this->getDoctrine()->getManager();
        $repP = $em->getRepository('PWPoudlardBundle:personnages');
        $em->persist($perso);
        $em->flush();
      }
      $persos[] = $perso;
      $em->flush();
    }


    return $this->render('PWPoudlardBundle:Default:changerPerso.html.twig', array(
      'niveau' => $actuel->getNiveau(),
      'score' => $actuel->getScore(),
      'argent'=> $actuel->getArgent(),
      'actuel'=> $actuel,
      'objets'=> $actuel->getObj(),
      'articles'=> $actuel->getArt(),
      'formI'=> $formI->createView(),
      'persos'=>$persos
    ));
  }

  public function changerAvatarAction(Request $request) {
    $em = $this->getDoctrine()->getManager();
    $repU = $em->getRepository('PWPoudlardBundle:utilisateurs');
    $repP = $em->getRepository('PWPoudlardBundle:personnages');
    $nom = $this->get('security.token_storage')->getToken()->getUser()->getUsername();
    $user = $repU->findOneBy(array('username'=>$nom));
    $persos = $repP->findBy(array('proprio'=>$user->getId()));
    $actuel = $repP->findOneBy(array('id'=>$user->getActuel()));

    return $this->render('PWPoudlardBundle:Default:changerAvatar.html.twig', array(
      'niveau' => $actuel->getNiveau(),
      'score' => $actuel->getScore(),
      'argent'=> $actuel->getArgent(),
      'actuel'=> $actuel,
      'objets'=> $actuel->getObj(),
      'articles'=> $actuel->getArt(),

    ));

  }


  public function infosPersoAction() {
    $em = $this->getDoctrine()->getManager();
    $repU = $em->getRepository('PWPoudlardBundle:utilisateurs');
    $repP = $em->getRepository('PWPoudlardBundle:personnages');
    $nom = $this->get('security.token_storage')->getToken()->getUser()->getUsername();
    $user = $repU->findOneBy(array('username'=>$nom));
    $actuel = $repP->findOneBy(array('id'=>$user->getActuel()));

    if(isset($_POST['infos'])){
      $perso = $repP->findOneBy(array('id'=>intval($_POST['infos'])));
    }

    return $this->render('PWPoudlardBundle:Default:infosPerso.html.twig', array(
      'niveau' => $actuel->getNiveau(),
      'score' => $actuel->getScore(),
      'argent'=> $actuel->getArgent(),
      'actuel'=> $actuel,
      'objets'=> $actuel->getObj(),
      'articles'=> $actuel->getArt(),
    ));
  }

  public function affichagePersoAction() {
    $em = $this->getDoctrine()->getManager();
    $repU = $em->getRepository('PWPoudlardBundle:utilisateurs');
    $repP = $em->getRepository('PWPoudlardBundle:personnages');
    $nom = $this->get('security.token_storage')->getToken()->getUser()->getUsername();
    $user = $repU->findOneBy(array('username'=>$nom));
    $actuel = $repP->findOneBy(array('id'=>$user->getActuel()));

    $users = $repU->findAll();
    $nbUsers = count($users);
    $persos = $repP->findAll();
    $nbPersos = count($persos)-4;
    $allScores = array();
    $bestScore = -1;
    $bestLevel = 0;
    foreach ($persos as $p) {
      $allScores[] = $p->getScore();
      if($p->getScore() > $bestScore && $p->getNiveau() >= $bestLevel){
        $bestUserId = $p->getProprio();
        $bestScore = $p->getScore();
        $bestLevel = $p->getNiveau();
      }
    }
    $scoreMoy = array_sum($allScores)%$nbPersos;
    $bestUser = "betty";
    // $bestUser = $repU->findOneBy(array('id'=>$bestUserId))->getUsername();

    $stats = array(
      0 => $nbUsers,
      1 => $nbPersos,
      2 => $scoreMoy,
      3 => $bestUser,
      4 => $bestScore
    );

    return $this->render('PWPoudlardBundle:Default:affichagePerso.html.twig', array(
      'niveau' => $actuel->getNiveau(),
      'score' => $actuel->getScore(),
      'argent'=> $actuel->getArgent(),
      'actuel'=> $actuel,
      'objets'=> $actuel->getObj(),
      'articles'=> $actuel->getArt(),
      'stats'=>$stats,
      'users'=>$users,
      'persos'=>$persos
    ));
  }

}
