<?php

namespace PW\PoudlardBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * personnages
 *
 * @ORM\Table(name="personnages")
 * @ORM\Entity(repositoryClass="PW\PoudlardBundle\Repository\personnagesRepository")
 */
class personnages
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="nom", type="string", length=255)
     */
    private $nom;

    /**
     * @var int
     *
     * @ORM\Column(name="maison", type="integer")
     */
    private $maison;

    /**
     * @var int
     *
     * @ORM\Column(name="niveau", type="integer")
     */
    private $niveau;

    /**
     * @var int
     *
     * @ORM\Column(name="argent", type="integer")
     */
    private $argent;

    /**
     * @var int
     *
     * @ORM\Column(name="score", type="integer")
     */
    private $score;

    /**
     * @var array
     *
     * @ORM\Column(name="obj", type="array")
     */
    private $obj;

    /**
     * @var array
     *
     * @ORM\Column(name="art", type="array")
     */
    private $art;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date", type="datetime")
     */
    private $date;

    /**
     * @var string
     *
     * @ORM\Column(name="image", type="string", length=255)
     */
    private $image;

    /**
     *@var int
     *
     * @ORM\Column(name="proprio", type="integer")
     */
    private $proprio;

    /**
     *@var int
     *
     * @ORM\Column(name="bibli", type="integer")
     */
    private $bibli;


    public function __construct($name, $house, $photo, $owner){
      $this->setDate(new \DateTime());
      $this->setArgent(5);
      $this->setNiveau(1);
      $this->setScore(0);
      $this->setNom($name);
      $this->setMaison($house);
      $this->setImage($photo);
      $this->setProprio($owner);
      $this->setBibli(1);

      $arrA = array(
        0 => 0,
        1 => 0,
        2 => 0,
        3 => 0,
        4 => 0,
        5 => 0,
        6 => 0,
        7 => 0,
        8 => 0,
        9 => 0
      );
      $this->setArt($arrA);


      $arrO = array(
        0 => 0,
        1 => 0,
        2 => 0,
        3 => 0
      );
      $this->setObj($arrO);

    }



    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nom
     *
     * @param string $nom
     *
     * @return personnages
     */
    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Set maison
     *
     * @param integer $maison
     *
     * @return personnages
     */
    public function setMaison($maison)
    {
        $this->maison = $maison;

        return $this;
    }

    /**
     * Get maison
     *
     * @return int
     */
    public function getMaison()
    {
        return $this->maison;
    }

    /**
     * Set niveau
     *
     * @param integer $niveau
     *
     * @return personnages
     */
    public function setNiveau($niveau)
    {
        $this->niveau = $niveau;

        return $this;
    }

    /**
     * Get niveau
     *
     * @return int
     */
    public function getNiveau()
    {
        return $this->niveau;
    }

    /**
     * Set argent
     *
     * @param integer $argent
     *
     * @return personnages
     */
    public function setArgent($argent)
    {
        $this->argent += $argent;

        return $this;
    }

    /**
     * Get argent
     *
     * @return int
     */
    public function getArgent()
    {
        return $this->argent;
    }

    /**
     * Set score
     *
     * @param integer $score
     *
     * @return personnages
     */
    public function setScore($score)
    {
        $this->score += $score;

        return $this;
    }

    /**
     * Get score
     *
     * @return int
     */
    public function getScore()
    {
        return $this->score;
    }


    /**
     * Set obj
     *
     * @param array $obj
     *
     * @return personnages
     */
    public function setObj($obj)
    {
        $this->obj = $obj;

        return $this;
    }

    /**
     * Get obj
     *
     * @return array
     */
    public function getObj()
    {
        return $this->obj;
    }

    /**
     * Set art
     *
     * @param array $art
     *
     * @return personnages
     */
    public function setArt($art)
    {
        $this->art = $art;

        return $this;
    }

    /**
     * Get art
     *
     * @return array
     */
    public function getArt()
    {
        return $this->art;
    }

    /**
     * Set date
     *
     * @param \DateTime $date
     *
     * @return personnages
     */
    public function setDate($date)
    {
        $this->date = $date;

        return $this;
    }

    /**
     * Get date
     *
     * @return \DateTime
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * Set image
     *
     * @param string $image
     *
     * @return personnages
     */
    public function setImage($image)
    {
        $this->image = $image;

        return $this;
    }

    /**
     * Get image
     *
     * @return string
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * Set proprio
     *
     * @param integer $proprio
     *
     * @return personnages
     */
    public function setProprio($proprio)
    {
        $this->proprio = $proprio;

        return $this;
    }

    /**
     * Get proprio
     *
     * @return integer
     */
    public function getProprio()
    {
        return $this->proprio;
    }

    /**
     * Set bibli
     *
     * @param integer $bibli
     *
     * @return personnages
     */
    public function setBibli($bibli)
    {
        $this->bibli = $bibli;

        return $this;
    }

    /**
     * Get bibli
     *
     * @return integer
     */
    public function getBibli()
    {
        return $this->bibli;
    }
}
