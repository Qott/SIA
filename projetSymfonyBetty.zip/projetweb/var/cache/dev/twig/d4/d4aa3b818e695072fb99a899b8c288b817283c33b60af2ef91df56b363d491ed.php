<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_b637723b582a7979b4b36d8b8f86a06c12f6affa9919a773d7bb7ead0fa50a1a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_407b65ce79df811407df69945bc9f9a9bec9c05a9d7e0f4a2f61766d5fa016d4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_407b65ce79df811407df69945bc9f9a9bec9c05a9d7e0f4a2f61766d5fa016d4->enter($__internal_407b65ce79df811407df69945bc9f9a9bec9c05a9d7e0f4a2f61766d5fa016d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $__internal_73d6c17e5a3b56607482081be4c09251c04b0272a488407201de5e3fe32b246f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_73d6c17e5a3b56607482081be4c09251c04b0272a488407201de5e3fe32b246f->enter($__internal_73d6c17e5a3b56607482081be4c09251c04b0272a488407201de5e3fe32b246f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_407b65ce79df811407df69945bc9f9a9bec9c05a9d7e0f4a2f61766d5fa016d4->leave($__internal_407b65ce79df811407df69945bc9f9a9bec9c05a9d7e0f4a2f61766d5fa016d4_prof);

        
        $__internal_73d6c17e5a3b56607482081be4c09251c04b0272a488407201de5e3fe32b246f->leave($__internal_73d6c17e5a3b56607482081be4c09251c04b0272a488407201de5e3fe32b246f_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_48fa79de6a787ec701604424c73a131c65fd90ee04d0efc0ed066e0326646dcf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_48fa79de6a787ec701604424c73a131c65fd90ee04d0efc0ed066e0326646dcf->enter($__internal_48fa79de6a787ec701604424c73a131c65fd90ee04d0efc0ed066e0326646dcf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_56c859c9ab41896bb437035679b1c75e3c237d554ffdbc822e68849dc6a04a3e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_56c859c9ab41896bb437035679b1c75e3c237d554ffdbc822e68849dc6a04a3e->enter($__internal_56c859c9ab41896bb437035679b1c75e3c237d554ffdbc822e68849dc6a04a3e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_56c859c9ab41896bb437035679b1c75e3c237d554ffdbc822e68849dc6a04a3e->leave($__internal_56c859c9ab41896bb437035679b1c75e3c237d554ffdbc822e68849dc6a04a3e_prof);

        
        $__internal_48fa79de6a787ec701604424c73a131c65fd90ee04d0efc0ed066e0326646dcf->leave($__internal_48fa79de6a787ec701604424c73a131c65fd90ee04d0efc0ed066e0326646dcf_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_11d266f09c3231300900e7d718b28304e4378aa2a338f17b8b4e477ad5bd66a8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_11d266f09c3231300900e7d718b28304e4378aa2a338f17b8b4e477ad5bd66a8->enter($__internal_11d266f09c3231300900e7d718b28304e4378aa2a338f17b8b4e477ad5bd66a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_382275afce82e5ea8f119d1d5c08ba997d68ad43d4a86d83a537c93a83abf617 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_382275afce82e5ea8f119d1d5c08ba997d68ad43d4a86d83a537c93a83abf617->enter($__internal_382275afce82e5ea8f119d1d5c08ba997d68ad43d4a86d83a537c93a83abf617_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_382275afce82e5ea8f119d1d5c08ba997d68ad43d4a86d83a537c93a83abf617->leave($__internal_382275afce82e5ea8f119d1d5c08ba997d68ad43d4a86d83a537c93a83abf617_prof);

        
        $__internal_11d266f09c3231300900e7d718b28304e4378aa2a338f17b8b4e477ad5bd66a8->leave($__internal_11d266f09c3231300900e7d718b28304e4378aa2a338f17b8b4e477ad5bd66a8_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/toolbar_redirect.html.twig");
    }
}
