<?php

/* PWPoudlardBundle:Default:affichagePerso.html.twig */
class __TwigTemplate_481ca8ceaae22230a76350b3876b157bdf8d709485b8ccc18ae6ec8d08adf77a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("menu.html.twig", "PWPoudlardBundle:Default:affichagePerso.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "menu.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3d65da2a360d5eef8f310817fac60ce8cdc616b918e7566a0ccac023c6bfaeb0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3d65da2a360d5eef8f310817fac60ce8cdc616b918e7566a0ccac023c6bfaeb0->enter($__internal_3d65da2a360d5eef8f310817fac60ce8cdc616b918e7566a0ccac023c6bfaeb0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PWPoudlardBundle:Default:affichagePerso.html.twig"));

        $__internal_985d298f820848e6c36abdcd22232352ac0f98446d0bf216692e40cf7a4c8545 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_985d298f820848e6c36abdcd22232352ac0f98446d0bf216692e40cf7a4c8545->enter($__internal_985d298f820848e6c36abdcd22232352ac0f98446d0bf216692e40cf7a4c8545_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PWPoudlardBundle:Default:affichagePerso.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3d65da2a360d5eef8f310817fac60ce8cdc616b918e7566a0ccac023c6bfaeb0->leave($__internal_3d65da2a360d5eef8f310817fac60ce8cdc616b918e7566a0ccac023c6bfaeb0_prof);

        
        $__internal_985d298f820848e6c36abdcd22232352ac0f98446d0bf216692e40cf7a4c8545->leave($__internal_985d298f820848e6c36abdcd22232352ac0f98446d0bf216692e40cf7a4c8545_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_37169bcf7c5a36203262bc6dd5fa34d60e9e926a4eb3138adb22e6afd1d9b520 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_37169bcf7c5a36203262bc6dd5fa34d60e9e926a4eb3138adb22e6afd1d9b520->enter($__internal_37169bcf7c5a36203262bc6dd5fa34d60e9e926a4eb3138adb22e6afd1d9b520_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_508e6d0532c82eb5756d11951227f783a4833560beddad2b9119847694d0958c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_508e6d0532c82eb5756d11951227f783a4833560beddad2b9119847694d0958c->enter($__internal_508e6d0532c82eb5756d11951227f783a4833560beddad2b9119847694d0958c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Personnages";
        
        $__internal_508e6d0532c82eb5756d11951227f783a4833560beddad2b9119847694d0958c->leave($__internal_508e6d0532c82eb5756d11951227f783a4833560beddad2b9119847694d0958c_prof);

        
        $__internal_37169bcf7c5a36203262bc6dd5fa34d60e9e926a4eb3138adb22e6afd1d9b520->leave($__internal_37169bcf7c5a36203262bc6dd5fa34d60e9e926a4eb3138adb22e6afd1d9b520_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_6a877799f4e4e14a09c20e822adb568801b4b08c663b0c21d04e711975902543 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6a877799f4e4e14a09c20e822adb568801b4b08c663b0c21d04e711975902543->enter($__internal_6a877799f4e4e14a09c20e822adb568801b4b08c663b0c21d04e711975902543_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_f249282ea5f24f638fdcbad088a73fd576726d8674e9d78f559e8f76b8f1d68f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f249282ea5f24f638fdcbad088a73fd576726d8674e9d78f559e8f76b8f1d68f->enter($__internal_f249282ea5f24f638fdcbad088a73fd576726d8674e9d78f559e8f76b8f1d68f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "  <div class=\"row\">
    <div class=\"col-sm-10 col-sm-push-1\">
      ";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["persos"] ?? $this->getContext($context, "persos")));
        foreach ($context['_seq'] as $context["_key"] => $context["perso"]) {
            // line 9
            echo "        ";
            if (($this->getAttribute($context["perso"], "id", array()) > 4)) {
                // line 10
                echo "          <a id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["perso"], "id", array()), "html", null, true);
                echo "click\">
            <div class=\"col-sm-2\">
              <div class=\"col-sm-12 col-sm-push-1 text-center\" id=\"border\">
                <form action=\"";
                // line 13
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pw_poudlard_infosPerso");
                echo "\" method=\"post\" id=\"formAffiche\">
                  <input type=\"hidden\" name=\"infos\" value=\"";
                // line 14
                echo twig_escape_filter($this->env, $this->getAttribute($context["perso"], "id", array()), "html", null, true);
                echo "\">
                  <figure>
                    <img src=\"";
                // line 16
                echo twig_escape_filter($this->env, $this->getAttribute($context["perso"], "image", array()), "html", null, true);
                echo "\" alt=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["perso"], "nom", array()), "html", null, true);
                echo "\" id=\"objets\"/>
                    <figcaption>
                      ";
                // line 18
                echo twig_escape_filter($this->env, $this->getAttribute($context["perso"], "nom", array()), "html", null, true);
                echo "
                      <br>
                      ";
                // line 20
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(($context["users"] ?? $this->getContext($context, "users")));
                foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
                    // line 21
                    echo "                        ";
                    if (($this->getAttribute($context["user"], "id", array()) == $this->getAttribute($context["perso"], "proprio", array()))) {
                        // line 22
                        echo "                          ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "username", array()), "html", null, true);
                        echo "
                        ";
                    }
                    // line 24
                    echo "                      ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 25
                echo "                    </figcaption>
                  </figure>
                </form>

                <script type=\"text/javascript\">
                  \$(\"#";
                // line 30
                echo twig_escape_filter($this->env, $this->getAttribute($context["perso"], "id", array()), "html", null, true);
                echo "click\").click(function() {
                    \$(\"#formAffiche\").submit();
                  });
                </script>
              </div>
            </div>
          </a>
        ";
            }
            // line 38
            echo "      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['perso'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        echo "    </div>
  </div>

";
        // line 44
        echo "
  <div class=\"row\">
    <div class=\"col-sm-2 col-sm-push-5\" id=\"body_color\">
      <h3 class=\"text-center\">Statistiques</h3>
      <p>
        Nombre de joueurs : ";
        // line 49
        echo twig_escape_filter($this->env, $this->getAttribute(($context["stats"] ?? $this->getContext($context, "stats")), 0, array(), "array"), "html", null, true);
        echo "<br>
        Nombre de personnages : ";
        // line 50
        echo twig_escape_filter($this->env, $this->getAttribute(($context["stats"] ?? $this->getContext($context, "stats")), 1, array(), "array"), "html", null, true);
        echo "<br>
        Score Moyen : ";
        // line 51
        echo twig_escape_filter($this->env, $this->getAttribute(($context["stats"] ?? $this->getContext($context, "stats")), 2, array(), "array"), "html", null, true);
        echo "<br>
        Meilleur Joueur : ";
        // line 52
        echo twig_escape_filter($this->env, $this->getAttribute(($context["stats"] ?? $this->getContext($context, "stats")), 3, array(), "array"), "html", null, true);
        echo "<br>
        Meilleur Score: ";
        // line 53
        echo twig_escape_filter($this->env, $this->getAttribute(($context["stats"] ?? $this->getContext($context, "stats")), 4, array(), "array"), "html", null, true);
        echo "
      </p>
    </div>
  </div>
";
        
        $__internal_f249282ea5f24f638fdcbad088a73fd576726d8674e9d78f559e8f76b8f1d68f->leave($__internal_f249282ea5f24f638fdcbad088a73fd576726d8674e9d78f559e8f76b8f1d68f_prof);

        
        $__internal_6a877799f4e4e14a09c20e822adb568801b4b08c663b0c21d04e711975902543->leave($__internal_6a877799f4e4e14a09c20e822adb568801b4b08c663b0c21d04e711975902543_prof);

    }

    public function getTemplateName()
    {
        return "PWPoudlardBundle:Default:affichagePerso.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  178 => 53,  174 => 52,  170 => 51,  166 => 50,  162 => 49,  155 => 44,  150 => 39,  144 => 38,  133 => 30,  126 => 25,  120 => 24,  114 => 22,  111 => 21,  107 => 20,  102 => 18,  95 => 16,  90 => 14,  86 => 13,  79 => 10,  76 => 9,  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"menu.html.twig\" %}

{% block title %}Personnages{% endblock %}

{% block body %}
  <div class=\"row\">
    <div class=\"col-sm-10 col-sm-push-1\">
      {% for perso in persos %}
        {% if perso.id > 4 %}
          <a id=\"{{perso.id}}click\">
            <div class=\"col-sm-2\">
              <div class=\"col-sm-12 col-sm-push-1 text-center\" id=\"border\">
                <form action=\"{{ path(\"pw_poudlard_infosPerso\") }}\" method=\"post\" id=\"formAffiche\">
                  <input type=\"hidden\" name=\"infos\" value=\"{{perso.id}}\">
                  <figure>
                    <img src=\"{{ perso.image }}\" alt=\"{{perso.nom}}\" id=\"objets\"/>
                    <figcaption>
                      {{perso.nom}}
                      <br>
                      {% for user in users %}
                        {% if user.id == perso.proprio %}
                          {{user.username}}
                        {% endif %}
                      {% endfor %}
                    </figcaption>
                  </figure>
                </form>

                <script type=\"text/javascript\">
                  \$(\"#{{perso.id}}click\").click(function() {
                    \$(\"#formAffiche\").submit();
                  });
                </script>
              </div>
            </div>
          </a>
        {% endif %}
      {% endfor %}
    </div>
  </div>

{# Attention il faudra creer un formulaire hidden qui lorsqu'on #}
{#clique sur une image renvoie vers infosPerso en donnant l'id du perso#}

  <div class=\"row\">
    <div class=\"col-sm-2 col-sm-push-5\" id=\"body_color\">
      <h3 class=\"text-center\">Statistiques</h3>
      <p>
        Nombre de joueurs : {{stats[0]}}<br>
        Nombre de personnages : {{stats[1]}}<br>
        Score Moyen : {{stats[2]}}<br>
        Meilleur Joueur : {{stats[3]}}<br>
        Meilleur Score: {{stats[4]}}
      </p>
    </div>
  </div>
{% endblock %}
", "PWPoudlardBundle:Default:affichagePerso.html.twig", "/home/betty/S6/PW6/projetweb/projetweb/src/PW/PoudlardBundle/Resources/views/Default/affichagePerso.html.twig");
    }
}
