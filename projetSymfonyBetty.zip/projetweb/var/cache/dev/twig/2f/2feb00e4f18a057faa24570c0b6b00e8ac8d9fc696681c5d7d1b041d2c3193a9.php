<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_91a8934b45f9944e6ad04de6aaf89fffee96696656f72c4601847bdc8ca26d04 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f493acaef7a2ac2b85765dfbff7879324c5e15bd2a7c66e9ccd200610cf8c17f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f493acaef7a2ac2b85765dfbff7879324c5e15bd2a7c66e9ccd200610cf8c17f->enter($__internal_f493acaef7a2ac2b85765dfbff7879324c5e15bd2a7c66e9ccd200610cf8c17f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        $__internal_ac45aefd8a28155450a4f8b71203ed339f69c2ebf718ce0f14707b99396a78d8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ac45aefd8a28155450a4f8b71203ed339f69c2ebf718ce0f14707b99396a78d8->enter($__internal_ac45aefd8a28155450a4f8b71203ed339f69c2ebf718ce0f14707b99396a78d8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_f493acaef7a2ac2b85765dfbff7879324c5e15bd2a7c66e9ccd200610cf8c17f->leave($__internal_f493acaef7a2ac2b85765dfbff7879324c5e15bd2a7c66e9ccd200610cf8c17f_prof);

        
        $__internal_ac45aefd8a28155450a4f8b71203ed339f69c2ebf718ce0f14707b99396a78d8->leave($__internal_ac45aefd8a28155450a4f8b71203ed339f69c2ebf718ce0f14707b99396a78d8_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
", "@Framework/Form/form_widget_simple.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_widget_simple.html.php");
    }
}
