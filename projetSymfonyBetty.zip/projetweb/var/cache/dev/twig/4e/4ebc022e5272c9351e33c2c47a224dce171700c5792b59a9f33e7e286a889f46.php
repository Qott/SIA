<?php

/* PWPoudlardBundle:Default:infosPerso.html.twig */
class __TwigTemplate_854be3ae8da96d652d57a82187598f172edc19ccadd9349ac5ad16f75893ae6c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("menu.html.twig", "PWPoudlardBundle:Default:infosPerso.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "menu.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_605e44022afa355f9134b15dcf5197fd12f78abd3ff585643706341e6cdaaec2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_605e44022afa355f9134b15dcf5197fd12f78abd3ff585643706341e6cdaaec2->enter($__internal_605e44022afa355f9134b15dcf5197fd12f78abd3ff585643706341e6cdaaec2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PWPoudlardBundle:Default:infosPerso.html.twig"));

        $__internal_25542d9430a6f95d4bd71355a08dcf1e6f98e2974f2fe6d6da9294491ab3c148 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_25542d9430a6f95d4bd71355a08dcf1e6f98e2974f2fe6d6da9294491ab3c148->enter($__internal_25542d9430a6f95d4bd71355a08dcf1e6f98e2974f2fe6d6da9294491ab3c148_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PWPoudlardBundle:Default:infosPerso.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_605e44022afa355f9134b15dcf5197fd12f78abd3ff585643706341e6cdaaec2->leave($__internal_605e44022afa355f9134b15dcf5197fd12f78abd3ff585643706341e6cdaaec2_prof);

        
        $__internal_25542d9430a6f95d4bd71355a08dcf1e6f98e2974f2fe6d6da9294491ab3c148->leave($__internal_25542d9430a6f95d4bd71355a08dcf1e6f98e2974f2fe6d6da9294491ab3c148_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_1a785a2fc6fda49e4302c58ba359ebbd7239f93f5dd0688569b2b8e24fe51c60 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1a785a2fc6fda49e4302c58ba359ebbd7239f93f5dd0688569b2b8e24fe51c60->enter($__internal_1a785a2fc6fda49e4302c58ba359ebbd7239f93f5dd0688569b2b8e24fe51c60_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_414832a0881a8d53caa9e418886d73c07d76808836343faf76a56e060918c386 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_414832a0881a8d53caa9e418886d73c07d76808836343faf76a56e060918c386->enter($__internal_414832a0881a8d53caa9e418886d73c07d76808836343faf76a56e060918c386_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Nom du personnage";
        
        $__internal_414832a0881a8d53caa9e418886d73c07d76808836343faf76a56e060918c386->leave($__internal_414832a0881a8d53caa9e418886d73c07d76808836343faf76a56e060918c386_prof);

        
        $__internal_1a785a2fc6fda49e4302c58ba359ebbd7239f93f5dd0688569b2b8e24fe51c60->leave($__internal_1a785a2fc6fda49e4302c58ba359ebbd7239f93f5dd0688569b2b8e24fe51c60_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_70bf15ce1c9e6d0dbfe5785f4e40378b298d861b5d7d678aa112602a2dd8ad2c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_70bf15ce1c9e6d0dbfe5785f4e40378b298d861b5d7d678aa112602a2dd8ad2c->enter($__internal_70bf15ce1c9e6d0dbfe5785f4e40378b298d861b5d7d678aa112602a2dd8ad2c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_f063dd8d12fa5bffd17ac8d6ae696bde14fefdba0012a68a366ae45862d06975 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f063dd8d12fa5bffd17ac8d6ae696bde14fefdba0012a68a366ae45862d06975->enter($__internal_f063dd8d12fa5bffd17ac8d6ae696bde14fefdba0012a68a366ae45862d06975_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "  <div class=\"container-fluid\">
    <div class=\"col-sm-4 text-center\">
      <img src=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("image/personnages/harry_potter.jpg"), "html", null, true);
        echo "\" alt=\"Photo du personnage\" id=\"photo_perso\"/>
    </div>
    <div class=\"col-sm-4\">
      <table class=\"table\" id=\"body_color\">
        <tbody>
          <tr>
            <td><h3>Maison</h3></td>
            <td class=\"text-center\" id=\"td_center\">Maison du personnage</td>
          </tr>
          <tr>
            <td><h3>Niveau</h3></td>
            <td class=\"text-center\" id=\"td_center\">niveau / 7</td>
          </tr>
          <tr>
            <td><h3>Score</h3></td>
            <td class=\"text-center\" id=\"td_center\">Score du personnage</td>
          </tr>
          <tr>
            <td><h3>Argent</h3></td>
            <td class=\"text-center\" id=\"td_center\">argent mornilles</td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class=\"dropdown col-sm-4\" id=\"menu_objets\">
      <button type=\"button\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">Objets
        <span class=\"caret\"></span>
      </button>
      <ul class=\"dropdown-menu dropdown-menu-left\" id=\"ul_menu_objets\">
        <li><a>
          <figure>
            <img src=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("image/livre.jpg"), "html", null, true);
        echo "\" alt=\"Objet\" id=\"objets\"/>
            <figcaption>Livre de défense contre les forces du mal niveau 1</figcaption>
          </figure>
        </a></li>
        <li><a>
          <figure>
            <img src=\"";
        // line 46
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("image/livre.jpg"), "html", null, true);
        echo "\" alt=\"Objet\" id=\"objets\"/>
            <figcaption>Autre objet</figcaption>
          </figure>
        </a></li>
        <li><a>
          <figure>
            <img src=\"";
        // line 52
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("image/livre.jpg"), "html", null, true);
        echo "\" alt=\"Objet\" id=\"objets\"/>
            <figcaption>Autre objet</figcaption>
          </figure>
        </a></li>
        <li><a>
          <figure>
            <img src=\"";
        // line 58
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("image/livre.jpg"), "html", null, true);
        echo "\" alt=\"Objet\" id=\"objets\"/>
            <figcaption>Autre objet</figcaption>
          </figure>
        </a></li>
        <li><a>
          <figure>
            <img src=\"";
        // line 64
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("image/livre.jpg"), "html", null, true);
        echo "\" alt=\"Objet\" id=\"objets\"/>
            <figcaption>Autre objet</figcaption>
          </figure>
        </a></li>
        <li><a>
          <figure>
            <img src=\"";
        // line 70
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("image/livre.jpg"), "html", null, true);
        echo "\" alt=\"Objet\" id=\"objets\"/>
            <figcaption>Autre objet</figcaption>
          </figure>
        </a></li>
      </ul>
    </div>
  </div>
";
        
        $__internal_f063dd8d12fa5bffd17ac8d6ae696bde14fefdba0012a68a366ae45862d06975->leave($__internal_f063dd8d12fa5bffd17ac8d6ae696bde14fefdba0012a68a366ae45862d06975_prof);

        
        $__internal_70bf15ce1c9e6d0dbfe5785f4e40378b298d861b5d7d678aa112602a2dd8ad2c->leave($__internal_70bf15ce1c9e6d0dbfe5785f4e40378b298d861b5d7d678aa112602a2dd8ad2c_prof);

    }

    public function getTemplateName()
    {
        return "PWPoudlardBundle:Default:infosPerso.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  152 => 70,  143 => 64,  134 => 58,  125 => 52,  116 => 46,  107 => 40,  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"menu.html.twig\" %}

{% block title %}Nom du personnage{% endblock %}

{% block body %}
  <div class=\"container-fluid\">
    <div class=\"col-sm-4 text-center\">
      <img src=\"{{ asset(\"image/personnages/harry_potter.jpg\") }}\" alt=\"Photo du personnage\" id=\"photo_perso\"/>
    </div>
    <div class=\"col-sm-4\">
      <table class=\"table\" id=\"body_color\">
        <tbody>
          <tr>
            <td><h3>Maison</h3></td>
            <td class=\"text-center\" id=\"td_center\">Maison du personnage</td>
          </tr>
          <tr>
            <td><h3>Niveau</h3></td>
            <td class=\"text-center\" id=\"td_center\">niveau / 7</td>
          </tr>
          <tr>
            <td><h3>Score</h3></td>
            <td class=\"text-center\" id=\"td_center\">Score du personnage</td>
          </tr>
          <tr>
            <td><h3>Argent</h3></td>
            <td class=\"text-center\" id=\"td_center\">argent mornilles</td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class=\"dropdown col-sm-4\" id=\"menu_objets\">
      <button type=\"button\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">Objets
        <span class=\"caret\"></span>
      </button>
      <ul class=\"dropdown-menu dropdown-menu-left\" id=\"ul_menu_objets\">
        <li><a>
          <figure>
            <img src=\"{{ asset(\"image/livre.jpg\") }}\" alt=\"Objet\" id=\"objets\"/>
            <figcaption>Livre de défense contre les forces du mal niveau 1</figcaption>
          </figure>
        </a></li>
        <li><a>
          <figure>
            <img src=\"{{ asset(\"image/livre.jpg\") }}\" alt=\"Objet\" id=\"objets\"/>
            <figcaption>Autre objet</figcaption>
          </figure>
        </a></li>
        <li><a>
          <figure>
            <img src=\"{{ asset(\"image/livre.jpg\") }}\" alt=\"Objet\" id=\"objets\"/>
            <figcaption>Autre objet</figcaption>
          </figure>
        </a></li>
        <li><a>
          <figure>
            <img src=\"{{ asset(\"image/livre.jpg\") }}\" alt=\"Objet\" id=\"objets\"/>
            <figcaption>Autre objet</figcaption>
          </figure>
        </a></li>
        <li><a>
          <figure>
            <img src=\"{{ asset(\"image/livre.jpg\") }}\" alt=\"Objet\" id=\"objets\"/>
            <figcaption>Autre objet</figcaption>
          </figure>
        </a></li>
        <li><a>
          <figure>
            <img src=\"{{ asset(\"image/livre.jpg\") }}\" alt=\"Objet\" id=\"objets\"/>
            <figcaption>Autre objet</figcaption>
          </figure>
        </a></li>
      </ul>
    </div>
  </div>
{% endblock %}
", "PWPoudlardBundle:Default:infosPerso.html.twig", "/home/betty/S6/PW6/projetweb/projetweb/src/PW/PoudlardBundle/Resources/views/Default/infosPerso.html.twig");
    }
}
