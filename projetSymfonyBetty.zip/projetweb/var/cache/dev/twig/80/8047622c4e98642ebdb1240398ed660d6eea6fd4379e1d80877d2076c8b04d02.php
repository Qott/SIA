<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_a2047749632772e78fc479fb789b20bfbae028baf86d5e829db4bd4947a1e2e3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c21fefa85cebb9e116ca66fc9cc7d159a00b6f71e6a51540e25fa908399f0b9b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c21fefa85cebb9e116ca66fc9cc7d159a00b6f71e6a51540e25fa908399f0b9b->enter($__internal_c21fefa85cebb9e116ca66fc9cc7d159a00b6f71e6a51540e25fa908399f0b9b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        $__internal_ed8fa162474074c938f65e62fadeb60f88b0d49ffd78e53def4ed5f6c7c24054 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ed8fa162474074c938f65e62fadeb60f88b0d49ffd78e53def4ed5f6c7c24054->enter($__internal_ed8fa162474074c938f65e62fadeb60f88b0d49ffd78e53def4ed5f6c7c24054_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_c21fefa85cebb9e116ca66fc9cc7d159a00b6f71e6a51540e25fa908399f0b9b->leave($__internal_c21fefa85cebb9e116ca66fc9cc7d159a00b6f71e6a51540e25fa908399f0b9b_prof);

        
        $__internal_ed8fa162474074c938f65e62fadeb60f88b0d49ffd78e53def4ed5f6c7c24054->leave($__internal_ed8fa162474074c938f65e62fadeb60f88b0d49ffd78e53def4ed5f6c7c24054_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
", "@Framework/Form/form.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form.html.php");
    }
}
