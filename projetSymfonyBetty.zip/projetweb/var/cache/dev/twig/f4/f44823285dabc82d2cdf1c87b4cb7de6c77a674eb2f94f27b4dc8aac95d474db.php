<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_fdef7b3cbc51627ddf34b13ab6fe79909f3fb2aa9aacdf2b43b9e2fe712f399f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_afc4b12fb92fc9fd20a23842511361bea66df96bdfc67e6cf7affd2566c866d0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_afc4b12fb92fc9fd20a23842511361bea66df96bdfc67e6cf7affd2566c866d0->enter($__internal_afc4b12fb92fc9fd20a23842511361bea66df96bdfc67e6cf7affd2566c866d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        $__internal_9b2c5e94d0b635b84c5c36420431b94e752881f2286d5ab8467df6d20be7e2d1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9b2c5e94d0b635b84c5c36420431b94e752881f2286d5ab8467df6d20be7e2d1->enter($__internal_9b2c5e94d0b635b84c5c36420431b94e752881f2286d5ab8467df6d20be7e2d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_afc4b12fb92fc9fd20a23842511361bea66df96bdfc67e6cf7affd2566c866d0->leave($__internal_afc4b12fb92fc9fd20a23842511361bea66df96bdfc67e6cf7affd2566c866d0_prof);

        
        $__internal_9b2c5e94d0b635b84c5c36420431b94e752881f2286d5ab8467df6d20be7e2d1->leave($__internal_9b2c5e94d0b635b84c5c36420431b94e752881f2286d5ab8467df6d20be7e2d1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
", "@Framework/Form/choice_options.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_options.html.php");
    }
}
