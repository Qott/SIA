<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_a35857ee1311a28a3bc68d6cb688f4573a483378ff1d1ae838e53d4742bfcaab extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7477c63f5a3771b77249942cf0190e152b31a9758636d359df22b783ab328680 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7477c63f5a3771b77249942cf0190e152b31a9758636d359df22b783ab328680->enter($__internal_7477c63f5a3771b77249942cf0190e152b31a9758636d359df22b783ab328680_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        $__internal_eb3a1f4d3b2a34961c569cb5df170c4fefde79bd7d095f3f93eccc6db22c8307 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eb3a1f4d3b2a34961c569cb5df170c4fefde79bd7d095f3f93eccc6db22c8307->enter($__internal_eb3a1f4d3b2a34961c569cb5df170c4fefde79bd7d095f3f93eccc6db22c8307_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
        
        $__internal_7477c63f5a3771b77249942cf0190e152b31a9758636d359df22b783ab328680->leave($__internal_7477c63f5a3771b77249942cf0190e152b31a9758636d359df22b783ab328680_prof);

        
        $__internal_eb3a1f4d3b2a34961c569cb5df170c4fefde79bd7d095f3f93eccc6db22c8307->leave($__internal_eb3a1f4d3b2a34961c569cb5df170c4fefde79bd7d095f3f93eccc6db22c8307_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
", "@Framework/Form/attributes.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/attributes.html.php");
    }
}
