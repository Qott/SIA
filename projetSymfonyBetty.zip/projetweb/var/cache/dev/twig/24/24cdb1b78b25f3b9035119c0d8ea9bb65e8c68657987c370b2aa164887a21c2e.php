<?php

/* TwigBundle:Exception:exception.js.twig */
class __TwigTemplate_3ee860a2cff957446f4e9e2481079c3f6a949a8e6a353099fa77fd7770c2b433 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fb2c44cfa009cd13cefcaef3ca23a0f3d988a44cac3449c3e71351017d33aec0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fb2c44cfa009cd13cefcaef3ca23a0f3d988a44cac3449c3e71351017d33aec0->enter($__internal_fb2c44cfa009cd13cefcaef3ca23a0f3d988a44cac3449c3e71351017d33aec0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        $__internal_d7a2cd60129958666f4bb1bf9eeb1e0ae0ed083b3948b7d0dd46f880ee0406bb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d7a2cd60129958666f4bb1bf9eeb1e0ae0ed083b3948b7d0dd46f880ee0406bb->enter($__internal_d7a2cd60129958666f4bb1bf9eeb1e0ae0ed083b3948b7d0dd46f880ee0406bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "TwigBundle:Exception:exception.js.twig", 2)->display(array_merge($context, array("exception" => ($context["exception"] ?? $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_fb2c44cfa009cd13cefcaef3ca23a0f3d988a44cac3449c3e71351017d33aec0->leave($__internal_fb2c44cfa009cd13cefcaef3ca23a0f3d988a44cac3449c3e71351017d33aec0_prof);

        
        $__internal_d7a2cd60129958666f4bb1bf9eeb1e0ae0ed083b3948b7d0dd46f880ee0406bb->leave($__internal_d7a2cd60129958666f4bb1bf9eeb1e0ae0ed083b3948b7d0dd46f880ee0406bb_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 3,  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}
*/
", "TwigBundle:Exception:exception.js.twig", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.js.twig");
    }
}
