<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_cdbb904837e962a19dfec90805919a0d29ba78968ddf9c258e4cd106724570ae extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_752a9092a162f4be9f8e964bd3232fc53c66eb4b657ac8aaa0ca89f3470346d3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_752a9092a162f4be9f8e964bd3232fc53c66eb4b657ac8aaa0ca89f3470346d3->enter($__internal_752a9092a162f4be9f8e964bd3232fc53c66eb4b657ac8aaa0ca89f3470346d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        $__internal_98740ec98a61285c2fb1980cccebdadcefe16f711fc2c3fef4471c5d208566fa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_98740ec98a61285c2fb1980cccebdadcefe16f711fc2c3fef4471c5d208566fa->enter($__internal_98740ec98a61285c2fb1980cccebdadcefe16f711fc2c3fef4471c5d208566fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_752a9092a162f4be9f8e964bd3232fc53c66eb4b657ac8aaa0ca89f3470346d3->leave($__internal_752a9092a162f4be9f8e964bd3232fc53c66eb4b657ac8aaa0ca89f3470346d3_prof);

        
        $__internal_98740ec98a61285c2fb1980cccebdadcefe16f711fc2c3fef4471c5d208566fa->leave($__internal_98740ec98a61285c2fb1980cccebdadcefe16f711fc2c3fef4471c5d208566fa_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
", "@Framework/Form/integer_widget.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/integer_widget.html.php");
    }
}
