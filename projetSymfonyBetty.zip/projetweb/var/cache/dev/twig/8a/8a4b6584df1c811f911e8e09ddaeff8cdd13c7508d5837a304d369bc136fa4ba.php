<?php

/* WebProfilerBundle:Profiler:open.html.twig */
class __TwigTemplate_4215492859ff851dd46248b460e126b3fb360a785635db52ff03b10fe3f09c0f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "WebProfilerBundle:Profiler:open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_35012b960529139c470e179ff1143b208b267f9255987f13b43e190b55ad4a92 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_35012b960529139c470e179ff1143b208b267f9255987f13b43e190b55ad4a92->enter($__internal_35012b960529139c470e179ff1143b208b267f9255987f13b43e190b55ad4a92_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $__internal_eeb9773437fae6c4ae1400786d8d0a11def5f8c371fc51748a42de7c85f11868 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eeb9773437fae6c4ae1400786d8d0a11def5f8c371fc51748a42de7c85f11868->enter($__internal_eeb9773437fae6c4ae1400786d8d0a11def5f8c371fc51748a42de7c85f11868_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_35012b960529139c470e179ff1143b208b267f9255987f13b43e190b55ad4a92->leave($__internal_35012b960529139c470e179ff1143b208b267f9255987f13b43e190b55ad4a92_prof);

        
        $__internal_eeb9773437fae6c4ae1400786d8d0a11def5f8c371fc51748a42de7c85f11868->leave($__internal_eeb9773437fae6c4ae1400786d8d0a11def5f8c371fc51748a42de7c85f11868_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_2fba9444469078320591290d807c1bbd204c3a110fcad183785d129fea96a4bd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2fba9444469078320591290d807c1bbd204c3a110fcad183785d129fea96a4bd->enter($__internal_2fba9444469078320591290d807c1bbd204c3a110fcad183785d129fea96a4bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_90779bafe12ce2d6d922e7419758da8be956012874d664af81072d6113b1e120 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_90779bafe12ce2d6d922e7419758da8be956012874d664af81072d6113b1e120->enter($__internal_90779bafe12ce2d6d922e7419758da8be956012874d664af81072d6113b1e120_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_90779bafe12ce2d6d922e7419758da8be956012874d664af81072d6113b1e120->leave($__internal_90779bafe12ce2d6d922e7419758da8be956012874d664af81072d6113b1e120_prof);

        
        $__internal_2fba9444469078320591290d807c1bbd204c3a110fcad183785d129fea96a4bd->leave($__internal_2fba9444469078320591290d807c1bbd204c3a110fcad183785d129fea96a4bd_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_714a453cfe6d77eb7b810109116a726d28ac706d792678e28b6a4531e838c696 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_714a453cfe6d77eb7b810109116a726d28ac706d792678e28b6a4531e838c696->enter($__internal_714a453cfe6d77eb7b810109116a726d28ac706d792678e28b6a4531e838c696_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_f51550bdcd31751732eee575a9b0beeb7c41036c583a492c3efc54e3c8fcb491 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f51550bdcd31751732eee575a9b0beeb7c41036c583a492c3efc54e3c8fcb491->enter($__internal_f51550bdcd31751732eee575a9b0beeb7c41036c583a492c3efc54e3c8fcb491_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, ($context["file"] ?? $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, ($context["line"] ?? $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt(($context["filename"] ?? $this->getContext($context, "filename")), ($context["line"] ?? $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_f51550bdcd31751732eee575a9b0beeb7c41036c583a492c3efc54e3c8fcb491->leave($__internal_f51550bdcd31751732eee575a9b0beeb7c41036c583a492c3efc54e3c8fcb491_prof);

        
        $__internal_714a453cfe6d77eb7b810109116a726d28ac706d792678e28b6a4531e838c696->leave($__internal_714a453cfe6d77eb7b810109116a726d28ac706d792678e28b6a4531e838c696_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "WebProfilerBundle:Profiler:open.html.twig", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/open.html.twig");
    }
}
