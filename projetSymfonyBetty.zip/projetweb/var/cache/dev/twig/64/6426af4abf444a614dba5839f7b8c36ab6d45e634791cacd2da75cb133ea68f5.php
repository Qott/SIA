<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_d53658b15e56fd14b303884d834c3407f4d01ff2e637535840b08a37fb3d1798 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7e93c613965ec1d30a938c247ca8f35291b3b9d9aa41af46278aee7feaff8099 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7e93c613965ec1d30a938c247ca8f35291b3b9d9aa41af46278aee7feaff8099->enter($__internal_7e93c613965ec1d30a938c247ca8f35291b3b9d9aa41af46278aee7feaff8099_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        $__internal_9ac6bbb0a7dada212e025fbd2a509e4a2b3968c782c7549f671ad1e8aa669f07 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9ac6bbb0a7dada212e025fbd2a509e4a2b3968c782c7549f671ad1e8aa669f07->enter($__internal_9ac6bbb0a7dada212e025fbd2a509e4a2b3968c782c7549f671ad1e8aa669f07_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_7e93c613965ec1d30a938c247ca8f35291b3b9d9aa41af46278aee7feaff8099->leave($__internal_7e93c613965ec1d30a938c247ca8f35291b3b9d9aa41af46278aee7feaff8099_prof);

        
        $__internal_9ac6bbb0a7dada212e025fbd2a509e4a2b3968c782c7549f671ad1e8aa669f07->leave($__internal_9ac6bbb0a7dada212e025fbd2a509e4a2b3968c782c7549f671ad1e8aa669f07_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
", "@Framework/Form/form_enctype.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_enctype.html.php");
    }
}
