<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_f5e276029df096f60f1d55e16bb79f27bb0e261287257bb8e74c790056fba810 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7ee56189ad59417fef1612e4221bc5e08d9780f2090eae643bed70d0a1d7b8d3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7ee56189ad59417fef1612e4221bc5e08d9780f2090eae643bed70d0a1d7b8d3->enter($__internal_7ee56189ad59417fef1612e4221bc5e08d9780f2090eae643bed70d0a1d7b8d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_1882578eec34a282eac9ade50a3e92c1a213a82b47a0bd41a100eae0e20a35c2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1882578eec34a282eac9ade50a3e92c1a213a82b47a0bd41a100eae0e20a35c2->enter($__internal_1882578eec34a282eac9ade50a3e92c1a213a82b47a0bd41a100eae0e20a35c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7ee56189ad59417fef1612e4221bc5e08d9780f2090eae643bed70d0a1d7b8d3->leave($__internal_7ee56189ad59417fef1612e4221bc5e08d9780f2090eae643bed70d0a1d7b8d3_prof);

        
        $__internal_1882578eec34a282eac9ade50a3e92c1a213a82b47a0bd41a100eae0e20a35c2->leave($__internal_1882578eec34a282eac9ade50a3e92c1a213a82b47a0bd41a100eae0e20a35c2_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_661027107c095e10e5d1d98d15c5031e8b6c7e540a73efcbe03934754ee2c26a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_661027107c095e10e5d1d98d15c5031e8b6c7e540a73efcbe03934754ee2c26a->enter($__internal_661027107c095e10e5d1d98d15c5031e8b6c7e540a73efcbe03934754ee2c26a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_ef888d7971ceb6a06ea7c27648590a744b39601f2a6aa0ba5dc70c7a233b814b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ef888d7971ceb6a06ea7c27648590a744b39601f2a6aa0ba5dc70c7a233b814b->enter($__internal_ef888d7971ceb6a06ea7c27648590a744b39601f2a6aa0ba5dc70c7a233b814b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_ef888d7971ceb6a06ea7c27648590a744b39601f2a6aa0ba5dc70c7a233b814b->leave($__internal_ef888d7971ceb6a06ea7c27648590a744b39601f2a6aa0ba5dc70c7a233b814b_prof);

        
        $__internal_661027107c095e10e5d1d98d15c5031e8b6c7e540a73efcbe03934754ee2c26a->leave($__internal_661027107c095e10e5d1d98d15c5031e8b6c7e540a73efcbe03934754ee2c26a_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_99d8bbd9991dc0f8316863ada4fdf129dcccc6d7ba018fc47c93aa80367ec8a9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_99d8bbd9991dc0f8316863ada4fdf129dcccc6d7ba018fc47c93aa80367ec8a9->enter($__internal_99d8bbd9991dc0f8316863ada4fdf129dcccc6d7ba018fc47c93aa80367ec8a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_e738cad3b515aada8ff0779f4a776ec4191b86440bc51e555225d4fb92636947 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e738cad3b515aada8ff0779f4a776ec4191b86440bc51e555225d4fb92636947->enter($__internal_e738cad3b515aada8ff0779f4a776ec4191b86440bc51e555225d4fb92636947_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_e738cad3b515aada8ff0779f4a776ec4191b86440bc51e555225d4fb92636947->leave($__internal_e738cad3b515aada8ff0779f4a776ec4191b86440bc51e555225d4fb92636947_prof);

        
        $__internal_99d8bbd9991dc0f8316863ada4fdf129dcccc6d7ba018fc47c93aa80367ec8a9->leave($__internal_99d8bbd9991dc0f8316863ada4fdf129dcccc6d7ba018fc47c93aa80367ec8a9_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_c5bf7a98eb79dc07c74cdf44a8b600f2a7e18eccea2bdf5178d93ba8d0a7092f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c5bf7a98eb79dc07c74cdf44a8b600f2a7e18eccea2bdf5178d93ba8d0a7092f->enter($__internal_c5bf7a98eb79dc07c74cdf44a8b600f2a7e18eccea2bdf5178d93ba8d0a7092f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_ac6bfa73eec86e85aa49f4b498c52ae63a6cc692ef17484765c9a0b804ab070b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ac6bfa73eec86e85aa49f4b498c52ae63a6cc692ef17484765c9a0b804ab070b->enter($__internal_ac6bfa73eec86e85aa49f4b498c52ae63a6cc692ef17484765c9a0b804ab070b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_ac6bfa73eec86e85aa49f4b498c52ae63a6cc692ef17484765c9a0b804ab070b->leave($__internal_ac6bfa73eec86e85aa49f4b498c52ae63a6cc692ef17484765c9a0b804ab070b_prof);

        
        $__internal_c5bf7a98eb79dc07c74cdf44a8b600f2a7e18eccea2bdf5178d93ba8d0a7092f->leave($__internal_c5bf7a98eb79dc07c74cdf44a8b600f2a7e18eccea2bdf5178d93ba8d0a7092f_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
