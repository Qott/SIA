<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_af0d7ffca172acc8290551e8da69fd63cb787d448b705003130cc80d19d83054 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4bbd3fc07f275afc4d9bd77259ae54123033772e89b37bcb4b7d7fda3b2315dd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4bbd3fc07f275afc4d9bd77259ae54123033772e89b37bcb4b7d7fda3b2315dd->enter($__internal_4bbd3fc07f275afc4d9bd77259ae54123033772e89b37bcb4b7d7fda3b2315dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        $__internal_7819b5a3681700fd2307c2096f1151f4fa05cb136b535be0be018692f33416a6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7819b5a3681700fd2307c2096f1151f4fa05cb136b535be0be018692f33416a6->enter($__internal_7819b5a3681700fd2307c2096f1151f4fa05cb136b535be0be018692f33416a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_4bbd3fc07f275afc4d9bd77259ae54123033772e89b37bcb4b7d7fda3b2315dd->leave($__internal_4bbd3fc07f275afc4d9bd77259ae54123033772e89b37bcb4b7d7fda3b2315dd_prof);

        
        $__internal_7819b5a3681700fd2307c2096f1151f4fa05cb136b535be0be018692f33416a6->leave($__internal_7819b5a3681700fd2307c2096f1151f4fa05cb136b535be0be018692f33416a6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
", "@Framework/Form/reset_widget.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/reset_widget.html.php");
    }
}
