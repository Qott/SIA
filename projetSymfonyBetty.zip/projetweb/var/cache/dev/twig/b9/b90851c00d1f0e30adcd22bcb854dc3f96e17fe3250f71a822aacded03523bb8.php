<?php

/* PWPoudlardBundle:Default:promener.html.twig */
class __TwigTemplate_e775c347d539c2058fa11be465b53d30d0d362c3d2eed04472ae026639294258 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("menu.html.twig", "PWPoudlardBundle:Default:promener.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "menu.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_05b48cf977f3662b32c37830e0c5fcfafc5bcfee08b173d01b4a8ef63ddf94a8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_05b48cf977f3662b32c37830e0c5fcfafc5bcfee08b173d01b4a8ef63ddf94a8->enter($__internal_05b48cf977f3662b32c37830e0c5fcfafc5bcfee08b173d01b4a8ef63ddf94a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PWPoudlardBundle:Default:promener.html.twig"));

        $__internal_872a342758c74d3d733c2da0247591e0f234b25bd951956e4a4869810a8436b4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_872a342758c74d3d733c2da0247591e0f234b25bd951956e4a4869810a8436b4->enter($__internal_872a342758c74d3d733c2da0247591e0f234b25bd951956e4a4869810a8436b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PWPoudlardBundle:Default:promener.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_05b48cf977f3662b32c37830e0c5fcfafc5bcfee08b173d01b4a8ef63ddf94a8->leave($__internal_05b48cf977f3662b32c37830e0c5fcfafc5bcfee08b173d01b4a8ef63ddf94a8_prof);

        
        $__internal_872a342758c74d3d733c2da0247591e0f234b25bd951956e4a4869810a8436b4->leave($__internal_872a342758c74d3d733c2da0247591e0f234b25bd951956e4a4869810a8436b4_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_ed2c25b8c199b9c0bf6c2dae8b9dd2204b3b496d4e28cab921606e0eb7e83bc7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ed2c25b8c199b9c0bf6c2dae8b9dd2204b3b496d4e28cab921606e0eb7e83bc7->enter($__internal_ed2c25b8c199b9c0bf6c2dae8b9dd2204b3b496d4e28cab921606e0eb7e83bc7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_4eb36e9d7a675d1921d0967f2600d2173f27502d625ec725b1d58c653769e0fe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4eb36e9d7a675d1921d0967f2600d2173f27502d625ec725b1d58c653769e0fe->enter($__internal_4eb36e9d7a675d1921d0967f2600d2173f27502d625ec725b1d58c653769e0fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Où souhaites-tu t'aventurer ?";
        
        $__internal_4eb36e9d7a675d1921d0967f2600d2173f27502d625ec725b1d58c653769e0fe->leave($__internal_4eb36e9d7a675d1921d0967f2600d2173f27502d625ec725b1d58c653769e0fe_prof);

        
        $__internal_ed2c25b8c199b9c0bf6c2dae8b9dd2204b3b496d4e28cab921606e0eb7e83bc7->leave($__internal_ed2c25b8c199b9c0bf6c2dae8b9dd2204b3b496d4e28cab921606e0eb7e83bc7_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_2faf813db8b62a0cb9a12306f865a570d2df58ab3032265732023704368af3fe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2faf813db8b62a0cb9a12306f865a570d2df58ab3032265732023704368af3fe->enter($__internal_2faf813db8b62a0cb9a12306f865a570d2df58ab3032265732023704368af3fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_6e619ff27492926a555a5ac48330d5462b2b136d1ae21ab53b5ea6213aa14b5f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6e619ff27492926a555a5ac48330d5462b2b136d1ae21ab53b5ea6213aa14b5f->enter($__internal_6e619ff27492926a555a5ac48330d5462b2b136d1ae21ab53b5ea6213aa14b5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "  <div class=\"container-fluid\">
    <div class=\"col-sm-4\">
      <a data-toggle=\"modal\" id=\"ecoleClick\">
        <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
          <form class=\"\" name=\"ecole_form\" action=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pw_poudlard_promener");
        echo "\" method=\"post\" id=\"ecole\">
            <input type=\"hidden\" name=\"ecole_name\" value=\"\">
            <h2 class=\"text-center\">Ecole</h2>
            <br>
            <img src=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("image/ecole.jpg"), "html", null, true);
        echo "\" alt=\"Ecole\" class=\"col-sm-12\" id=\"images\"/>
          </form>

          <script type=\"text/javascript\">
            \$(\"#ecoleClick\").click(function() {
              \$(\"#ecole\").submit();
            });
          </script>
        </div>
      </a>
    </div>

    <div class=\"col-sm-4\">
      <a data-toggle=\"modal\" id=\"lardClick\">
        <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
          <form class=\"\" name=\"lard_form\" action=\"";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pw_poudlard_promener");
        echo "\" method=\"post\" id=\"lard\">
            <input type=\"hidden\" name=\"lard_name\" value=\"\">
            <h2 class=\"text-center\">Pré-au-lard</h2>
            <img src=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("image/pre_au_lard.jpg"), "html", null, true);
        echo "\" alt=\"Pré au lard\" class=\"col-sm-12\" id=\"images\"/>
            <br>
            <p class=\"text-center\" id=\"attention\">Attention ! Ne t'y aventures pas avant le niveau 3 !</p>
          </form>

          <script type=\"text/javascript\">
            \$(\"#lardClick\").click(function() {
              \$(\"#lard\").submit();
            });
          </script>
        </div>
      </a>
    </div>

    <div class=\"col-sm-4\">
      <a data-toggle=\"modal\" id=\"foretClick\">
        <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
          <form class=\"\" name=\"foret_form\" action=\"";
        // line 49
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pw_poudlard_promener");
        echo "\" method=\"post\" id=\"foret\">
            <input type=\"hidden\" name=\"foret_name\" value=\"\">
            <h2 class=\"text-center\">Forêt interdite</h2>
            <br>
            <img src=\"";
        // line 53
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("image/foret_interdite.jpg"), "html", null, true);
        echo "\" alt=\"Forêt interdite\" class=\"col-sm-12\" id=\"images\"/>
          </form>

          <script type=\"text/javascript\">
            \$(\"#foretClick\").click(function() {
              \$(\"#foret\").submit();
            });
          </script>
        </div>
      </a>
    </div>
  </div>

  <div id=\"modal_ecole\" class=\"modal fade\" role=\"dialog\">
    <div class=\"modal-dialog\">
      <div class=\"modal-content\">
        <div class=\"modal-body\">
          <p>
            ";
        // line 71
        $context["r"] = twig_random($this->env, array(0 => "Viande", 1 => "Bois", 2 => ""));
        // line 72
        echo "            ";
        if ((($context["r"] ?? $this->getContext($context, "r")) == "")) {
            // line 73
            echo "              Tu n'as rien trouvé, mais c'était une jolie balade !
            ";
        } else {
            // line 75
            echo "              Bravo, tu as trouvé : ";
            echo twig_escape_filter($this->env, ($context["r"] ?? $this->getContext($context, "r")), "html", null, true);
            echo " !
              ";
            // line 76
            if ((($context["r"] ?? $this->getContext($context, "r")) == "Viande")) {
                // line 77
                echo "                <script type=\"text/javascript\">
                  document.forms[\"ecole_form\"].elements[\"ecole_name\"].value = \"0\";
                </script>
              ";
            }
            // line 81
            echo "              ";
            if ((($context["r"] ?? $this->getContext($context, "r")) == "Bois")) {
                // line 82
                echo "                <script type=\"text/javascript\">
                  document.forms[\"ecole_form\"].elements[\"ecole_name\"].value = \"1\";
                </script>
              ";
            }
            // line 86
            echo "            ";
        }
        // line 87
        echo "          </p>
        </div>
        <div class=\"modal-footer\">
          <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" onclick=\"fermeModal('modal_ecole');\">Fermer</button>
        </div>
      </div>
    </div>
  </div>

  <div id=\"modal_pre_au_lard\" class=\"modal fade\" role=\"dialog\">
    <div class=\"modal-dialog\">
      <div class=\"modal-content\">
        <div class=\"modal-body\">
          <p>
            ";
        // line 101
        $context["p"] = twig_random($this->env, array(0 => "Cape", 1 => "Jouet", 2 => ""));
        // line 102
        echo "            ";
        if ((($context["p"] ?? $this->getContext($context, "p")) == "")) {
            // line 103
            echo "              Tu n'as rien trouvé, mais c'était une jolie balade !
            ";
        } else {
            // line 105
            echo "              Chouette ! Tu as trouvé : ";
            echo twig_escape_filter($this->env, ($context["p"] ?? $this->getContext($context, "p")), "html", null, true);
            echo " !
              ";
            // line 106
            if ((($context["p"] ?? $this->getContext($context, "p")) == "Cape")) {
                // line 107
                echo "                <script type=\"text/javascript\">
                  document.forms[\"lard_form\"].elements[\"lard_name\"].value = \"2\";
                </script>
              ";
            }
            // line 111
            echo "              ";
            if ((($context["p"] ?? $this->getContext($context, "p")) == "Jouet")) {
                // line 112
                echo "                <script type=\"text/javascript\">
                  document.forms[\"lard_form\"].elements[\"lard_name\"].value = \"3\";
                </script>
              ";
            }
            // line 116
            echo "            ";
        }
        // line 117
        echo "          </p>
        </div>
        <div class=\"modal-footer\">
          <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" onclick=\"fermeModal('modal_pre_au_lard');\">Fermer</button>
        </div>
      </div>
    </div>
  </div>

  <div id=\"modal_foret_interdite\" class=\"modal fade\" role=\"dialog\">
    <div class=\"modal-dialog\">
      <div class=\"modal-content\">
        <div class=\"modal-body\">
          <p>
            ";
        // line 131
        $context["s"] = twig_random($this->env, array(0 => "Cape", 1 => "Jouet"));
        // line 132
        echo "            Chouette ! Tu as trouvé : ";
        echo twig_escape_filter($this->env, ($context["s"] ?? $this->getContext($context, "s")), "html", null, true);
        echo " !<br>
            ";
        // line 133
        if ((($context["s"] ?? $this->getContext($context, "s")) == "Cape")) {
            // line 134
            echo "              <script type=\"text/javascript\">
                document.forms[\"foret_form\"].elements[\"foret_name\"].value = \"2\";
              </script>
            ";
        }
        // line 138
        echo "            ";
        if ((($context["s"] ?? $this->getContext($context, "s")) == "Jouet")) {
            // line 139
            echo "              <script type=\"text/javascript\">
                document.forms[\"foret_form\"].elements[\"foret_name\"].value = \"3\";
              </script>
            ";
        }
        // line 143
        echo "            Malheureusement, un professeur t'a vu !<br>
            Tu perds 5 points
          </p>
        </div>
        <div class=\"modal-footer\">
          <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" onclick=\"fermeModal('modal_foret_interdite');\">Fermer</button>
        </div>
      </div>
    </div>
  </div>
  <script type=\"text/javascript\">
    function fermeModal(idSupp) {
      \$(\"#\"+idSupp).css('display', 'none');
    }
  </script>
";
        
        $__internal_6e619ff27492926a555a5ac48330d5462b2b136d1ae21ab53b5ea6213aa14b5f->leave($__internal_6e619ff27492926a555a5ac48330d5462b2b136d1ae21ab53b5ea6213aa14b5f_prof);

        
        $__internal_2faf813db8b62a0cb9a12306f865a570d2df58ab3032265732023704368af3fe->leave($__internal_2faf813db8b62a0cb9a12306f865a570d2df58ab3032265732023704368af3fe_prof);

    }

    public function getTemplateName()
    {
        return "PWPoudlardBundle:Default:promener.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  277 => 143,  271 => 139,  268 => 138,  262 => 134,  260 => 133,  255 => 132,  253 => 131,  237 => 117,  234 => 116,  228 => 112,  225 => 111,  219 => 107,  217 => 106,  212 => 105,  208 => 103,  205 => 102,  203 => 101,  187 => 87,  184 => 86,  178 => 82,  175 => 81,  169 => 77,  167 => 76,  162 => 75,  158 => 73,  155 => 72,  153 => 71,  132 => 53,  125 => 49,  105 => 32,  99 => 29,  81 => 14,  74 => 10,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"menu.html.twig\" %}

{% block title %}Où souhaites-tu t'aventurer ?{% endblock %}

{% block body %}
  <div class=\"container-fluid\">
    <div class=\"col-sm-4\">
      <a data-toggle=\"modal\" id=\"ecoleClick\">
        <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
          <form class=\"\" name=\"ecole_form\" action=\"{{ path(\"pw_poudlard_promener\") }}\" method=\"post\" id=\"ecole\">
            <input type=\"hidden\" name=\"ecole_name\" value=\"\">
            <h2 class=\"text-center\">Ecole</h2>
            <br>
            <img src=\"{{ asset(\"image/ecole.jpg\") }}\" alt=\"Ecole\" class=\"col-sm-12\" id=\"images\"/>
          </form>

          <script type=\"text/javascript\">
            \$(\"#ecoleClick\").click(function() {
              \$(\"#ecole\").submit();
            });
          </script>
        </div>
      </a>
    </div>

    <div class=\"col-sm-4\">
      <a data-toggle=\"modal\" id=\"lardClick\">
        <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
          <form class=\"\" name=\"lard_form\" action=\"{{ path(\"pw_poudlard_promener\") }}\" method=\"post\" id=\"lard\">
            <input type=\"hidden\" name=\"lard_name\" value=\"\">
            <h2 class=\"text-center\">Pré-au-lard</h2>
            <img src=\"{{ asset(\"image/pre_au_lard.jpg\") }}\" alt=\"Pré au lard\" class=\"col-sm-12\" id=\"images\"/>
            <br>
            <p class=\"text-center\" id=\"attention\">Attention ! Ne t'y aventures pas avant le niveau 3 !</p>
          </form>

          <script type=\"text/javascript\">
            \$(\"#lardClick\").click(function() {
              \$(\"#lard\").submit();
            });
          </script>
        </div>
      </a>
    </div>

    <div class=\"col-sm-4\">
      <a data-toggle=\"modal\" id=\"foretClick\">
        <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
          <form class=\"\" name=\"foret_form\" action=\"{{ path(\"pw_poudlard_promener\") }}\" method=\"post\" id=\"foret\">
            <input type=\"hidden\" name=\"foret_name\" value=\"\">
            <h2 class=\"text-center\">Forêt interdite</h2>
            <br>
            <img src=\"{{ asset(\"image/foret_interdite.jpg\") }}\" alt=\"Forêt interdite\" class=\"col-sm-12\" id=\"images\"/>
          </form>

          <script type=\"text/javascript\">
            \$(\"#foretClick\").click(function() {
              \$(\"#foret\").submit();
            });
          </script>
        </div>
      </a>
    </div>
  </div>

  <div id=\"modal_ecole\" class=\"modal fade\" role=\"dialog\">
    <div class=\"modal-dialog\">
      <div class=\"modal-content\">
        <div class=\"modal-body\">
          <p>
            {% set r = random([\"Viande\", \"Bois\", \"\"]) %}
            {% if r == \"\" %}
              Tu n'as rien trouvé, mais c'était une jolie balade !
            {% else %}
              Bravo, tu as trouvé : {{ r }} !
              {% if r == \"Viande\" %}
                <script type=\"text/javascript\">
                  document.forms[\"ecole_form\"].elements[\"ecole_name\"].value = \"0\";
                </script>
              {% endif %}
              {% if r == \"Bois\" %}
                <script type=\"text/javascript\">
                  document.forms[\"ecole_form\"].elements[\"ecole_name\"].value = \"1\";
                </script>
              {% endif %}
            {% endif %}
          </p>
        </div>
        <div class=\"modal-footer\">
          <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" onclick=\"fermeModal('modal_ecole');\">Fermer</button>
        </div>
      </div>
    </div>
  </div>

  <div id=\"modal_pre_au_lard\" class=\"modal fade\" role=\"dialog\">
    <div class=\"modal-dialog\">
      <div class=\"modal-content\">
        <div class=\"modal-body\">
          <p>
            {% set p = random([\"Cape\", \"Jouet\", \"\"]) %}
            {% if p == \"\" %}
              Tu n'as rien trouvé, mais c'était une jolie balade !
            {% else %}
              Chouette ! Tu as trouvé : {{ p }} !
              {% if p == \"Cape\" %}
                <script type=\"text/javascript\">
                  document.forms[\"lard_form\"].elements[\"lard_name\"].value = \"2\";
                </script>
              {% endif %}
              {% if p == \"Jouet\" %}
                <script type=\"text/javascript\">
                  document.forms[\"lard_form\"].elements[\"lard_name\"].value = \"3\";
                </script>
              {% endif %}
            {% endif %}
          </p>
        </div>
        <div class=\"modal-footer\">
          <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" onclick=\"fermeModal('modal_pre_au_lard');\">Fermer</button>
        </div>
      </div>
    </div>
  </div>

  <div id=\"modal_foret_interdite\" class=\"modal fade\" role=\"dialog\">
    <div class=\"modal-dialog\">
      <div class=\"modal-content\">
        <div class=\"modal-body\">
          <p>
            {% set s = random([\"Cape\", \"Jouet\"]) %}
            Chouette ! Tu as trouvé : {{ s }} !<br>
            {% if s == \"Cape\" %}
              <script type=\"text/javascript\">
                document.forms[\"foret_form\"].elements[\"foret_name\"].value = \"2\";
              </script>
            {% endif %}
            {% if s == \"Jouet\" %}
              <script type=\"text/javascript\">
                document.forms[\"foret_form\"].elements[\"foret_name\"].value = \"3\";
              </script>
            {% endif %}
            Malheureusement, un professeur t'a vu !<br>
            Tu perds 5 points
          </p>
        </div>
        <div class=\"modal-footer\">
          <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" onclick=\"fermeModal('modal_foret_interdite');\">Fermer</button>
        </div>
      </div>
    </div>
  </div>
  <script type=\"text/javascript\">
    function fermeModal(idSupp) {
      \$(\"#\"+idSupp).css('display', 'none');
    }
  </script>
{% endblock %}
", "PWPoudlardBundle:Default:promener.html.twig", "/home/betty/S6/PW6/projetweb/projetweb/src/PW/PoudlardBundle/Resources/views/Default/promener.html.twig");
    }
}
