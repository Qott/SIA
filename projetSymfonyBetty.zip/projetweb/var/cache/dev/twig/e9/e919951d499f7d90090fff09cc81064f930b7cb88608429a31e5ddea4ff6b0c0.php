<?php

/* @Framework/Form/button_widget.html.php */
class __TwigTemplate_632777faee52521f52599050204e98e151d10f6d29fd60284f7ce50b679bef62 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_74e510cca20e92419a27ffc28488b2b9d622e0c9ca8a7bb7349171e513e3d7b0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_74e510cca20e92419a27ffc28488b2b9d622e0c9ca8a7bb7349171e513e3d7b0->enter($__internal_74e510cca20e92419a27ffc28488b2b9d622e0c9ca8a7bb7349171e513e3d7b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_widget.html.php"));

        $__internal_a3c176ec1207321d1545c1bd950b689f1fdc66790c1f5e4ddc6ad27da6568986 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a3c176ec1207321d1545c1bd950b689f1fdc66790c1f5e4ddc6ad27da6568986->enter($__internal_a3c176ec1207321d1545c1bd950b689f1fdc66790c1f5e4ddc6ad27da6568986_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_widget.html.php"));

        // line 1
        echo "<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<button type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'button' ?>\" <?php echo \$view['form']->block(\$form, 'button_attributes') ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></button>
";
        
        $__internal_74e510cca20e92419a27ffc28488b2b9d622e0c9ca8a7bb7349171e513e3d7b0->leave($__internal_74e510cca20e92419a27ffc28488b2b9d622e0c9ca8a7bb7349171e513e3d7b0_prof);

        
        $__internal_a3c176ec1207321d1545c1bd950b689f1fdc66790c1f5e4ddc6ad27da6568986->leave($__internal_a3c176ec1207321d1545c1bd950b689f1fdc66790c1f5e4ddc6ad27da6568986_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<button type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'button' ?>\" <?php echo \$view['form']->block(\$form, 'button_attributes') ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></button>
", "@Framework/Form/button_widget.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_widget.html.php");
    }
}
