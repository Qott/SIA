<?php

/* PWPoudlardBundle:Default:boutique.html.twig */
class __TwigTemplate_5be5f266a8952105f8b37ac9747a5366a08c093e3db10245e4bd612b5f7fc3ff extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("menu.html.twig", "PWPoudlardBundle:Default:boutique.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "menu.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d8f38d03d3da9007a13eae060fa1f6fed94c9b98715f77b8eea75b1d23fb9c57 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d8f38d03d3da9007a13eae060fa1f6fed94c9b98715f77b8eea75b1d23fb9c57->enter($__internal_d8f38d03d3da9007a13eae060fa1f6fed94c9b98715f77b8eea75b1d23fb9c57_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PWPoudlardBundle:Default:boutique.html.twig"));

        $__internal_e8ded9341f4d9cc0b9c50ef485751dc99f1cec1f9525b09ec94a688d0b73c0f0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e8ded9341f4d9cc0b9c50ef485751dc99f1cec1f9525b09ec94a688d0b73c0f0->enter($__internal_e8ded9341f4d9cc0b9c50ef485751dc99f1cec1f9525b09ec94a688d0b73c0f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PWPoudlardBundle:Default:boutique.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d8f38d03d3da9007a13eae060fa1f6fed94c9b98715f77b8eea75b1d23fb9c57->leave($__internal_d8f38d03d3da9007a13eae060fa1f6fed94c9b98715f77b8eea75b1d23fb9c57_prof);

        
        $__internal_e8ded9341f4d9cc0b9c50ef485751dc99f1cec1f9525b09ec94a688d0b73c0f0->leave($__internal_e8ded9341f4d9cc0b9c50ef485751dc99f1cec1f9525b09ec94a688d0b73c0f0_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_2afbe7d99ace8d745ec51224cf98333cde4b7d1b4254ccf7d59587640c2a0b68 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2afbe7d99ace8d745ec51224cf98333cde4b7d1b4254ccf7d59587640c2a0b68->enter($__internal_2afbe7d99ace8d745ec51224cf98333cde4b7d1b4254ccf7d59587640c2a0b68_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_4c434388c01f3d0d7d4fbef85ec27e5bc37d53c936d848c31fe6b7675e5b9bc4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4c434388c01f3d0d7d4fbef85ec27e5bc37d53c936d848c31fe6b7675e5b9bc4->enter($__internal_4c434388c01f3d0d7d4fbef85ec27e5bc37d53c936d848c31fe6b7675e5b9bc4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "  Boutique
";
        
        $__internal_4c434388c01f3d0d7d4fbef85ec27e5bc37d53c936d848c31fe6b7675e5b9bc4->leave($__internal_4c434388c01f3d0d7d4fbef85ec27e5bc37d53c936d848c31fe6b7675e5b9bc4_prof);

        
        $__internal_2afbe7d99ace8d745ec51224cf98333cde4b7d1b4254ccf7d59587640c2a0b68->leave($__internal_2afbe7d99ace8d745ec51224cf98333cde4b7d1b4254ccf7d59587640c2a0b68_prof);

    }

    // line 7
    public function block_body($context, array $blocks = array())
    {
        $__internal_a5fde86f333c6f5533ce34234a4762571850916a4126eb57c11bbcb5fd127af6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a5fde86f333c6f5533ce34234a4762571850916a4126eb57c11bbcb5fd127af6->enter($__internal_a5fde86f333c6f5533ce34234a4762571850916a4126eb57c11bbcb5fd127af6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_ce340eab04da2dd554341d228a5c7307141ad5dad478ec84b6f8bd0a5a081ba2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ce340eab04da2dd554341d228a5c7307141ad5dad478ec84b6f8bd0a5a081ba2->enter($__internal_ce340eab04da2dd554341d228a5c7307141ad5dad478ec84b6f8bd0a5a081ba2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 8
        echo "  <div class=\"container-fluid col-sm-10 col-sm-push-1\">
    <h3 id=\"information\"></h3>
    <form class=\"\" name=\"formulaire_boutique\" action=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pw_poudlard_boutique");
        echo "\" method=\"post\">
      <table class=\"table\" id=\"body_color\">
        <thead>
          <tr>
            <td><h3>Articles</h3></td>
            <td><h3>Modèles</h3></td>
            <td><h3>Photos</h3></td>
            <td><h3>Prix</h3></td>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Livres (tous niveaux)</td>
            <td>
              <input type=\"checkbox\" class=\"livre\" name=\"potions\" onclick=\"prixTotal()\"/> <label>Potions</label><br>
              <input type=\"checkbox\" class=\"livre\" name=\"defense\" onclick=\"prixTotal()\"/> <label>Défense contre les forces du mal</label><br>
              <input type=\"checkbox\" class=\"livre\" name=\"divination\" onclick=\"prixTotal()\"/> <label>Divination</label><br>
              <input type=\"checkbox\" class=\"livre\" name=\"magique\" onclick=\"prixTotal()\"/> <label>Soins aux créatures magiques</label><br>
              <input type=\"checkbox\" class=\"livre\" name=\"botanique\" onclick=\"prixTotal()\"/> <label>Botanique</label><br>
              <input type=\"checkbox\" class=\"livre\" name=\"sort\" onclick=\"prixTotal()\"/> <label>Sortilèges</label><br>
            </td>
            <td>
              <img src=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("image/livre.jpg"), "html", null, true);
        echo "\" alt=\"Livre\" id=\"articles\"/>
            </td>
            <td>
              3 mornilles
            </td>
          </tr>
          <tr>
            <td>Balais</td>
            <td>
              <input type=\"checkbox\" class=\"balais\" name=\"nimbus\" onclick=\"prixTotal()\"/> <label>Nimbus 2000</label><br>
              <input type=\"checkbox\" class=\"balais\" name=\"feu\" onclick=\"prixTotal()\"/> <label>Eclair de feu</label><br>
            </td>
            <td>
              <img src=\"";
        // line 45
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("image/balai.jpg"), "html", null, true);
        echo "\" alt=\"Balais\" id=\"articles\"/>
            </td>
            <td>
              15 mornilles
            </td>
          </tr>
          <tr>
            <td>Baguette</td>
            <td>
              <input type=\"checkbox\" class=\"baguette\" name=\"dragon\" onclick=\"prixTotal()\"/> <label>Baguette en cyprès et ventricule de dragon</label><br>
              <input type=\"checkbox\" class=\"baguette\" name=\"phoenix\" onclick=\"prixTotal()\"/> <label>Baguette en sureau et plume de phénix</label><br>
            </td>
            <td>
              <img src=\"";
        // line 58
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("image/baguette.jpg"), "html", null, true);
        echo "\" alt=\"Baguette\" id=\"articles\"/>
            </td>
            <td>
              6 mornilles
            </td>
          </tr>
        </tbody>
      </table>
      <input type=\"hidden\" name=\"prix\" value=\"\">
      <div class=\"row\">
        <p class=\"text-center col-sm-2 col-sm-push-5\" id=\"total\">Total : 0 mornille</p>
      </div>
      <div class=\"row text-center\">
        <input type=\"submit\" name=\"boutique\" value=\"Acheter\"/>
      </div>
    </form>

    <script type=\"text/javascript\">
      function prixTotal() {
        var total = 0;
        var tab = document.getElementsByClassName(\"livre\");
        for(var i = 0; i < tab.length; i++) {
          if(tab[i].checked)
            total = total + 3;
        }
        tab = document.getElementsByClassName(\"balais\");
        for(var i = 0; i < tab.length; i++) {
          if(tab[i].checked)
            total = total + 15;
        }
        tab = document.getElementsByClassName(\"baguette\");
        for(var i = 0; i < tab.length; i++) {
          if(tab[i].checked)
            total = total + 6;
        }
        document.getElementById(\"total\").innerHTML = \"Total : \" + total + \" mornille\" + (total > 1 ? \"s\" : \"\");
        document.forms[\"formulaire_boutique\"].elements[\"prix\"].value = total.toString();
      }
    </script>
  </div>
";
        
        $__internal_ce340eab04da2dd554341d228a5c7307141ad5dad478ec84b6f8bd0a5a081ba2->leave($__internal_ce340eab04da2dd554341d228a5c7307141ad5dad478ec84b6f8bd0a5a081ba2_prof);

        
        $__internal_a5fde86f333c6f5533ce34234a4762571850916a4126eb57c11bbcb5fd127af6->leave($__internal_a5fde86f333c6f5533ce34234a4762571850916a4126eb57c11bbcb5fd127af6_prof);

    }

    public function getTemplateName()
    {
        return "PWPoudlardBundle:Default:boutique.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  131 => 58,  115 => 45,  99 => 32,  74 => 10,  70 => 8,  61 => 7,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"menu.html.twig\" %}

{% block title %}
  Boutique
{% endblock %}

{% block body %}
  <div class=\"container-fluid col-sm-10 col-sm-push-1\">
    <h3 id=\"information\"></h3>
    <form class=\"\" name=\"formulaire_boutique\" action=\"{{ path(\"pw_poudlard_boutique\") }}\" method=\"post\">
      <table class=\"table\" id=\"body_color\">
        <thead>
          <tr>
            <td><h3>Articles</h3></td>
            <td><h3>Modèles</h3></td>
            <td><h3>Photos</h3></td>
            <td><h3>Prix</h3></td>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Livres (tous niveaux)</td>
            <td>
              <input type=\"checkbox\" class=\"livre\" name=\"potions\" onclick=\"prixTotal()\"/> <label>Potions</label><br>
              <input type=\"checkbox\" class=\"livre\" name=\"defense\" onclick=\"prixTotal()\"/> <label>Défense contre les forces du mal</label><br>
              <input type=\"checkbox\" class=\"livre\" name=\"divination\" onclick=\"prixTotal()\"/> <label>Divination</label><br>
              <input type=\"checkbox\" class=\"livre\" name=\"magique\" onclick=\"prixTotal()\"/> <label>Soins aux créatures magiques</label><br>
              <input type=\"checkbox\" class=\"livre\" name=\"botanique\" onclick=\"prixTotal()\"/> <label>Botanique</label><br>
              <input type=\"checkbox\" class=\"livre\" name=\"sort\" onclick=\"prixTotal()\"/> <label>Sortilèges</label><br>
            </td>
            <td>
              <img src=\"{{ asset(\"image/livre.jpg\") }}\" alt=\"Livre\" id=\"articles\"/>
            </td>
            <td>
              3 mornilles
            </td>
          </tr>
          <tr>
            <td>Balais</td>
            <td>
              <input type=\"checkbox\" class=\"balais\" name=\"nimbus\" onclick=\"prixTotal()\"/> <label>Nimbus 2000</label><br>
              <input type=\"checkbox\" class=\"balais\" name=\"feu\" onclick=\"prixTotal()\"/> <label>Eclair de feu</label><br>
            </td>
            <td>
              <img src=\"{{ asset(\"image/balai.jpg\") }}\" alt=\"Balais\" id=\"articles\"/>
            </td>
            <td>
              15 mornilles
            </td>
          </tr>
          <tr>
            <td>Baguette</td>
            <td>
              <input type=\"checkbox\" class=\"baguette\" name=\"dragon\" onclick=\"prixTotal()\"/> <label>Baguette en cyprès et ventricule de dragon</label><br>
              <input type=\"checkbox\" class=\"baguette\" name=\"phoenix\" onclick=\"prixTotal()\"/> <label>Baguette en sureau et plume de phénix</label><br>
            </td>
            <td>
              <img src=\"{{ asset(\"image/baguette.jpg\") }}\" alt=\"Baguette\" id=\"articles\"/>
            </td>
            <td>
              6 mornilles
            </td>
          </tr>
        </tbody>
      </table>
      <input type=\"hidden\" name=\"prix\" value=\"\">
      <div class=\"row\">
        <p class=\"text-center col-sm-2 col-sm-push-5\" id=\"total\">Total : 0 mornille</p>
      </div>
      <div class=\"row text-center\">
        <input type=\"submit\" name=\"boutique\" value=\"Acheter\"/>
      </div>
    </form>

    <script type=\"text/javascript\">
      function prixTotal() {
        var total = 0;
        var tab = document.getElementsByClassName(\"livre\");
        for(var i = 0; i < tab.length; i++) {
          if(tab[i].checked)
            total = total + 3;
        }
        tab = document.getElementsByClassName(\"balais\");
        for(var i = 0; i < tab.length; i++) {
          if(tab[i].checked)
            total = total + 15;
        }
        tab = document.getElementsByClassName(\"baguette\");
        for(var i = 0; i < tab.length; i++) {
          if(tab[i].checked)
            total = total + 6;
        }
        document.getElementById(\"total\").innerHTML = \"Total : \" + total + \" mornille\" + (total > 1 ? \"s\" : \"\");
        document.forms[\"formulaire_boutique\"].elements[\"prix\"].value = total.toString();
      }
    </script>
  </div>
{% endblock %}
", "PWPoudlardBundle:Default:boutique.html.twig", "/home/betty/S6/PW6/projetweb/projetweb/src/PW/PoudlardBundle/Resources/views/Default/boutique.html.twig");
    }
}
