<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_67641477698b6eea2e6bbfd3a74b45911356d91d77869b652912de882954c17f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e233dcc7a8aff9c4340f1ede4a7da0ca11d69ff5a87b7930917c40cebe56d5fe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e233dcc7a8aff9c4340f1ede4a7da0ca11d69ff5a87b7930917c40cebe56d5fe->enter($__internal_e233dcc7a8aff9c4340f1ede4a7da0ca11d69ff5a87b7930917c40cebe56d5fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        $__internal_339fbe503f27497afeedede49b03959cb7aa7071a1f4172e0e07701114fe3333 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_339fbe503f27497afeedede49b03959cb7aa7071a1f4172e0e07701114fe3333->enter($__internal_339fbe503f27497afeedede49b03959cb7aa7071a1f4172e0e07701114fe3333_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_e233dcc7a8aff9c4340f1ede4a7da0ca11d69ff5a87b7930917c40cebe56d5fe->leave($__internal_e233dcc7a8aff9c4340f1ede4a7da0ca11d69ff5a87b7930917c40cebe56d5fe_prof);

        
        $__internal_339fbe503f27497afeedede49b03959cb7aa7071a1f4172e0e07701114fe3333->leave($__internal_339fbe503f27497afeedede49b03959cb7aa7071a1f4172e0e07701114fe3333_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?> %
", "@Framework/Form/percent_widget.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/percent_widget.html.php");
    }
}
