<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_740a1e675171eae31fdc33a6b2ec07b9a03970286eb59464e27fc1f696422796 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_06ca625920381e2236cc8461bcce0ffad49d026af859f2ed37c8cb6b89fc47f9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_06ca625920381e2236cc8461bcce0ffad49d026af859f2ed37c8cb6b89fc47f9->enter($__internal_06ca625920381e2236cc8461bcce0ffad49d026af859f2ed37c8cb6b89fc47f9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        $__internal_957645d31c975a16c15c2e8dbdc5eb4dbd9b5b0db824c1d411fda7bfded3440f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_957645d31c975a16c15c2e8dbdc5eb4dbd9b5b0db824c1d411fda7bfded3440f->enter($__internal_957645d31c975a16c15c2e8dbdc5eb4dbd9b5b0db824c1d411fda7bfded3440f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_06ca625920381e2236cc8461bcce0ffad49d026af859f2ed37c8cb6b89fc47f9->leave($__internal_06ca625920381e2236cc8461bcce0ffad49d026af859f2ed37c8cb6b89fc47f9_prof);

        
        $__internal_957645d31c975a16c15c2e8dbdc5eb4dbd9b5b0db824c1d411fda7bfded3440f->leave($__internal_957645d31c975a16c15c2e8dbdc5eb4dbd9b5b0db824c1d411fda7bfded3440f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
", "@Framework/Form/hidden_widget.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/hidden_widget.html.php");
    }
}
