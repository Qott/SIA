<?php

/* @Framework/Form/money_widget.html.php */
class __TwigTemplate_2722426e46d50e4e427c4443770abf2394fe69258026c8e8f06233e47d4f859b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5cba91a59a7234cb8185169e3efc70db82123e37141dd28e378d15b4078293d5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5cba91a59a7234cb8185169e3efc70db82123e37141dd28e378d15b4078293d5->enter($__internal_5cba91a59a7234cb8185169e3efc70db82123e37141dd28e378d15b4078293d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/money_widget.html.php"));

        $__internal_1be639110136372dcd0a2eea006900ed82448ca074572d01541e282f8e78b588 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1be639110136372dcd0a2eea006900ed82448ca074572d01541e282f8e78b588->enter($__internal_1be639110136372dcd0a2eea006900ed82448ca074572d01541e282f8e78b588_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/money_widget.html.php"));

        // line 1
        echo "<?php echo str_replace('";
        echo twig_escape_filter($this->env, ($context["widget"] ?? $this->getContext($context, "widget")), "html", null, true);
        echo "', \$view['form']->block(\$form, 'form_widget_simple'), \$money_pattern) ?>
";
        
        $__internal_5cba91a59a7234cb8185169e3efc70db82123e37141dd28e378d15b4078293d5->leave($__internal_5cba91a59a7234cb8185169e3efc70db82123e37141dd28e378d15b4078293d5_prof);

        
        $__internal_1be639110136372dcd0a2eea006900ed82448ca074572d01541e282f8e78b588->leave($__internal_1be639110136372dcd0a2eea006900ed82448ca074572d01541e282f8e78b588_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/money_widget.html.php";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo str_replace('{{ widget }}', \$view['form']->block(\$form, 'form_widget_simple'), \$money_pattern) ?>
", "@Framework/Form/money_widget.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/money_widget.html.php");
    }
}
