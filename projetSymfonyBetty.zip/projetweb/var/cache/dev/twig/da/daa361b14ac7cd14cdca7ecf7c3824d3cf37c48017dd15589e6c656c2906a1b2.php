<?php

/* PWPoudlardBundle:Default:service.html.twig */
class __TwigTemplate_ea38912653c64aafc53de41e82816df958b515db620aed4cbd7b352ad26aba88 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("menu.html.twig", "PWPoudlardBundle:Default:service.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "menu.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cf1ad073a77d02f310dd2092ef8336766448ba99d93ce74883959d4f610ed415 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cf1ad073a77d02f310dd2092ef8336766448ba99d93ce74883959d4f610ed415->enter($__internal_cf1ad073a77d02f310dd2092ef8336766448ba99d93ce74883959d4f610ed415_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PWPoudlardBundle:Default:service.html.twig"));

        $__internal_4777a91c9d355166eaabd69e2b7f8764ec73ae4ba87fbfc6de54faf8946a2892 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4777a91c9d355166eaabd69e2b7f8764ec73ae4ba87fbfc6de54faf8946a2892->enter($__internal_4777a91c9d355166eaabd69e2b7f8764ec73ae4ba87fbfc6de54faf8946a2892_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PWPoudlardBundle:Default:service.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_cf1ad073a77d02f310dd2092ef8336766448ba99d93ce74883959d4f610ed415->leave($__internal_cf1ad073a77d02f310dd2092ef8336766448ba99d93ce74883959d4f610ed415_prof);

        
        $__internal_4777a91c9d355166eaabd69e2b7f8764ec73ae4ba87fbfc6de54faf8946a2892->leave($__internal_4777a91c9d355166eaabd69e2b7f8764ec73ae4ba87fbfc6de54faf8946a2892_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_83ba9ccac17c0d51ec9e078e85c338e47d2a493c77b67970aee14236f6cb5ee7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_83ba9ccac17c0d51ec9e078e85c338e47d2a493c77b67970aee14236f6cb5ee7->enter($__internal_83ba9ccac17c0d51ec9e078e85c338e47d2a493c77b67970aee14236f6cb5ee7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_b7af7499caa02f01a4e54ce27e93230bfd7e41de256a0187a12d4a6122033aef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b7af7499caa02f01a4e54ce27e93230bfd7e41de256a0187a12d4a6122033aef->enter($__internal_b7af7499caa02f01a4e54ce27e93230bfd7e41de256a0187a12d4a6122033aef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Rends un service à Hagrid";
        
        $__internal_b7af7499caa02f01a4e54ce27e93230bfd7e41de256a0187a12d4a6122033aef->leave($__internal_b7af7499caa02f01a4e54ce27e93230bfd7e41de256a0187a12d4a6122033aef_prof);

        
        $__internal_83ba9ccac17c0d51ec9e078e85c338e47d2a493c77b67970aee14236f6cb5ee7->leave($__internal_83ba9ccac17c0d51ec9e078e85c338e47d2a493c77b67970aee14236f6cb5ee7_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_617d66051542de800a586d6eaca84f492f0263f52e8036aa110269954479e220 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_617d66051542de800a586d6eaca84f492f0263f52e8036aa110269954479e220->enter($__internal_617d66051542de800a586d6eaca84f492f0263f52e8036aa110269954479e220_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_e278639ddd121e11fdb296882abb688467fc326ba98e9e2415a72626145b89ff = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e278639ddd121e11fdb296882abb688467fc326ba98e9e2415a72626145b89ff->enter($__internal_e278639ddd121e11fdb296882abb688467fc326ba98e9e2415a72626145b89ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "  <div class=\"container-fluid\">
    <div class=\"col-sm-4\">
      <a data-toggle=\"modal\" id=\"visiteClick\">
        <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
          <form class=\"\" action=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pw_poudlard_service");
        echo "\" method=\"post\" id=\"visite\">
            <input type=\"hidden\" name=\"visite\" value=\"1\">
            <h2 class=\"text-center\">Visite de courtoisie</h2>
            <br>
            <img src=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("image/hagrid.jpg"), "html", null, true);
        echo "\" alt=\"Hagrid\" class=\"col-sm-12\" id=\"images\"/>
          </form>

          <script type=\"text/javascript\">
            \$(\"#visiteClick\").click(function() {
              \$(\"#visite\").submit();
            });
          </script>
        </div>
      </a>
    </div>

    ";
        // line 26
        if (($context["visite"] ?? $this->getContext($context, "visite"))) {
            // line 27
            echo "      <div id=\"modal_visite\" class=\"modal fade in\" role=\"dialog\" style=\"display:block;\">
        <div class=\"modal-dialog\">
          <div class=\"modal-content\">
            <div class=\"modal-body\">
              <p>
                \"Comme c'est gentil de passer me voir !\"
                <br>
                Tu gagnes 1 mornille
              </p>
            </div>
            <div class=\"modal-footer\">
              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" onclick=\"fermeModal('modal_visite');\">Fermer</button>
            </div>
          </div>
        </div>
      </div>
    ";
        }
        // line 44
        echo "
    <div class=\"col-sm-4\">
      <a data-toggle=\"modal\" id=\"crockdurClick\">
        <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
          <form class=\"\" action=\"";
        // line 48
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pw_poudlard_service");
        echo "\" method=\"post\" id=\"crockdur\">
            <input type=\"hidden\" name=\"crockdur\" value=\"3\">
            <h2 class=\"text-center\">Nourrir Crockdur</h2>
            <br>
            <img src=\"";
        // line 52
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("image/crockdur.jpg"), "html", null, true);
        echo "\" alt=\"Crockdur\" class=\"col-sm-12\" id=\"images\"/>
            <p class=\"text-center\">Tu as besoin de viande !</p>
          </form>

          <script type=\"text/javascript\">
            \$(\"#crockdurClick\").click(function() {
              \$(\"#crockdur\").submit();
            });
          </script>
        </div>
      </a>
    </div>

    ";
        // line 65
        if (($context["crockdur"] ?? $this->getContext($context, "crockdur"))) {
            // line 66
            echo "      <div id=\"modal_crockdur\" class=\"modal fade in\" role=\"dialog\" style=\"display:block;\">
        <div class=\"modal-dialog\">
          <div class=\"modal-content\">
            <div class=\"modal-body\">
              <p>
                \"Merci d'avoir nourri ce gourmand !\"
                <br>
                Tu gagnes 3 mornilles
              </p>
            </div>
            <div class=\"modal-footer\">
              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" onclick=\"fermeModal('modal_crockdur');\">Fermer</button>
            </div>
          </div>
        </div>
      </div>
    ";
        }
        // line 83
        echo "
    <div class=\"col-sm-4\">
      <a data-toggle=\"modal\" id=\"dragonClick\">
        <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
          <form class=\"\" action=\"";
        // line 87
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pw_poudlard_service");
        echo "\" method=\"post\" id=\"dragon\">
            <input type=\"hidden\" name=\"dragon\" value=\"5\">
            <h2 class=\"text-center\">Surveiller l'oeuf de dragon</h2>
            <br>
            <img src=\"";
        // line 91
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("image/oeuf_dragon.jpg"), "html", null, true);
        echo "\" alt=\"Oeuf de dragon\" class=\"col-sm-12\" id=\"images\"/>
            <p class=\"text-center\">Tu as besoin de bois pour le garder au chaud !</p>
          </form>
        </div>
      </a>
    </div>

    ";
        // line 98
        if (($context["dragon"] ?? $this->getContext($context, "dragon"))) {
            // line 99
            echo "      <div id=\"modal_dragon\" class=\"modal fade in\" role=\"dialog\" style=\"display:block;\">
        <div class=\"modal-dialog\">
          <div class=\"modal-content\">
            <div class=\"modal-body\">
              <p>
                \"Merci d'avoir surveillé Norbert !\"
                <br>
                Tu gagnes 5 mornilles
              </p>
            </div>
            <div class=\"modal-footer\">
              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" onclick=\"fermeModal('modal_dragon');\">Fermer</button>
            </div>
          </div>
        </div>
      </div>
    ";
        }
        // line 116
        echo "
    <div class=\"col-sm-4\">
      <a data-toggle=\"modal\" id=\"hippogriffeClick\">
        <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
          <form class=\"\" action=\"";
        // line 120
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pw_poudlard_service");
        echo "\" method=\"post\" id=\"hippogriffe\">
            <input type=\"hidden\" name=\"hippogriffe\" value=\"10\">
            <h2 class=\"text-center\">Promener l'hippogriffe</h2>
            <br>
            <img src=\"";
        // line 124
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("image/hippogriffe.jpg"), "html", null, true);
        echo "\" alt=\"Hippogriffe\" class=\"col-sm-12\" id=\"images\"/>
            <p class=\"text-center\">Tu as besoin d'une cape pour te protéger du vent !</p>
          </form>

          <script type=\"text/javascript\">
            \$(\"#hippogriffeClick\").click(function() {
              \$(\"#hippogriffe\").submit();
            });
          </script>
        </div>
      </a>
    </div>

    ";
        // line 137
        if (($context["hippogriffe"] ?? $this->getContext($context, "hippogriffe"))) {
            // line 138
            echo "      <div id=\"modal_hippogriffe\" class=\"modal fade in\" role=\"dialog\" style=\"display:block;\">
        <div class=\"modal-dialog\">
          <div class=\"modal-content\">
            <div class=\"modal-body\">
              <p>
                \"Merci d'avoir promené l'hippogriffe !\"
                <br>
                Tu gagnes 10 mornilles
              </p>
            </div>
            <div class=\"modal-footer\">
              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" onclick=\"fermeModal('modal_hippogriffe');\">Fermer</button>
            </div>
          </div>
        </div>
      </div>
    ";
        }
        // line 155
        echo "
    <div class=\"col-sm-4\">
      <a data-toggle=\"modal\" id=\"graupClick\">
        <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
          <form class=\"\" action=\"";
        // line 159
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pw_poudlard_service");
        echo "\" method=\"post\" id=\"graup\">
            <input type=\"hidden\" name=\"graup\" value=\"15\">
            <h2 class=\"text-center\">Tenir compagnie à Graup</h2>
            <br>
            <img src=\"";
        // line 163
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("image/graup.jpg"), "html", null, true);
        echo "\" alt=\"Graup\" class=\"col-sm-12\" id=\"images\"/>
            <p class=\"text-center\">Tu as besoin de jouets pour l'occuper !</p>
          </form>

          <script type=\"text/javascript\">
            \$(\"#graupClick\").click(function() {
              \$(\"#graup\").submit();
            });
          </script>
        </div>
      </a>
    </div>

    ";
        // line 176
        if (($context["graup"] ?? $this->getContext($context, "graup"))) {
            // line 177
            echo "      <div id=\"modal_graup\" class=\"modal fade in\" role=\"dialog\" style=\"display:block;\">
        <div class=\"modal-dialog\">
          <div class=\"modal-content\">
            <div class=\"modal-body\">
              <p>
                \"Merci d'avoir tenu compagnie à mon frère !\"
                <br>
                Tu gagnes 15 mornilles
              </p>
            </div>
            <div class=\"modal-footer\">
              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" onclick=\"fermeModal('modal_graup');\">Fermer</button>
            </div>
          </div>
        </div>
      </div>
    ";
        }
        // line 194
        echo "  </div>
  <script type=\"text/javascript\">
    function fermeModal(idSupp) {
      \$(\"#\"+idSupp).css('display', 'none');
    }
  </script>
";
        
        $__internal_e278639ddd121e11fdb296882abb688467fc326ba98e9e2415a72626145b89ff->leave($__internal_e278639ddd121e11fdb296882abb688467fc326ba98e9e2415a72626145b89ff_prof);

        
        $__internal_617d66051542de800a586d6eaca84f492f0263f52e8036aa110269954479e220->leave($__internal_617d66051542de800a586d6eaca84f492f0263f52e8036aa110269954479e220_prof);

    }

    public function getTemplateName()
    {
        return "PWPoudlardBundle:Default:service.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  311 => 194,  292 => 177,  290 => 176,  274 => 163,  267 => 159,  261 => 155,  242 => 138,  240 => 137,  224 => 124,  217 => 120,  211 => 116,  192 => 99,  190 => 98,  180 => 91,  173 => 87,  167 => 83,  148 => 66,  146 => 65,  130 => 52,  123 => 48,  117 => 44,  98 => 27,  96 => 26,  81 => 14,  74 => 10,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"menu.html.twig\" %}

{% block title %}Rends un service à Hagrid{% endblock %}

{% block body %}
  <div class=\"container-fluid\">
    <div class=\"col-sm-4\">
      <a data-toggle=\"modal\" id=\"visiteClick\">
        <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
          <form class=\"\" action=\"{{ path(\"pw_poudlard_service\")}}\" method=\"post\" id=\"visite\">
            <input type=\"hidden\" name=\"visite\" value=\"1\">
            <h2 class=\"text-center\">Visite de courtoisie</h2>
            <br>
            <img src=\"{{ asset(\"image/hagrid.jpg\") }}\" alt=\"Hagrid\" class=\"col-sm-12\" id=\"images\"/>
          </form>

          <script type=\"text/javascript\">
            \$(\"#visiteClick\").click(function() {
              \$(\"#visite\").submit();
            });
          </script>
        </div>
      </a>
    </div>

    {% if visite %}
      <div id=\"modal_visite\" class=\"modal fade in\" role=\"dialog\" style=\"display:block;\">
        <div class=\"modal-dialog\">
          <div class=\"modal-content\">
            <div class=\"modal-body\">
              <p>
                \"Comme c'est gentil de passer me voir !\"
                <br>
                Tu gagnes 1 mornille
              </p>
            </div>
            <div class=\"modal-footer\">
              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" onclick=\"fermeModal('modal_visite');\">Fermer</button>
            </div>
          </div>
        </div>
      </div>
    {% endif %}

    <div class=\"col-sm-4\">
      <a data-toggle=\"modal\" id=\"crockdurClick\">
        <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
          <form class=\"\" action=\"{{ path(\"pw_poudlard_service\") }}\" method=\"post\" id=\"crockdur\">
            <input type=\"hidden\" name=\"crockdur\" value=\"3\">
            <h2 class=\"text-center\">Nourrir Crockdur</h2>
            <br>
            <img src=\"{{ asset(\"image/crockdur.jpg\") }}\" alt=\"Crockdur\" class=\"col-sm-12\" id=\"images\"/>
            <p class=\"text-center\">Tu as besoin de viande !</p>
          </form>

          <script type=\"text/javascript\">
            \$(\"#crockdurClick\").click(function() {
              \$(\"#crockdur\").submit();
            });
          </script>
        </div>
      </a>
    </div>

    {% if crockdur %}
      <div id=\"modal_crockdur\" class=\"modal fade in\" role=\"dialog\" style=\"display:block;\">
        <div class=\"modal-dialog\">
          <div class=\"modal-content\">
            <div class=\"modal-body\">
              <p>
                \"Merci d'avoir nourri ce gourmand !\"
                <br>
                Tu gagnes 3 mornilles
              </p>
            </div>
            <div class=\"modal-footer\">
              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" onclick=\"fermeModal('modal_crockdur');\">Fermer</button>
            </div>
          </div>
        </div>
      </div>
    {% endif %}

    <div class=\"col-sm-4\">
      <a data-toggle=\"modal\" id=\"dragonClick\">
        <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
          <form class=\"\" action=\"{{ path(\"pw_poudlard_service\") }}\" method=\"post\" id=\"dragon\">
            <input type=\"hidden\" name=\"dragon\" value=\"5\">
            <h2 class=\"text-center\">Surveiller l'oeuf de dragon</h2>
            <br>
            <img src=\"{{ asset(\"image/oeuf_dragon.jpg\") }}\" alt=\"Oeuf de dragon\" class=\"col-sm-12\" id=\"images\"/>
            <p class=\"text-center\">Tu as besoin de bois pour le garder au chaud !</p>
          </form>
        </div>
      </a>
    </div>

    {% if dragon %}
      <div id=\"modal_dragon\" class=\"modal fade in\" role=\"dialog\" style=\"display:block;\">
        <div class=\"modal-dialog\">
          <div class=\"modal-content\">
            <div class=\"modal-body\">
              <p>
                \"Merci d'avoir surveillé Norbert !\"
                <br>
                Tu gagnes 5 mornilles
              </p>
            </div>
            <div class=\"modal-footer\">
              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" onclick=\"fermeModal('modal_dragon');\">Fermer</button>
            </div>
          </div>
        </div>
      </div>
    {% endif %}

    <div class=\"col-sm-4\">
      <a data-toggle=\"modal\" id=\"hippogriffeClick\">
        <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
          <form class=\"\" action=\"{{path(\"pw_poudlard_service\")}}\" method=\"post\" id=\"hippogriffe\">
            <input type=\"hidden\" name=\"hippogriffe\" value=\"10\">
            <h2 class=\"text-center\">Promener l'hippogriffe</h2>
            <br>
            <img src=\"{{ asset(\"image/hippogriffe.jpg\") }}\" alt=\"Hippogriffe\" class=\"col-sm-12\" id=\"images\"/>
            <p class=\"text-center\">Tu as besoin d'une cape pour te protéger du vent !</p>
          </form>

          <script type=\"text/javascript\">
            \$(\"#hippogriffeClick\").click(function() {
              \$(\"#hippogriffe\").submit();
            });
          </script>
        </div>
      </a>
    </div>

    {% if hippogriffe %}
      <div id=\"modal_hippogriffe\" class=\"modal fade in\" role=\"dialog\" style=\"display:block;\">
        <div class=\"modal-dialog\">
          <div class=\"modal-content\">
            <div class=\"modal-body\">
              <p>
                \"Merci d'avoir promené l'hippogriffe !\"
                <br>
                Tu gagnes 10 mornilles
              </p>
            </div>
            <div class=\"modal-footer\">
              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" onclick=\"fermeModal('modal_hippogriffe');\">Fermer</button>
            </div>
          </div>
        </div>
      </div>
    {% endif %}

    <div class=\"col-sm-4\">
      <a data-toggle=\"modal\" id=\"graupClick\">
        <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
          <form class=\"\" action=\"{{path(\"pw_poudlard_service\")}}\" method=\"post\" id=\"graup\">
            <input type=\"hidden\" name=\"graup\" value=\"15\">
            <h2 class=\"text-center\">Tenir compagnie à Graup</h2>
            <br>
            <img src=\"{{ asset(\"image/graup.jpg\") }}\" alt=\"Graup\" class=\"col-sm-12\" id=\"images\"/>
            <p class=\"text-center\">Tu as besoin de jouets pour l'occuper !</p>
          </form>

          <script type=\"text/javascript\">
            \$(\"#graupClick\").click(function() {
              \$(\"#graup\").submit();
            });
          </script>
        </div>
      </a>
    </div>

    {% if graup %}
      <div id=\"modal_graup\" class=\"modal fade in\" role=\"dialog\" style=\"display:block;\">
        <div class=\"modal-dialog\">
          <div class=\"modal-content\">
            <div class=\"modal-body\">
              <p>
                \"Merci d'avoir tenu compagnie à mon frère !\"
                <br>
                Tu gagnes 15 mornilles
              </p>
            </div>
            <div class=\"modal-footer\">
              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" onclick=\"fermeModal('modal_graup');\">Fermer</button>
            </div>
          </div>
        </div>
      </div>
    {% endif %}
  </div>
  <script type=\"text/javascript\">
    function fermeModal(idSupp) {
      \$(\"#\"+idSupp).css('display', 'none');
    }
  </script>
{% endblock %}
", "PWPoudlardBundle:Default:service.html.twig", "/home/betty/S6/PW6/projetweb/projetweb/src/PW/PoudlardBundle/Resources/views/Default/service.html.twig");
    }
}
