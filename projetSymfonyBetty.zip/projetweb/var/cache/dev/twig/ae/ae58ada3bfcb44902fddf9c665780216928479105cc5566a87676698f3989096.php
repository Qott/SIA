<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_2b010cb35fb9a71259ebd5f4d9945690d6bc2df7d5bb357e7184efe2193ab1b2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cf76bd6ceb18ca04263b890eee3613ff22103332eff85b29aea6ebfec9ab0c55 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cf76bd6ceb18ca04263b890eee3613ff22103332eff85b29aea6ebfec9ab0c55->enter($__internal_cf76bd6ceb18ca04263b890eee3613ff22103332eff85b29aea6ebfec9ab0c55_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        $__internal_63e735644673ffae6e277415e9c8ddab9a59cef9c68dc329d21c90f5addcd852 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_63e735644673ffae6e277415e9c8ddab9a59cef9c68dc329d21c90f5addcd852->enter($__internal_63e735644673ffae6e277415e9c8ddab9a59cef9c68dc329d21c90f5addcd852_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_cf76bd6ceb18ca04263b890eee3613ff22103332eff85b29aea6ebfec9ab0c55->leave($__internal_cf76bd6ceb18ca04263b890eee3613ff22103332eff85b29aea6ebfec9ab0c55_prof);

        
        $__internal_63e735644673ffae6e277415e9c8ddab9a59cef9c68dc329d21c90f5addcd852->leave($__internal_63e735644673ffae6e277415e9c8ddab9a59cef9c68dc329d21c90f5addcd852_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
", "@Framework/Form/form_rest.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_rest.html.php");
    }
}
