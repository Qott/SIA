<?php

/* TwigBundle:Exception:error.json.twig */
class __TwigTemplate_e297c640960503a899ae115cebef317122a0fecdcd1671665a4e9527d4b3f59c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9553e2da64db90ce5a5820f169ecb668012abc10e0ab341c2422640d7d6cd642 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9553e2da64db90ce5a5820f169ecb668012abc10e0ab341c2422640d7d6cd642->enter($__internal_9553e2da64db90ce5a5820f169ecb668012abc10e0ab341c2422640d7d6cd642_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        $__internal_ec8c87091d7c59603195971cd9f635749d8ce543dee18162ab39d248a4d2d69c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ec8c87091d7c59603195971cd9f635749d8ce543dee18162ab39d248a4d2d69c->enter($__internal_ec8c87091d7c59603195971cd9f635749d8ce543dee18162ab39d248a4d2d69c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => ($context["status_code"] ?? $this->getContext($context, "status_code")), "message" => ($context["status_text"] ?? $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_9553e2da64db90ce5a5820f169ecb668012abc10e0ab341c2422640d7d6cd642->leave($__internal_9553e2da64db90ce5a5820f169ecb668012abc10e0ab341c2422640d7d6cd642_prof);

        
        $__internal_ec8c87091d7c59603195971cd9f635749d8ce543dee18162ab39d248a4d2d69c->leave($__internal_ec8c87091d7c59603195971cd9f635749d8ce543dee18162ab39d248a4d2d69c_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
", "TwigBundle:Exception:error.json.twig", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.json.twig");
    }
}
