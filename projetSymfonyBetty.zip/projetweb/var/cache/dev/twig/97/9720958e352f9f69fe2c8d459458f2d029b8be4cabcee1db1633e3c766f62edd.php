<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_d7e6cce490cf57ea2009fe76aa05ae8cfdb5dae41cedf16f66f00ec05608b804 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_99fa274df2fa01fef0ec7959c083f814929aa73e7ffd4f7f73ed364632433ad3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_99fa274df2fa01fef0ec7959c083f814929aa73e7ffd4f7f73ed364632433ad3->enter($__internal_99fa274df2fa01fef0ec7959c083f814929aa73e7ffd4f7f73ed364632433ad3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_5c32593c4f3483cbbc1d6143d24c67877ac5731fe8345f729a40153a065d9d8c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5c32593c4f3483cbbc1d6143d24c67877ac5731fe8345f729a40153a065d9d8c->enter($__internal_5c32593c4f3483cbbc1d6143d24c67877ac5731fe8345f729a40153a065d9d8c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_99fa274df2fa01fef0ec7959c083f814929aa73e7ffd4f7f73ed364632433ad3->leave($__internal_99fa274df2fa01fef0ec7959c083f814929aa73e7ffd4f7f73ed364632433ad3_prof);

        
        $__internal_5c32593c4f3483cbbc1d6143d24c67877ac5731fe8345f729a40153a065d9d8c->leave($__internal_5c32593c4f3483cbbc1d6143d24c67877ac5731fe8345f729a40153a065d9d8c_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_d612b3053b18dcf5aeda4a654a1905eb047aa6a51e5cd1855279c42429de7255 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d612b3053b18dcf5aeda4a654a1905eb047aa6a51e5cd1855279c42429de7255->enter($__internal_d612b3053b18dcf5aeda4a654a1905eb047aa6a51e5cd1855279c42429de7255_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_ca64d7d9c8f46aed34e2a43eb6cce466b48c7b36fe598e33c8d9a466ef149c4c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca64d7d9c8f46aed34e2a43eb6cce466b48c7b36fe598e33c8d9a466ef149c4c->enter($__internal_ca64d7d9c8f46aed34e2a43eb6cce466b48c7b36fe598e33c8d9a466ef149c4c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_ca64d7d9c8f46aed34e2a43eb6cce466b48c7b36fe598e33c8d9a466ef149c4c->leave($__internal_ca64d7d9c8f46aed34e2a43eb6cce466b48c7b36fe598e33c8d9a466ef149c4c_prof);

        
        $__internal_d612b3053b18dcf5aeda4a654a1905eb047aa6a51e5cd1855279c42429de7255->leave($__internal_d612b3053b18dcf5aeda4a654a1905eb047aa6a51e5cd1855279c42429de7255_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_86db10978ba3f3a99f4fde1644e1753338b484b4690e8530e41faa64abb81b32 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_86db10978ba3f3a99f4fde1644e1753338b484b4690e8530e41faa64abb81b32->enter($__internal_86db10978ba3f3a99f4fde1644e1753338b484b4690e8530e41faa64abb81b32_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_ced7b1c46127527a566978a3ac260499fb053a28d5ed03ba1cc75b62fd7e5bca = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ced7b1c46127527a566978a3ac260499fb053a28d5ed03ba1cc75b62fd7e5bca->enter($__internal_ced7b1c46127527a566978a3ac260499fb053a28d5ed03ba1cc75b62fd7e5bca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_ced7b1c46127527a566978a3ac260499fb053a28d5ed03ba1cc75b62fd7e5bca->leave($__internal_ced7b1c46127527a566978a3ac260499fb053a28d5ed03ba1cc75b62fd7e5bca_prof);

        
        $__internal_86db10978ba3f3a99f4fde1644e1753338b484b4690e8530e41faa64abb81b32->leave($__internal_86db10978ba3f3a99f4fde1644e1753338b484b4690e8530e41faa64abb81b32_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_c4ade306b9d5ed7e88ee1119a88094d4ea6e3764bd494c81e46873a24c70d21c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c4ade306b9d5ed7e88ee1119a88094d4ea6e3764bd494c81e46873a24c70d21c->enter($__internal_c4ade306b9d5ed7e88ee1119a88094d4ea6e3764bd494c81e46873a24c70d21c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_bcd909f7b8cbf42ed1d60c08bb441745f54eda4f215bcde72ddb42992bfae5ef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bcd909f7b8cbf42ed1d60c08bb441745f54eda4f215bcde72ddb42992bfae5ef->enter($__internal_bcd909f7b8cbf42ed1d60c08bb441745f54eda4f215bcde72ddb42992bfae5ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_bcd909f7b8cbf42ed1d60c08bb441745f54eda4f215bcde72ddb42992bfae5ef->leave($__internal_bcd909f7b8cbf42ed1d60c08bb441745f54eda4f215bcde72ddb42992bfae5ef_prof);

        
        $__internal_c4ade306b9d5ed7e88ee1119a88094d4ea6e3764bd494c81e46873a24c70d21c->leave($__internal_c4ade306b9d5ed7e88ee1119a88094d4ea6e3764bd494c81e46873a24c70d21c_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/exception.html.twig");
    }
}
