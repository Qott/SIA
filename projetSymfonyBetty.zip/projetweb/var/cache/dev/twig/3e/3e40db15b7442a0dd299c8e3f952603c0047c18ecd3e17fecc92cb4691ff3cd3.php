<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_e8da47c82bdbf50e78aef30bcc8d459ea0b2d9469dfc5aab66ef267e1403fcc8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4c8301832ae387ed49a1cd149458958753ad4da8c178213c916b0d09c0d85a3c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4c8301832ae387ed49a1cd149458958753ad4da8c178213c916b0d09c0d85a3c->enter($__internal_4c8301832ae387ed49a1cd149458958753ad4da8c178213c916b0d09c0d85a3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        $__internal_6fa34aa5b61f5ac81df6e00dcea98acf1e82a9e0b305321dde116e74dd62a9ef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6fa34aa5b61f5ac81df6e00dcea98acf1e82a9e0b305321dde116e74dd62a9ef->enter($__internal_6fa34aa5b61f5ac81df6e00dcea98acf1e82a9e0b305321dde116e74dd62a9ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_4c8301832ae387ed49a1cd149458958753ad4da8c178213c916b0d09c0d85a3c->leave($__internal_4c8301832ae387ed49a1cd149458958753ad4da8c178213c916b0d09c0d85a3c_prof);

        
        $__internal_6fa34aa5b61f5ac81df6e00dcea98acf1e82a9e0b305321dde116e74dd62a9ef->leave($__internal_6fa34aa5b61f5ac81df6e00dcea98acf1e82a9e0b305321dde116e74dd62a9ef_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/form_row.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_row.html.php");
    }
}
