<?php

/* PWPoudlardBundle:Default:changerPerso.html.twig */
class __TwigTemplate_5f66c71be81f34281fe6a2b67c859a4bc35825b536914c932d0d22c55cb3f9ea extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("menu.html.twig", "PWPoudlardBundle:Default:changerPerso.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "menu.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_772a6fff44b5ca065a2d5b30a9e3fac0369c80fd41180903b412b8dd983cba0c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_772a6fff44b5ca065a2d5b30a9e3fac0369c80fd41180903b412b8dd983cba0c->enter($__internal_772a6fff44b5ca065a2d5b30a9e3fac0369c80fd41180903b412b8dd983cba0c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PWPoudlardBundle:Default:changerPerso.html.twig"));

        $__internal_bbeb0d9be15c40b1e963235bba6e647e9061a8d76cdfba56d5d55e7807b83d8d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bbeb0d9be15c40b1e963235bba6e647e9061a8d76cdfba56d5d55e7807b83d8d->enter($__internal_bbeb0d9be15c40b1e963235bba6e647e9061a8d76cdfba56d5d55e7807b83d8d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PWPoudlardBundle:Default:changerPerso.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_772a6fff44b5ca065a2d5b30a9e3fac0369c80fd41180903b412b8dd983cba0c->leave($__internal_772a6fff44b5ca065a2d5b30a9e3fac0369c80fd41180903b412b8dd983cba0c_prof);

        
        $__internal_bbeb0d9be15c40b1e963235bba6e647e9061a8d76cdfba56d5d55e7807b83d8d->leave($__internal_bbeb0d9be15c40b1e963235bba6e647e9061a8d76cdfba56d5d55e7807b83d8d_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_ee4b4949743db59c23246528f2c23d9a72fc1666bcbe2e7104d4b6b0c498a044 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ee4b4949743db59c23246528f2c23d9a72fc1666bcbe2e7104d4b6b0c498a044->enter($__internal_ee4b4949743db59c23246528f2c23d9a72fc1666bcbe2e7104d4b6b0c498a044_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_ed07e65ff18b3ed15bc689c0df529c2916c4b2047594a977bf66f6cc82a03064 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ed07e65ff18b3ed15bc689c0df529c2916c4b2047594a977bf66f6cc82a03064->enter($__internal_ed07e65ff18b3ed15bc689c0df529c2916c4b2047594a977bf66f6cc82a03064_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 5
        echo "Change ton personnage
";
        
        $__internal_ed07e65ff18b3ed15bc689c0df529c2916c4b2047594a977bf66f6cc82a03064->leave($__internal_ed07e65ff18b3ed15bc689c0df529c2916c4b2047594a977bf66f6cc82a03064_prof);

        
        $__internal_ee4b4949743db59c23246528f2c23d9a72fc1666bcbe2e7104d4b6b0c498a044->leave($__internal_ee4b4949743db59c23246528f2c23d9a72fc1666bcbe2e7104d4b6b0c498a044_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_167eca8a0a0df1ae58dbec0a5e2db9f8311e239dc173d8a1cd8ef9e4839eefa8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_167eca8a0a0df1ae58dbec0a5e2db9f8311e239dc173d8a1cd8ef9e4839eefa8->enter($__internal_167eca8a0a0df1ae58dbec0a5e2db9f8311e239dc173d8a1cd8ef9e4839eefa8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_e2d667d91438fe83f437d8a39c104920137aefc18fadab6de2788de78f464943 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e2d667d91438fe83f437d8a39c104920137aefc18fadab6de2788de78f464943->enter($__internal_e2d667d91438fe83f437d8a39c104920137aefc18fadab6de2788de78f464943_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo "    <div class =\"well text-center\">
      <h3 class=\"text-center\">Créer personnage</h3>
      ";
        // line 11
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["formI"] ?? $this->getContext($context, "formI")), 'form');
        echo "

    </div>

    <div class=\"container-fluid\">
      ";
        // line 16
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["persos"] ?? $this->getContext($context, "persos")));
        foreach ($context['_seq'] as $context["_key"] => $context["perso"]) {
            // line 17
            echo "        <div class=\"col-sm-3\" id=\"border\">
          <a>
            <form action=\"";
            // line 19
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pw_poudlard_accueil");
            echo "\" method=\"post\"  id=\"choix";
            echo twig_escape_filter($this->env, $this->getAttribute($context["perso"], "id", array()), "html", null, true);
            echo "\">
              <input name=\"perso\" type=\"hidden\" value=\"";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($context["perso"], "id", array()), "html", null, true);
            echo "\" id=\"perso\">
              <h2 class=\"text-center\">";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($context["perso"], "nom", array()), "html", null, true);
            echo "</h2>
              <img src=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["perso"], "image", array()), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["perso"], "nom", array()), "html", null, true);
            echo "\" class=\"col-sm-12\" id=\"image";
            echo twig_escape_filter($this->env, $this->getAttribute($context["perso"], "id", array()), "html", null, true);
            echo "\"/>
              ";
            // line 23
            if (($this->getAttribute($context["perso"], "maison", array()) == 1)) {
                // line 24
                echo "                ";
                $context["maison"] = "Gryffondor";
                // line 25
                echo "              ";
            } elseif (($this->getAttribute($context["perso"], "maison", array()) == 2)) {
                // line 26
                echo "                ";
                $context["maison"] = "Poufsouffle";
                // line 27
                echo "              ";
            } elseif (($this->getAttribute($context["perso"], "maison", array()) == 3)) {
                // line 28
                echo "                ";
                $context["maison"] = "Serpentard";
                // line 29
                echo "              ";
            } elseif (($this->getAttribute($context["perso"], "maison", array()) == 4)) {
                // line 30
                echo "                ";
                $context["maison"] = "Serdaigle";
                // line 31
                echo "              ";
            }
            // line 32
            echo "              <p class=\"text-center\">Maison : ";
            echo twig_escape_filter($this->env, ($context["maison"] ?? $this->getContext($context, "maison")), "html", null, true);
            echo "</p>
            </form>

            <script type=\"text/javascript\">
              \$(\"#image";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute($context["perso"], "id", array()), "html", null, true);
            echo "\").click(function() {
                \$(\"#choix";
            // line 37
            echo twig_escape_filter($this->env, $this->getAttribute($context["perso"], "id", array()), "html", null, true);
            echo "\").submit();
              });
            </script>
          </a>
        </div>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['perso'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 43
        echo "    </div>
    ";
        
        $__internal_e2d667d91438fe83f437d8a39c104920137aefc18fadab6de2788de78f464943->leave($__internal_e2d667d91438fe83f437d8a39c104920137aefc18fadab6de2788de78f464943_prof);

        
        $__internal_167eca8a0a0df1ae58dbec0a5e2db9f8311e239dc173d8a1cd8ef9e4839eefa8->leave($__internal_167eca8a0a0df1ae58dbec0a5e2db9f8311e239dc173d8a1cd8ef9e4839eefa8_prof);

    }

    public function getTemplateName()
    {
        return "PWPoudlardBundle:Default:changerPerso.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  162 => 43,  150 => 37,  146 => 36,  138 => 32,  135 => 31,  132 => 30,  129 => 29,  126 => 28,  123 => 27,  120 => 26,  117 => 25,  114 => 24,  112 => 23,  104 => 22,  100 => 21,  96 => 20,  90 => 19,  86 => 17,  82 => 16,  74 => 11,  70 => 9,  61 => 8,  50 => 5,  41 => 4,  11 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("
  {% extends \"menu.html.twig\" %}

  {% block title %}
Change ton personnage
{% endblock %}

  {% block body %}
    <div class =\"well text-center\">
      <h3 class=\"text-center\">Créer personnage</h3>
      {{form(formI)}}

    </div>

    <div class=\"container-fluid\">
      {% for perso in persos %}
        <div class=\"col-sm-3\" id=\"border\">
          <a>
            <form action=\"{{ path('pw_poudlard_accueil') }}\" method=\"post\"  id=\"choix{{perso.id}}\">
              <input name=\"perso\" type=\"hidden\" value=\"{{perso.id}}\" id=\"perso\">
              <h2 class=\"text-center\">{{perso.nom}}</h2>
              <img src=\"{{perso.image}}\" alt=\"{{perso.nom}}\" class=\"col-sm-12\" id=\"image{{perso.id}}\"/>
              {% if perso.maison == 1 %}
                {% set maison = \"Gryffondor\" %}
              {% elseif perso.maison == 2 %}
                {% set maison = \"Poufsouffle\" %}
              {% elseif perso.maison == 3 %}
                {% set maison = \"Serpentard\" %}
              {% elseif perso.maison == 4 %}
                {% set maison = \"Serdaigle\" %}
              {% endif %}
              <p class=\"text-center\">Maison : {{maison}}</p>
            </form>

            <script type=\"text/javascript\">
              \$(\"#image{{perso.id}}\").click(function() {
                \$(\"#choix{{perso.id}}\").submit();
              });
            </script>
          </a>
        </div>
      {% endfor %}
    </div>
    {% endblock %}
", "PWPoudlardBundle:Default:changerPerso.html.twig", "/home/betty/S6/PW6/projetweb/projetweb/src/PW/PoudlardBundle/Resources/views/Default/changerPerso.html.twig");
    }
}
