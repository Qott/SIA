<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_9da4296c33e4a2507a8266e721232d10f3a1b58beaa68b6875203d4e982a6302 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dc2e4202b09475931257fa69e25138f803eb19c9f71d115663d7b5a911fe2a59 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dc2e4202b09475931257fa69e25138f803eb19c9f71d115663d7b5a911fe2a59->enter($__internal_dc2e4202b09475931257fa69e25138f803eb19c9f71d115663d7b5a911fe2a59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        $__internal_98d28ea7fe85ecbc84177fa3f35e23581dd7a840b31a99dff0d317dd6747632f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_98d28ea7fe85ecbc84177fa3f35e23581dd7a840b31a99dff0d317dd6747632f->enter($__internal_98d28ea7fe85ecbc84177fa3f35e23581dd7a840b31a99dff0d317dd6747632f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_dc2e4202b09475931257fa69e25138f803eb19c9f71d115663d7b5a911fe2a59->leave($__internal_dc2e4202b09475931257fa69e25138f803eb19c9f71d115663d7b5a911fe2a59_prof);

        
        $__internal_98d28ea7fe85ecbc84177fa3f35e23581dd7a840b31a99dff0d317dd6747632f->leave($__internal_98d28ea7fe85ecbc84177fa3f35e23581dd7a840b31a99dff0d317dd6747632f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
", "@Framework/Form/form_end.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_end.html.php");
    }
}
