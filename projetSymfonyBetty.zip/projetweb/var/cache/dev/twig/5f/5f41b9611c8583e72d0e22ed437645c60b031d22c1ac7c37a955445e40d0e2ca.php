<?php

/* menu.html.twig */
class __TwigTemplate_41f03b68669551e89d671d676e9f673c5a4035fca6a1ed04d2c80bc276f04dbb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_33caf4b372e60ecfd159f642230478d5b991d937cda64ce83a996aaed446f75f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_33caf4b372e60ecfd159f642230478d5b991d937cda64ce83a996aaed446f75f->enter($__internal_33caf4b372e60ecfd159f642230478d5b991d937cda64ce83a996aaed446f75f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "menu.html.twig"));

        $__internal_8a800ef4188487cc1233eac66db53d0e7f4f0e98adf2a51ca2b2f736c290c39f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8a800ef4188487cc1233eac66db53d0e7f4f0e98adf2a51ca2b2f736c290c39f->enter($__internal_8a800ef4188487cc1233eac66db53d0e7f4f0e98adf2a51ca2b2f736c290c39f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "menu.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
  <head>
    <meta charset=\"utf-8\">
    <title>Poudlard Academy</title>
    ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 15
        echo "  </head>
  <body>
    <nav class=\"navbar navbar-default\">
      <div class=\"container-fluid\">
        <div class=\"navbar-header\">
          <a class=\"navbar-brand\" href=\"";
        // line 20
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pw_poudlard_accueil");
        echo "\">Poudlard Academy</a>
        </div>
        <ul class=\"nav navbar-nav\">
          <li><a>";
        // line 23
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "username", array()), "html", null, true);
        echo "</a></li>
          <li><a>";
        // line 24
        echo twig_escape_filter($this->env, $this->getAttribute(($context["actuel"] ?? $this->getContext($context, "actuel")), "nom", array()), "html", null, true);
        echo "</a></li>
          <li><a>";
        // line 25
        echo twig_escape_filter($this->env, ($context["niveau"] ?? $this->getContext($context, "niveau")), "html", null, true);
        echo " /7</a></li>
          <li><a>";
        // line 26
        echo twig_escape_filter($this->env, ($context["score"] ?? $this->getContext($context, "score")), "html", null, true);
        echo "</a></li>
          <li><a>";
        // line 27
        echo twig_escape_filter($this->env, ($context["argent"] ?? $this->getContext($context, "argent")), "html", null, true);
        echo " Mornilles</a></li>
          <li class=\"dropdown\">
            <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">Objets
              <span class=\"caret\"></span>
            </a>
            <ul class=\"dropdown-menu\">
              ";
        // line 33
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range(0, 9));
        foreach ($context['_seq'] as $context["_key"] => $context["index"]) {
            // line 34
            echo "                ";
            if ((($context["index"] < 6) && ($this->getAttribute(($context["articles"] ?? $this->getContext($context, "articles")), $context["index"], array(), "array") == ($context["niveau"] ?? $this->getContext($context, "niveau"))))) {
                // line 35
                echo "                  ";
                if (($context["index"] == 0)) {
                    // line 36
                    echo "                    <li>Livre de potions</li>
                  ";
                }
                // line 38
                echo "                  ";
                if (($context["index"] == 1)) {
                    // line 39
                    echo "                    <li>Livre de défenses contre les forces du mal</li>
                  ";
                }
                // line 41
                echo "                  ";
                if (($context["index"] == 2)) {
                    // line 42
                    echo "                    <li>Livre de divination</li>
                  ";
                }
                // line 44
                echo "                  ";
                if (($context["index"] == 3)) {
                    // line 45
                    echo "                    <li>Livre de soins aux créatures magiques</li>
                  ";
                }
                // line 47
                echo "                  ";
                if (($context["index"] == 4)) {
                    // line 48
                    echo "                    <li>Livre de botanique</li>
                  ";
                }
                // line 50
                echo "                  ";
                if (($context["index"] == 5)) {
                    // line 51
                    echo "                    <li>Livre de sortilèges</li>
                  ";
                }
                // line 53
                echo "                ";
            }
            // line 54
            echo "                ";
            if ((($context["index"] > 5) && ($this->getAttribute(($context["articles"] ?? $this->getContext($context, "articles")), $context["index"], array(), "array") > 0))) {
                // line 55
                echo "                  ";
                if (($context["index"] == 6)) {
                    // line 56
                    echo "                    <li>Nimbus 2000 x";
                    echo twig_escape_filter($this->env, $this->getAttribute(($context["articles"] ?? $this->getContext($context, "articles")), $context["index"], array(), "array"), "html", null, true);
                    echo "</li>
                  ";
                }
                // line 58
                echo "                  ";
                if (($context["index"] == 7)) {
                    // line 59
                    echo "                    <li>Eclair de feu x";
                    echo twig_escape_filter($this->env, $this->getAttribute(($context["articles"] ?? $this->getContext($context, "articles")), $context["index"], array(), "array"), "html", null, true);
                    echo "</li>
                  ";
                }
                // line 61
                echo "                  ";
                if (($context["index"] == 8)) {
                    // line 62
                    echo "                    <li>Baguette en cyprès et ventricule de dragon x";
                    echo twig_escape_filter($this->env, $this->getAttribute(($context["articles"] ?? $this->getContext($context, "articles")), $context["index"], array(), "array"), "html", null, true);
                    echo "</li>
                  ";
                }
                // line 64
                echo "                  ";
                if (($context["index"] == 9)) {
                    // line 65
                    echo "                    <li>Baguette en sureau et plume de phénix :";
                    echo twig_escape_filter($this->env, $this->getAttribute(($context["articles"] ?? $this->getContext($context, "articles")), $context["index"], array(), "array"), "html", null, true);
                    echo "</li>
                  ";
                }
                // line 67
                echo "                ";
            }
            // line 68
            echo "              ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['index'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 69
        echo "              ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range(0, 3));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 70
            echo "                ";
            if (($this->getAttribute(($context["objets"] ?? $this->getContext($context, "objets")), $context["i"], array(), "array") > 0)) {
                // line 71
                echo "                  ";
                if (($context["i"] == 0)) {
                    // line 72
                    echo "                    <li>Viande x";
                    echo twig_escape_filter($this->env, $this->getAttribute(($context["objets"] ?? $this->getContext($context, "objets")), $context["i"], array(), "array"), "html", null, true);
                    echo "</li>
                  ";
                }
                // line 74
                echo "                  ";
                if (($context["i"] == 1)) {
                    // line 75
                    echo "                    <li>Bois x";
                    echo twig_escape_filter($this->env, $this->getAttribute(($context["objets"] ?? $this->getContext($context, "objets")), $context["i"], array(), "array"), "html", null, true);
                    echo "</li>
                  ";
                }
                // line 77
                echo "                  ";
                if (($context["i"] == 2)) {
                    // line 78
                    echo "                    <li>Cape x";
                    echo twig_escape_filter($this->env, $this->getAttribute(($context["objets"] ?? $this->getContext($context, "objets")), $context["i"], array(), "array"), "html", null, true);
                    echo "</li>
                  ";
                }
                // line 80
                echo "                  ";
                if (($context["i"] == 3)) {
                    // line 81
                    echo "                    <li>Jouets x";
                    echo twig_escape_filter($this->env, $this->getAttribute(($context["objets"] ?? $this->getContext($context, "objets")), $context["i"], array(), "array"), "html", null, true);
                    echo "</li>
                  ";
                }
                // line 83
                echo "                ";
            }
            // line 84
            echo "              ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 85
        echo "            </ul>
          </li>
        </ul>
        <ul class=\"nav navbar-nav navbar-right\">
          <li class=\"dropdown\">
            <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">Menu
              <span class=\"caret\"></span>
            </a>
            <ul class=\"dropdown-menu\">
              <li><a href=\"";
        // line 94
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pw_poudlard_affichagePerso");
        echo "\">Affichage des personnages</a></li>
              <li><a href=\"";
        // line 95
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pw_poudlard_compte");
        echo "\">Compte</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
    <h1 class=\"text-center\">";
        // line 101
        $this->displayBlock('title', $context, $blocks);
        echo "</h1>
    <br>
    ";
        // line 103
        $this->displayBlock('body', $context, $blocks);
        // line 104
        echo "  </body>
</html>
";
        
        $__internal_33caf4b372e60ecfd159f642230478d5b991d937cda64ce83a996aaed446f75f->leave($__internal_33caf4b372e60ecfd159f642230478d5b991d937cda64ce83a996aaed446f75f_prof);

        
        $__internal_8a800ef4188487cc1233eac66db53d0e7f4f0e98adf2a51ca2b2f736c290c39f->leave($__internal_8a800ef4188487cc1233eac66db53d0e7f4f0e98adf2a51ca2b2f736c290c39f_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_ffd7345485259fdc7713145e7d92ff6e6d234159906be26da428ba4778e68e9d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ffd7345485259fdc7713145e7d92ff6e6d234159906be26da428ba4778e68e9d->enter($__internal_ffd7345485259fdc7713145e7d92ff6e6d234159906be26da428ba4778e68e9d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_cbe74a49c9bae02d942f59d1c6929fb94ef481019a5bae102fa0b52d40799dce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cbe74a49c9bae02d942f59d1c6929fb94ef481019a5bae102fa0b52d40799dce->enter($__internal_cbe74a49c9bae02d942f59d1c6929fb94ef481019a5bae102fa0b52d40799dce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 7
        echo "      <script src=\"http://code.jquery.com/jquery-1.11.3.js\"></script>
      <link rel=\"stylesheet\"
        href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\"
        integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\"
        crossorigin=\"anonymous\">
      <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>
      <link rel=\"stylesheet\" href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\"/>
    ";
        
        $__internal_cbe74a49c9bae02d942f59d1c6929fb94ef481019a5bae102fa0b52d40799dce->leave($__internal_cbe74a49c9bae02d942f59d1c6929fb94ef481019a5bae102fa0b52d40799dce_prof);

        
        $__internal_ffd7345485259fdc7713145e7d92ff6e6d234159906be26da428ba4778e68e9d->leave($__internal_ffd7345485259fdc7713145e7d92ff6e6d234159906be26da428ba4778e68e9d_prof);

    }

    // line 101
    public function block_title($context, array $blocks = array())
    {
        $__internal_24fa35cd1fcc33b154fdd6af7a1e6d5fae20c9037ba60c7884e73959860a66a6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_24fa35cd1fcc33b154fdd6af7a1e6d5fae20c9037ba60c7884e73959860a66a6->enter($__internal_24fa35cd1fcc33b154fdd6af7a1e6d5fae20c9037ba60c7884e73959860a66a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_9b6df605f2aaf607396169bdf907653786e1a851584b49f7ff719d834278860a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9b6df605f2aaf607396169bdf907653786e1a851584b49f7ff719d834278860a->enter($__internal_9b6df605f2aaf607396169bdf907653786e1a851584b49f7ff719d834278860a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_9b6df605f2aaf607396169bdf907653786e1a851584b49f7ff719d834278860a->leave($__internal_9b6df605f2aaf607396169bdf907653786e1a851584b49f7ff719d834278860a_prof);

        
        $__internal_24fa35cd1fcc33b154fdd6af7a1e6d5fae20c9037ba60c7884e73959860a66a6->leave($__internal_24fa35cd1fcc33b154fdd6af7a1e6d5fae20c9037ba60c7884e73959860a66a6_prof);

    }

    // line 103
    public function block_body($context, array $blocks = array())
    {
        $__internal_614d016729bb72f32b619402dd804d2eebbfbb27b474f5d70b8051160d9de19d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_614d016729bb72f32b619402dd804d2eebbfbb27b474f5d70b8051160d9de19d->enter($__internal_614d016729bb72f32b619402dd804d2eebbfbb27b474f5d70b8051160d9de19d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_0257ca6f0b97e50b10a3cacd273bedef17e0e3fbf8ec6cddd91736fac0e3cb1c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0257ca6f0b97e50b10a3cacd273bedef17e0e3fbf8ec6cddd91736fac0e3cb1c->enter($__internal_0257ca6f0b97e50b10a3cacd273bedef17e0e3fbf8ec6cddd91736fac0e3cb1c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_0257ca6f0b97e50b10a3cacd273bedef17e0e3fbf8ec6cddd91736fac0e3cb1c->leave($__internal_0257ca6f0b97e50b10a3cacd273bedef17e0e3fbf8ec6cddd91736fac0e3cb1c_prof);

        
        $__internal_614d016729bb72f32b619402dd804d2eebbfbb27b474f5d70b8051160d9de19d->leave($__internal_614d016729bb72f32b619402dd804d2eebbfbb27b474f5d70b8051160d9de19d_prof);

    }

    public function getTemplateName()
    {
        return "menu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  317 => 103,  300 => 101,  288 => 13,  280 => 7,  271 => 6,  259 => 104,  257 => 103,  252 => 101,  243 => 95,  239 => 94,  228 => 85,  222 => 84,  219 => 83,  213 => 81,  210 => 80,  204 => 78,  201 => 77,  195 => 75,  192 => 74,  186 => 72,  183 => 71,  180 => 70,  175 => 69,  169 => 68,  166 => 67,  160 => 65,  157 => 64,  151 => 62,  148 => 61,  142 => 59,  139 => 58,  133 => 56,  130 => 55,  127 => 54,  124 => 53,  120 => 51,  117 => 50,  113 => 48,  110 => 47,  106 => 45,  103 => 44,  99 => 42,  96 => 41,  92 => 39,  89 => 38,  85 => 36,  82 => 35,  79 => 34,  75 => 33,  66 => 27,  62 => 26,  58 => 25,  54 => 24,  50 => 23,  44 => 20,  37 => 15,  35 => 6,  28 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
  <head>
    <meta charset=\"utf-8\">
    <title>Poudlard Academy</title>
    {% block stylesheets %}
      <script src=\"http://code.jquery.com/jquery-1.11.3.js\"></script>
      <link rel=\"stylesheet\"
        href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\"
        integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\"
        crossorigin=\"anonymous\">
      <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>
      <link rel=\"stylesheet\" href=\"{{ asset(\"css/style.css\") }}\"/>
    {% endblock %}
  </head>
  <body>
    <nav class=\"navbar navbar-default\">
      <div class=\"container-fluid\">
        <div class=\"navbar-header\">
          <a class=\"navbar-brand\" href=\"{{ path(\"pw_poudlard_accueil\") }}\">Poudlard Academy</a>
        </div>
        <ul class=\"nav navbar-nav\">
          <li><a>{{app.user.username}}</a></li>
          <li><a>{{actuel.nom}}</a></li>
          <li><a>{{niveau}} /7</a></li>
          <li><a>{{score}}</a></li>
          <li><a>{{argent}} Mornilles</a></li>
          <li class=\"dropdown\">
            <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">Objets
              <span class=\"caret\"></span>
            </a>
            <ul class=\"dropdown-menu\">
              {% for index in 0..9 %}
                {% if index < 6 and articles[index] == niveau %}
                  {% if index == 0 %}
                    <li>Livre de potions</li>
                  {% endif %}
                  {% if index == 1 %}
                    <li>Livre de défenses contre les forces du mal</li>
                  {% endif %}
                  {% if index == 2 %}
                    <li>Livre de divination</li>
                  {% endif %}
                  {% if index == 3 %}
                    <li>Livre de soins aux créatures magiques</li>
                  {% endif %}
                  {% if index == 4 %}
                    <li>Livre de botanique</li>
                  {% endif %}
                  {% if index == 5 %}
                    <li>Livre de sortilèges</li>
                  {% endif %}
                {% endif %}
                {% if index > 5 and articles[index] > 0 %}
                  {% if index == 6 %}
                    <li>Nimbus 2000 x{{articles[index]}}</li>
                  {% endif %}
                  {% if index == 7 %}
                    <li>Eclair de feu x{{articles[index]}}</li>
                  {% endif %}
                  {% if index == 8 %}
                    <li>Baguette en cyprès et ventricule de dragon x{{articles[index]}}</li>
                  {% endif %}
                  {% if index == 9 %}
                    <li>Baguette en sureau et plume de phénix :{{articles[index]}}</li>
                  {% endif %}
                {% endif %}
              {% endfor %}
              {% for i in 0..3 %}
                {% if objets[i] > 0 %}
                  {% if i == 0 %}
                    <li>Viande x{{objets[i]}}</li>
                  {% endif %}
                  {% if i == 1 %}
                    <li>Bois x{{objets[i]}}</li>
                  {% endif %}
                  {% if i == 2 %}
                    <li>Cape x{{objets[i]}}</li>
                  {% endif %}
                  {% if i == 3 %}
                    <li>Jouets x{{objets[i]}}</li>
                  {% endif %}
                {% endif %}
              {% endfor %}
            </ul>
          </li>
        </ul>
        <ul class=\"nav navbar-nav navbar-right\">
          <li class=\"dropdown\">
            <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">Menu
              <span class=\"caret\"></span>
            </a>
            <ul class=\"dropdown-menu\">
              <li><a href=\"{{ path(\"pw_poudlard_affichagePerso\") }}\">Affichage des personnages</a></li>
              <li><a href=\"{{ path(\"pw_poudlard_compte\") }}\">Compte</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
    <h1 class=\"text-center\">{% block title %}{% endblock %}</h1>
    <br>
    {% block body %}{% endblock %}
  </body>
</html>
", "menu.html.twig", "/home/betty/S6/PW6/projetweb/projetweb/app/Resources/views/menu.html.twig");
    }
}
