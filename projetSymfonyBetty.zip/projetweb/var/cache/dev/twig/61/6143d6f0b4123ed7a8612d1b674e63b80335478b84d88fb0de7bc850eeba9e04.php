<?php

/* PWPoudlardBundle:Default:changerAvatar.html.twig */
class __TwigTemplate_7f061ebceecb9cfc9e39f1ef42417a9de0102e5a95696b8601e6d0212099dd1e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("menu.html.twig", "PWPoudlardBundle:Default:changerAvatar.html.twig", 3);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "menu.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a824732cce9d32dcf6d15830d683344cc0fa44947cda24ec36351dbb09b2e8dc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a824732cce9d32dcf6d15830d683344cc0fa44947cda24ec36351dbb09b2e8dc->enter($__internal_a824732cce9d32dcf6d15830d683344cc0fa44947cda24ec36351dbb09b2e8dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PWPoudlardBundle:Default:changerAvatar.html.twig"));

        $__internal_fd7836d1cbaacbc0da8414e4a88a6e24f4c484960133008ea1b6679eee5ba225 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fd7836d1cbaacbc0da8414e4a88a6e24f4c484960133008ea1b6679eee5ba225->enter($__internal_fd7836d1cbaacbc0da8414e4a88a6e24f4c484960133008ea1b6679eee5ba225_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PWPoudlardBundle:Default:changerAvatar.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a824732cce9d32dcf6d15830d683344cc0fa44947cda24ec36351dbb09b2e8dc->leave($__internal_a824732cce9d32dcf6d15830d683344cc0fa44947cda24ec36351dbb09b2e8dc_prof);

        
        $__internal_fd7836d1cbaacbc0da8414e4a88a6e24f4c484960133008ea1b6679eee5ba225->leave($__internal_fd7836d1cbaacbc0da8414e4a88a6e24f4c484960133008ea1b6679eee5ba225_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_5d3b7d080fb90ac03e9917df5f26c5ba7a4e0631c083fdeaad4f5253e6166f00 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5d3b7d080fb90ac03e9917df5f26c5ba7a4e0631c083fdeaad4f5253e6166f00->enter($__internal_5d3b7d080fb90ac03e9917df5f26c5ba7a4e0631c083fdeaad4f5253e6166f00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_4c7787fcb99681efd5dcc769f73cd091990e1c7a05b41714c35a5e8ff46b91d6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4c7787fcb99681efd5dcc769f73cd091990e1c7a05b41714c35a5e8ff46b91d6->enter($__internal_4c7787fcb99681efd5dcc769f73cd091990e1c7a05b41714c35a5e8ff46b91d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 6
        echo "Change ton avatar
  ";
        
        $__internal_4c7787fcb99681efd5dcc769f73cd091990e1c7a05b41714c35a5e8ff46b91d6->leave($__internal_4c7787fcb99681efd5dcc769f73cd091990e1c7a05b41714c35a5e8ff46b91d6_prof);

        
        $__internal_5d3b7d080fb90ac03e9917df5f26c5ba7a4e0631c083fdeaad4f5253e6166f00->leave($__internal_5d3b7d080fb90ac03e9917df5f26c5ba7a4e0631c083fdeaad4f5253e6166f00_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_de2c50d287eb00103a757cf16e50fc74dd99261d9045cedc816818fa486912b6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_de2c50d287eb00103a757cf16e50fc74dd99261d9045cedc816818fa486912b6->enter($__internal_de2c50d287eb00103a757cf16e50fc74dd99261d9045cedc816818fa486912b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_93d28332d4407ee82d926a1f514ed825ab36a986e40380983247ebf4762ca8da = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_93d28332d4407ee82d926a1f514ed825ab36a986e40380983247ebf4762ca8da->enter($__internal_93d28332d4407ee82d926a1f514ed825ab36a986e40380983247ebf4762ca8da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "    <div class =\"container center_div\">
      <form action=\"";
        // line 11
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pw_poudlard_compte");
        echo "\" method=\"post\">
        <div class=\"form-group\">
          <label for=\"inputFile\">Nouvelle image</label>
          <input type=\"file\" class=\"\" id=\"inputFile\" name=\"inputFile\">
        </div>
        <button type=\"submit\" class=\"btn btn-primary\">C'est parti !</button>
      </form>

    </div>

    ";
        
        $__internal_93d28332d4407ee82d926a1f514ed825ab36a986e40380983247ebf4762ca8da->leave($__internal_93d28332d4407ee82d926a1f514ed825ab36a986e40380983247ebf4762ca8da_prof);

        
        $__internal_de2c50d287eb00103a757cf16e50fc74dd99261d9045cedc816818fa486912b6->leave($__internal_de2c50d287eb00103a757cf16e50fc74dd99261d9045cedc816818fa486912b6_prof);

    }

    public function getTemplateName()
    {
        return "PWPoudlardBundle:Default:changerAvatar.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 11,  70 => 10,  61 => 9,  50 => 6,  41 => 5,  11 => 3,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("

  {% extends \"menu.html.twig\" %}

  {% block title %}
Change ton avatar
  {% endblock %}

  {% block body %}
    <div class =\"container center_div\">
      <form action=\"{{ path('pw_poudlard_compte') }}\" method=\"post\">
        <div class=\"form-group\">
          <label for=\"inputFile\">Nouvelle image</label>
          <input type=\"file\" class=\"\" id=\"inputFile\" name=\"inputFile\">
        </div>
        <button type=\"submit\" class=\"btn btn-primary\">C'est parti !</button>
      </form>

    </div>

    {% endblock %}
", "PWPoudlardBundle:Default:changerAvatar.html.twig", "/home/betty/S6/PW6/projetweb/projetweb/src/PW/PoudlardBundle/Resources/views/Default/changerAvatar.html.twig");
    }
}
