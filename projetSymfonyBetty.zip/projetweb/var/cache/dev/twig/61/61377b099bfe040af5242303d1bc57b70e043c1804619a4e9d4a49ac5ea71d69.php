<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_87c54b94642b5acb5f8392769c9f7cda27b8679021e0bbdc2603da56cb6339b7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_78a73cea217417e16b057f3d67a0c5f0e05f9008c7b05421743b00e9b5c44127 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_78a73cea217417e16b057f3d67a0c5f0e05f9008c7b05421743b00e9b5c44127->enter($__internal_78a73cea217417e16b057f3d67a0c5f0e05f9008c7b05421743b00e9b5c44127_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        $__internal_b077c63db4b6f9a7bfcd1630199268df0888868505ab76b5b688fb0f56e9cd4a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b077c63db4b6f9a7bfcd1630199268df0888868505ab76b5b688fb0f56e9cd4a->enter($__internal_b077c63db4b6f9a7bfcd1630199268df0888868505ab76b5b688fb0f56e9cd4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_78a73cea217417e16b057f3d67a0c5f0e05f9008c7b05421743b00e9b5c44127->leave($__internal_78a73cea217417e16b057f3d67a0c5f0e05f9008c7b05421743b00e9b5c44127_prof);

        
        $__internal_b077c63db4b6f9a7bfcd1630199268df0888868505ab76b5b688fb0f56e9cd4a->leave($__internal_b077c63db4b6f9a7bfcd1630199268df0888868505ab76b5b688fb0f56e9cd4a_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "TwigBundle:Exception:error.atom.twig", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.atom.twig");
    }
}
