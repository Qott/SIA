<?php

/* @Framework/Form/number_widget.html.php */
class __TwigTemplate_5f6ec7f51f2d51e10ad09ad7f2f36fcd1e8d01be6d18aa5fbd82ae21ca0f6871 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2e2641e94ad791eb356bbfeba3f5354d11bad07501a026b70e8f780af8c4762e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2e2641e94ad791eb356bbfeba3f5354d11bad07501a026b70e8f780af8c4762e->enter($__internal_2e2641e94ad791eb356bbfeba3f5354d11bad07501a026b70e8f780af8c4762e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        $__internal_ce3dcdeb3fea961efab36f6c6a8d62f5ef434f4c1dd7fdf4b064a239e9c9890f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ce3dcdeb3fea961efab36f6c6a8d62f5ef434f4c1dd7fdf4b064a239e9c9890f->enter($__internal_ce3dcdeb3fea961efab36f6c6a8d62f5ef434f4c1dd7fdf4b064a239e9c9890f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?>
";
        
        $__internal_2e2641e94ad791eb356bbfeba3f5354d11bad07501a026b70e8f780af8c4762e->leave($__internal_2e2641e94ad791eb356bbfeba3f5354d11bad07501a026b70e8f780af8c4762e_prof);

        
        $__internal_ce3dcdeb3fea961efab36f6c6a8d62f5ef434f4c1dd7fdf4b064a239e9c9890f->leave($__internal_ce3dcdeb3fea961efab36f6c6a8d62f5ef434f4c1dd7fdf4b064a239e9c9890f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/number_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?>
", "@Framework/Form/number_widget.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/number_widget.html.php");
    }
}
