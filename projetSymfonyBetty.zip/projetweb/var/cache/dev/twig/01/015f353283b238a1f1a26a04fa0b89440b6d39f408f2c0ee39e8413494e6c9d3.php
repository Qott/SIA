<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_aaefabb95fdb057edc91b57e65ad07320397beccb8b0c0616689c51bac6073bb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d637ad8ad6951c2c711fb371f7a041f64afa7bd79d6bb969a1363f071bd7ca3c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d637ad8ad6951c2c711fb371f7a041f64afa7bd79d6bb969a1363f071bd7ca3c->enter($__internal_d637ad8ad6951c2c711fb371f7a041f64afa7bd79d6bb969a1363f071bd7ca3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        $__internal_9b6be76c0b3e66eaa86218a00de39d45bd172454bab32de8cf5c43cf35a43067 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9b6be76c0b3e66eaa86218a00de39d45bd172454bab32de8cf5c43cf35a43067->enter($__internal_9b6be76c0b3e66eaa86218a00de39d45bd172454bab32de8cf5c43cf35a43067_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_d637ad8ad6951c2c711fb371f7a041f64afa7bd79d6bb969a1363f071bd7ca3c->leave($__internal_d637ad8ad6951c2c711fb371f7a041f64afa7bd79d6bb969a1363f071bd7ca3c_prof);

        
        $__internal_9b6be76c0b3e66eaa86218a00de39d45bd172454bab32de8cf5c43cf35a43067->leave($__internal_9b6be76c0b3e66eaa86218a00de39d45bd172454bab32de8cf5c43cf35a43067_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_08a12be4078867b9585fa0a01b4ad6b91fbc3e3bbc654433e22973d25d71e93c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_08a12be4078867b9585fa0a01b4ad6b91fbc3e3bbc654433e22973d25d71e93c->enter($__internal_08a12be4078867b9585fa0a01b4ad6b91fbc3e3bbc654433e22973d25d71e93c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_906b82d70f9e7b2082661d471c263df00acc715e2dd3ba9f218965dcbf08b3b1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_906b82d70f9e7b2082661d471c263df00acc715e2dd3ba9f218965dcbf08b3b1->enter($__internal_906b82d70f9e7b2082661d471c263df00acc715e2dd3ba9f218965dcbf08b3b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_906b82d70f9e7b2082661d471c263df00acc715e2dd3ba9f218965dcbf08b3b1->leave($__internal_906b82d70f9e7b2082661d471c263df00acc715e2dd3ba9f218965dcbf08b3b1_prof);

        
        $__internal_08a12be4078867b9585fa0a01b4ad6b91fbc3e3bbc654433e22973d25d71e93c->leave($__internal_08a12be4078867b9585fa0a01b4ad6b91fbc3e3bbc654433e22973d25d71e93c_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
