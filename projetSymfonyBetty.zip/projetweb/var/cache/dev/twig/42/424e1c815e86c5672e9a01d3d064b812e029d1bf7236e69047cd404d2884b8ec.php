<?php

/* @WebProfiler/Icon/forward.svg */
class __TwigTemplate_751fbc78a93790c34e0fae1baf68b6aaebf92bd356ae9595cb619249bd1e0367 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d63158bb8dc047c757cf90ebee0d7e2e60980035e38875fb1014676e0da99d2c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d63158bb8dc047c757cf90ebee0d7e2e60980035e38875fb1014676e0da99d2c->enter($__internal_d63158bb8dc047c757cf90ebee0d7e2e60980035e38875fb1014676e0da99d2c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Icon/forward.svg"));

        $__internal_867f06764537fe9dfdf04ca25a533776d52e347330c643dd52c4fd93f91e9162 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_867f06764537fe9dfdf04ca25a533776d52e347330c643dd52c4fd93f91e9162->enter($__internal_867f06764537fe9dfdf04ca25a533776d52e347330c643dd52c4fd93f91e9162_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Icon/forward.svg"));

        // line 1
        echo "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\">
    <path style=\"fill:#aaa\" d=\"M23.61,11.07L17.07,4.35A1.2,1.2,0,0,0,15,5.28V9H1.4A1.82,1.82,0,0,0,0,10.82v2.61A1.55,
        1.55,0,0,0,1.4,15H15v3.72a1.2,1.2,0,0,0,2.07.93l6.63-6.72A1.32,1.32,0,0,0,23.61,11.07Z\"/>
</svg>
";
        
        $__internal_d63158bb8dc047c757cf90ebee0d7e2e60980035e38875fb1014676e0da99d2c->leave($__internal_d63158bb8dc047c757cf90ebee0d7e2e60980035e38875fb1014676e0da99d2c_prof);

        
        $__internal_867f06764537fe9dfdf04ca25a533776d52e347330c643dd52c4fd93f91e9162->leave($__internal_867f06764537fe9dfdf04ca25a533776d52e347330c643dd52c4fd93f91e9162_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Icon/forward.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\">
    <path style=\"fill:#aaa\" d=\"M23.61,11.07L17.07,4.35A1.2,1.2,0,0,0,15,5.28V9H1.4A1.82,1.82,0,0,0,0,10.82v2.61A1.55,
        1.55,0,0,0,1.4,15H15v3.72a1.2,1.2,0,0,0,2.07.93l6.63-6.72A1.32,1.32,0,0,0,23.61,11.07Z\"/>
</svg>
", "@WebProfiler/Icon/forward.svg", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Icon/forward.svg");
    }
}
