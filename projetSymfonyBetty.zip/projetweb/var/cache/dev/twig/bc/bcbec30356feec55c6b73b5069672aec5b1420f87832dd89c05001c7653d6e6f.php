<?php

/* PWPoudlardBundle:Default:accueil.html.twig */
class __TwigTemplate_1f9feea81e2ede7a0cd6f3ea6cf851e01387c4c292522928fe01416607b2f997 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("menu.html.twig", "PWPoudlardBundle:Default:accueil.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "menu.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_304c70a8fe448e371d972d41e0e8f158d2ddc7974928863dab0d72ae4c982d13 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_304c70a8fe448e371d972d41e0e8f158d2ddc7974928863dab0d72ae4c982d13->enter($__internal_304c70a8fe448e371d972d41e0e8f158d2ddc7974928863dab0d72ae4c982d13_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PWPoudlardBundle:Default:accueil.html.twig"));

        $__internal_c5dae844f737aaaecb65e35f678ee0d3a1bd8f2a380fe6c88307ce319d19adde = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c5dae844f737aaaecb65e35f678ee0d3a1bd8f2a380fe6c88307ce319d19adde->enter($__internal_c5dae844f737aaaecb65e35f678ee0d3a1bd8f2a380fe6c88307ce319d19adde_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PWPoudlardBundle:Default:accueil.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_304c70a8fe448e371d972d41e0e8f158d2ddc7974928863dab0d72ae4c982d13->leave($__internal_304c70a8fe448e371d972d41e0e8f158d2ddc7974928863dab0d72ae4c982d13_prof);

        
        $__internal_c5dae844f737aaaecb65e35f678ee0d3a1bd8f2a380fe6c88307ce319d19adde->leave($__internal_c5dae844f737aaaecb65e35f678ee0d3a1bd8f2a380fe6c88307ce319d19adde_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_36e4f6bbc7a8e9929f60b557a4ac6bc5997925b19de573898510d9becfab7131 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_36e4f6bbc7a8e9929f60b557a4ac6bc5997925b19de573898510d9becfab7131->enter($__internal_36e4f6bbc7a8e9929f60b557a4ac6bc5997925b19de573898510d9becfab7131_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_13e5cf505181acbddd8ddffaa8f3cfad34ed8d4fb658f1a773c8f317ae5f9592 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_13e5cf505181acbddd8ddffaa8f3cfad34ed8d4fb658f1a773c8f317ae5f9592->enter($__internal_13e5cf505181acbddd8ddffaa8f3cfad34ed8d4fb658f1a773c8f317ae5f9592_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "  Bienvenue à Poudlard, ";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "username", array()), "html", null, true);
        echo " !
  <br>
  Que veux-tu faire aujourd'hui ?
";
        
        $__internal_13e5cf505181acbddd8ddffaa8f3cfad34ed8d4fb658f1a773c8f317ae5f9592->leave($__internal_13e5cf505181acbddd8ddffaa8f3cfad34ed8d4fb658f1a773c8f317ae5f9592_prof);

        
        $__internal_36e4f6bbc7a8e9929f60b557a4ac6bc5997925b19de573898510d9becfab7131->leave($__internal_36e4f6bbc7a8e9929f60b557a4ac6bc5997925b19de573898510d9becfab7131_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_faa27be863b54c7549e0cfb91cb55b5c60313eeda3834931aa057985921a1899 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_faa27be863b54c7549e0cfb91cb55b5c60313eeda3834931aa057985921a1899->enter($__internal_faa27be863b54c7549e0cfb91cb55b5c60313eeda3834931aa057985921a1899_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_649ee9c0dcba5e8a9cc8961cc1d7f867327b0647221939bfdb5c5d56ec1b9448 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_649ee9c0dcba5e8a9cc8961cc1d7f867327b0647221939bfdb5c5d56ec1b9448->enter($__internal_649ee9c0dcba5e8a9cc8961cc1d7f867327b0647221939bfdb5c5d56ec1b9448_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "  <div class=\"container-fluid\">
    <div class=\"row\">
      <div class=\"col-sm-4\">
        <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
          <h2 class=\"text-center\">Aller en cours de :</h2>
          <div class=\"dropdown\">
            <button class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">Choisir un cours
              <span class=\"caret\"></span>
            </button>
            <ul class=\"dropdown-menu\">
              ";
        // line 20
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range(0, 5));
        foreach ($context['_seq'] as $context["_key"] => $context["index"]) {
            // line 21
            echo "                ";
            if (($this->getAttribute(($context["articles"] ?? $this->getContext($context, "articles")), $context["index"], array(), "array") == ($context["niveau"] ?? $this->getContext($context, "niveau")))) {
                // line 22
                echo "                  ";
                if (($context["index"] == 0)) {
                    // line 23
                    echo "                    ";
                    $context["livre"] = "potions";
                    // line 24
                    echo "                  ";
                } elseif (($context["index"] == 1)) {
                    // line 25
                    echo "                    ";
                    $context["livre"] = "défense contre les forces du mal";
                    // line 26
                    echo "                  ";
                } elseif (($context["index"] == 2)) {
                    // line 27
                    echo "                    ";
                    $context["livre"] = "divination";
                    // line 28
                    echo "                  ";
                } elseif (($context["index"] == 3)) {
                    // line 29
                    echo "                    ";
                    $context["livre"] = "soins aux créatures magiques";
                    // line 30
                    echo "                  ";
                } elseif (($context["index"] == 4)) {
                    // line 31
                    echo "                    ";
                    $context["livre"] = "botanique";
                    // line 32
                    echo "                  ";
                } elseif (($context["index"] == 5)) {
                    // line 33
                    echo "                    ";
                    $context["livre"] = "sortilèges";
                    // line 34
                    echo "                  ";
                }
                // line 35
                echo "                  <li><a data-toggle=\"modal\" id=\"coursClick\">
                    <form action=\"";
                // line 36
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pw_poudlard_accueil");
                echo "\" method=\"post\" id=\"cours\">
                      <input name=\"cours\" type=\"hidden\" value=\"10\" id=\"cours\">
                      ";
                // line 38
                echo twig_escape_filter($this->env, ($context["livre"] ?? $this->getContext($context, "livre")), "html", null, true);
                echo "
                    </form>
                    <script type=\"text/javascript\">
                      \$(\"#coursClick\").click(function() {
                        \$(\"#cours\").submit();
                      });
                    </script>
                  </a></li>

                  ";
                // line 47
                if (($context["cours"] ?? $this->getContext($context, "cours"))) {
                    // line 48
                    echo "                    <div id=\"modal_";
                    echo twig_escape_filter($this->env, ($context["livre"] ?? $this->getContext($context, "livre")), "html", null, true);
                    echo "\" class=\"modal fade in\" role=\"dialog\" style=\"display:block;\">
                      <div class=\"modal-dialog\">
                        <div class=\"modal-content\">
                          <div class=\"modal-body\">
                            <p>
                              Vous avez assisté au cours de ";
                    // line 53
                    echo twig_escape_filter($this->env, ($context["livre"] ?? $this->getContext($context, "livre")), "html", null, true);
                    echo ".
                              <br>
                              Vous gagnez 10 points
                            </p>
                          </div>
                          <div class=\"modal-footer\">
                            <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" onclick=\"fermeModal('modal_";
                    // line 59
                    echo twig_escape_filter($this->env, ($context["livre"] ?? $this->getContext($context, "livre")), "html", null, true);
                    echo "');\">Fermer</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ";
                }
                // line 65
                echo "                ";
            }
            // line 66
            echo "
              ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['index'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 68
        echo "
              <!-- <li><a data-toggle=\"modal\" data-target=\"#modal_potions\">potions</a></li>
              <li><a data-toggle=\"modal\" data-target=\"#modal_defense\">défense contre les forces du mal</a></li>
              <li><a data-toggle=\"modal\" data-target=\"#modal_divination\">divination</a></li>
              <li><a data-toggle=\"modal\" data-target=\"#modal_creatures\">soins aux créatures magiques</a></li>
              <li><a data-toggle=\"modal\" data-target=\"#modal_botanique\">botanique</a></li>
              <li><a data-toggle=\"modal\" data-target=\"#modal_sortileges\">sortilèges</a></li> -->
            </ul>
          </div>
          <br>
          <img src=\"";
        // line 78
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("image/cours.jpg"), "html", null, true);
        echo "\" alt=\"Cours\" class=\"col-sm-12\" id=\"images\"/>
        </div>
      </div>

      <!-- <div id=\"modal_potions\" class=\"modal fade\" role=\"dialog\">
        <div class=\"modal-dialog\">
          <div class=\"modal-content\">
            <div class=\"modal-body\">
              <p>
                Vous avez assisté au cours de potions.
                <br>
                Vous gagnez 10 points
              </p>
            </div>
            <div class=\"modal-footer\">
              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Fermer</button>
            </div>
          </div>
        </div>
      </div>
      <div id=\"modal_defense\" class=\"modal fade\" role=\"dialog\">
        <div class=\"modal-dialog\">
          <div class=\"modal-content\">
            <div class=\"modal-body\">
              <p>
                Vous avez assisté au cours de défense contre les forces du mal.
                <br>
                Vous gagnez 10 points
              </p>
            </div>
            <div class=\"modal-footer\">
              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Fermer</button>
            </div>
          </div>
        </div>
      </div>
      <div id=\"modal_divination\" class=\"modal fade\" role=\"dialog\">
        <div class=\"modal-dialog\">
          <div class=\"modal-content\">
            <div class=\"modal-body\">
              <p>
                Vous avez assisté au cours de divination.
                <br>
                Vous gagnez 10 points
              </p>
            </div>
            <div class=\"modal-footer\">
              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Fermer</button>
            </div>
          </div>
        </div>
      </div>
      <div id=\"modal_creatures\" class=\"modal fade\" role=\"dialog\">
        <div class=\"modal-dialog\">
          <div class=\"modal-content\">
            <div class=\"modal-body\">
              <p>
                Vous avez assisté au cours de soins aux créatures magiques.
                <br>
                Vous gagnez 10 points
              </p>
            </div>
            <div class=\"modal-footer\">
              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Fermer</button>
            </div>
          </div>
        </div>
      </div>
      <div id=\"modal_botanique\" class=\"modal fade\" role=\"dialog\">
        <div class=\"modal-dialog\">
          <div class=\"modal-content\">
            <div class=\"modal-body\">
              <p>
                Vous avez assisté au cours de botanique.
                <br>
                Vous gagnez 10 points
              </p>
            </div>
            <div class=\"modal-footer\">
              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Fermer</button>
            </div>
          </div>
        </div>
      </div>
      <div id=\"modal_sortileges\" class=\"modal fade\" role=\"dialog\">
        <div class=\"modal-dialog\">
          <div class=\"modal-content\">
            <div class=\"modal-body\">
              <p>
                Vous avez assisté au cours de sortilèges.
                <br>
                Vous gagnez 10 points
              </p>
            </div>
            <div class=\"modal-footer\">
              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Fermer</button>
            </div>
          </div>
        </div>
      </div> -->

      <div class=\"col-sm-4\">
        <a data-toggle=\"modal\" id=\"buClick\">
          <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
            <form action=\"";
        // line 182
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pw_poudlard_accueil");
        echo "\" method=\"post\" id=\"bu\">
              <input name=\"bu\" type=\"hidden\" value=\"7\">
              <h2 class=\"text-center\">Aller à la bibliothèque</h2>
              <br>
              <img src=\"";
        // line 186
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("image/bibliotheque.jpg"), "html", null, true);
        echo "\" alt=\"Bibliothèque\" class=\"col-sm-12\" id=\"images\"/>
            </form>

            <script type=\"text/javascript\">
              \$(\"#buClick\").click(function() {
                \$(\"#bu\").submit();
              });
            </script>
          </div>
        </a>
      </div>

      ";
        // line 198
        if (($context["bu"] ?? $this->getContext($context, "bu"))) {
            // line 199
            echo "        <div id=\"modal_bibliotheque\" class=\"modal fade in\" role=\"dialog\" style=\"display:block;\">
          <div class=\"modal-dialog\">
            <div class=\"modal-content\">
              <div class=\"modal-body\">
                <p>
                  ";
            // line 204
            if (($context["time"] ?? $this->getContext($context, "time"))) {
                // line 205
                echo "                    Vos recherches ont été fructueuses.
                    <br>
                    Vous gagnez 7 points
                  ";
            } else {
                // line 209
                echo "                    Vous ne pouvez pas encore aller à la bibliothèque ! Attendez quelques minutes...
                  ";
            }
            // line 211
            echo "                </p>
              </div>
              <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" onclick=\"fermeModal('modal_bibliotheque');\">Fermer</button>
              </div>
            </div>
          </div>
        </div>
      ";
        }
        // line 220
        echo "
      <div class=\"col-sm-4\">
        <a data-toggle=\"modal\" id=\"quidClick\">
          <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
            <form action=\"";
        // line 224
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pw_poudlard_accueil");
        echo "\" name=\"form_quid\" method=\"post\" id=\"quid\">
              <input name=\"quid\" type=\"hidden\" value=\"\" id=\"input_value\">
              <script type=\"text/javascript\">
                if(";
        // line 227
        echo twig_escape_filter($this->env, ($context["niveau"] ?? $this->getContext($context, "niveau")), "html", null, true);
        echo " > 1) {
                  var r = Math.random();
                  if(r < 0.5) {
                    document.forms[\"form_quid\"].elements[\"quid\"].value = \"gain\";
                  } else {
                    document.forms[\"form_quid\"].elements[\"quid\"].value = \"perte\";
                  }
                } else {
                  document.forms[\"form_quid\"].elements[\"quid\"].value = \"niv\";
                }
              </script>
              <h2 class=\"text-center\">Jouer au Quidditch</h2>
              <br>
              <img src=\"";
        // line 240
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("image/quidditch.jpg"), "html", null, true);
        echo "\" alt=\"Quidditch\" class=\"col-sm-12\" id=\"images\"/>
            </form>

            <script type=\"text/javascript\">
              if(";
        // line 244
        echo twig_escape_filter($this->env, ($context["niveau"] ?? $this->getContext($context, "niveau")), "html", null, true);
        echo " > 1) {
                \$(\"#quidClick\").click(function() {
                  \$(\"#quid\").submit();
                });
              }
            </script>
          </div>
        </a>
      </div>

      ";
        // line 254
        if ((($context["quid"] ?? $this->getContext($context, "quid")) != 0)) {
            // line 255
            echo "        <div id=\"modal_quidditch\" class=\"modal fade in\" role=\"dialog\" style=\"display:block;\">
          <div class=\"modal-dialog\">
            <div class=\"modal-content\">
              <div class=\"modal-body\">
                <p>

                  ";
            // line 261
            if ((($context["quid"] ?? $this->getContext($context, "quid")) == 3)) {
                // line 262
                echo "                    ";
                $context["r"] = twig_random($this->env, 1);
                // line 263
                echo "                    ";
                if ((($context["r"] ?? $this->getContext($context, "r")) == 0)) {
                    // line 264
                    echo "                      L'équipe de votre maison a gagné cette partie !
                    ";
                } else {
                    // line 266
                    echo "                      L'équipe de votre maison a perdu...
                    ";
                }
                // line 268
                echo "                  ";
            } else {
                // line 269
                echo "                    ";
                if ((($context["quid"] ?? $this->getContext($context, "quid")) == 1)) {
                    // line 270
                    echo "                      Vous avez gagné cette partie !
                      <br>
                      Vous gagnez 5 points
                    ";
                }
                // line 274
                echo "                    ";
                if ((($context["quid"] ?? $this->getContext($context, "quid")) == 2)) {
                    // line 275
                    echo "                      Vous avez perdu...
                      <br>
                      Vous gagnez 3 points
                    ";
                }
                // line 279
                echo "                  ";
            }
            // line 280
            echo "
                </p>
              </div>
              <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" onclick=\"fermeModal('modal_quidditch');\">Fermer</button>
              </div>
            </div>
          </div>
        </div>
      ";
        }
        // line 290
        echo "
    </div>

    <div class=\"row\">
      <div class=\"col-sm-4\">
        <a href=\"";
        // line 295
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pw_poudlard_boutique");
        echo "\">
          <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
            <h2 class=\"text-center\">Aller à la boutique</h2>
            <br>
            <img src=\"";
        // line 299
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("image/boutique.jpg"), "html", null, true);
        echo "\" alt=\"Boutique\" class=\"col-sm-12\" id=\"images\"/>
          </div>
        </a>
      </div>

      <div class=\"col-sm-4\">
        <a href=\"";
        // line 305
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pw_poudlard_promener");
        echo "\">
          <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
            <h2 class=\"text-center\">Se promener</h2>
            <br>
            <img src=\"";
        // line 309
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("image/ecole.jpg"), "html", null, true);
        echo "\" alt=\"Promenade\" class=\"col-sm-12\" id=\"images\"/>
          </div>
        </a>
      </div>

      <div class=\"col-sm-4\">
        <a href=\"";
        // line 315
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pw_poudlard_service");
        echo "\">
          <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
            <h2 class=\"text-center\">Rendre un service à Hagrid</h2>
            <br>
            <img src=\"";
        // line 319
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("image/hagrid.jpg"), "html", null, true);
        echo "\" alt=\"Service à Hagrid\" class=\"col-sm-12\" id=\"images\"/>
          </div>
        </a>
      </div>
    </div>
  </div>

  <script type=\"text/javascript\">
    function fermeModal(idSupp) {
      \$(\"#\"+idSupp).css('display', 'none');
    }
  </script>
";
        
        $__internal_649ee9c0dcba5e8a9cc8961cc1d7f867327b0647221939bfdb5c5d56ec1b9448->leave($__internal_649ee9c0dcba5e8a9cc8961cc1d7f867327b0647221939bfdb5c5d56ec1b9448_prof);

        
        $__internal_faa27be863b54c7549e0cfb91cb55b5c60313eeda3834931aa057985921a1899->leave($__internal_faa27be863b54c7549e0cfb91cb55b5c60313eeda3834931aa057985921a1899_prof);

    }

    public function getTemplateName()
    {
        return "PWPoudlardBundle:Default:accueil.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  520 => 319,  513 => 315,  504 => 309,  497 => 305,  488 => 299,  481 => 295,  474 => 290,  462 => 280,  459 => 279,  453 => 275,  450 => 274,  444 => 270,  441 => 269,  438 => 268,  434 => 266,  430 => 264,  427 => 263,  424 => 262,  422 => 261,  414 => 255,  412 => 254,  399 => 244,  392 => 240,  376 => 227,  370 => 224,  364 => 220,  353 => 211,  349 => 209,  343 => 205,  341 => 204,  334 => 199,  332 => 198,  317 => 186,  310 => 182,  203 => 78,  191 => 68,  184 => 66,  181 => 65,  172 => 59,  163 => 53,  154 => 48,  152 => 47,  140 => 38,  135 => 36,  132 => 35,  129 => 34,  126 => 33,  123 => 32,  120 => 31,  117 => 30,  114 => 29,  111 => 28,  108 => 27,  105 => 26,  102 => 25,  99 => 24,  96 => 23,  93 => 22,  90 => 21,  86 => 20,  74 => 10,  65 => 9,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"menu.html.twig\" %}

{% block title %}
  Bienvenue à Poudlard, {{ app.user.username }} !
  <br>
  Que veux-tu faire aujourd'hui ?
{% endblock %}

{% block body %}
  <div class=\"container-fluid\">
    <div class=\"row\">
      <div class=\"col-sm-4\">
        <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
          <h2 class=\"text-center\">Aller en cours de :</h2>
          <div class=\"dropdown\">
            <button class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">Choisir un cours
              <span class=\"caret\"></span>
            </button>
            <ul class=\"dropdown-menu\">
              {% for index in 0..5 %}
                {% if articles[index] == niveau %}
                  {% if index == 0 %}
                    {% set livre = \"potions\" %}
                  {% elseif index == 1 %}
                    {% set livre = \"défense contre les forces du mal\" %}
                  {% elseif index == 2 %}
                    {% set livre = \"divination\" %}
                  {% elseif index == 3 %}
                    {% set livre = \"soins aux créatures magiques\" %}
                  {% elseif index == 4 %}
                    {% set livre = \"botanique\" %}
                  {% elseif index == 5 %}
                    {% set livre = \"sortilèges\" %}
                  {% endif %}
                  <li><a data-toggle=\"modal\" id=\"coursClick\">
                    <form action=\"{{ path('pw_poudlard_accueil') }}\" method=\"post\" id=\"cours\">
                      <input name=\"cours\" type=\"hidden\" value=\"10\" id=\"cours\">
                      {{livre}}
                    </form>
                    <script type=\"text/javascript\">
                      \$(\"#coursClick\").click(function() {
                        \$(\"#cours\").submit();
                      });
                    </script>
                  </a></li>

                  {% if cours %}
                    <div id=\"modal_{{livre}}\" class=\"modal fade in\" role=\"dialog\" style=\"display:block;\">
                      <div class=\"modal-dialog\">
                        <div class=\"modal-content\">
                          <div class=\"modal-body\">
                            <p>
                              Vous avez assisté au cours de {{livre}}.
                              <br>
                              Vous gagnez 10 points
                            </p>
                          </div>
                          <div class=\"modal-footer\">
                            <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" onclick=\"fermeModal('modal_{{livre}}');\">Fermer</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  {% endif %}
                {% endif %}

              {% endfor %}

              <!-- <li><a data-toggle=\"modal\" data-target=\"#modal_potions\">potions</a></li>
              <li><a data-toggle=\"modal\" data-target=\"#modal_defense\">défense contre les forces du mal</a></li>
              <li><a data-toggle=\"modal\" data-target=\"#modal_divination\">divination</a></li>
              <li><a data-toggle=\"modal\" data-target=\"#modal_creatures\">soins aux créatures magiques</a></li>
              <li><a data-toggle=\"modal\" data-target=\"#modal_botanique\">botanique</a></li>
              <li><a data-toggle=\"modal\" data-target=\"#modal_sortileges\">sortilèges</a></li> -->
            </ul>
          </div>
          <br>
          <img src=\"{{ asset(\"image/cours.jpg\") }}\" alt=\"Cours\" class=\"col-sm-12\" id=\"images\"/>
        </div>
      </div>

      <!-- <div id=\"modal_potions\" class=\"modal fade\" role=\"dialog\">
        <div class=\"modal-dialog\">
          <div class=\"modal-content\">
            <div class=\"modal-body\">
              <p>
                Vous avez assisté au cours de potions.
                <br>
                Vous gagnez 10 points
              </p>
            </div>
            <div class=\"modal-footer\">
              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Fermer</button>
            </div>
          </div>
        </div>
      </div>
      <div id=\"modal_defense\" class=\"modal fade\" role=\"dialog\">
        <div class=\"modal-dialog\">
          <div class=\"modal-content\">
            <div class=\"modal-body\">
              <p>
                Vous avez assisté au cours de défense contre les forces du mal.
                <br>
                Vous gagnez 10 points
              </p>
            </div>
            <div class=\"modal-footer\">
              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Fermer</button>
            </div>
          </div>
        </div>
      </div>
      <div id=\"modal_divination\" class=\"modal fade\" role=\"dialog\">
        <div class=\"modal-dialog\">
          <div class=\"modal-content\">
            <div class=\"modal-body\">
              <p>
                Vous avez assisté au cours de divination.
                <br>
                Vous gagnez 10 points
              </p>
            </div>
            <div class=\"modal-footer\">
              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Fermer</button>
            </div>
          </div>
        </div>
      </div>
      <div id=\"modal_creatures\" class=\"modal fade\" role=\"dialog\">
        <div class=\"modal-dialog\">
          <div class=\"modal-content\">
            <div class=\"modal-body\">
              <p>
                Vous avez assisté au cours de soins aux créatures magiques.
                <br>
                Vous gagnez 10 points
              </p>
            </div>
            <div class=\"modal-footer\">
              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Fermer</button>
            </div>
          </div>
        </div>
      </div>
      <div id=\"modal_botanique\" class=\"modal fade\" role=\"dialog\">
        <div class=\"modal-dialog\">
          <div class=\"modal-content\">
            <div class=\"modal-body\">
              <p>
                Vous avez assisté au cours de botanique.
                <br>
                Vous gagnez 10 points
              </p>
            </div>
            <div class=\"modal-footer\">
              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Fermer</button>
            </div>
          </div>
        </div>
      </div>
      <div id=\"modal_sortileges\" class=\"modal fade\" role=\"dialog\">
        <div class=\"modal-dialog\">
          <div class=\"modal-content\">
            <div class=\"modal-body\">
              <p>
                Vous avez assisté au cours de sortilèges.
                <br>
                Vous gagnez 10 points
              </p>
            </div>
            <div class=\"modal-footer\">
              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Fermer</button>
            </div>
          </div>
        </div>
      </div> -->

      <div class=\"col-sm-4\">
        <a data-toggle=\"modal\" id=\"buClick\">
          <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
            <form action=\"{{ path('pw_poudlard_accueil') }}\" method=\"post\" id=\"bu\">
              <input name=\"bu\" type=\"hidden\" value=\"7\">
              <h2 class=\"text-center\">Aller à la bibliothèque</h2>
              <br>
              <img src=\"{{ asset(\"image/bibliotheque.jpg\") }}\" alt=\"Bibliothèque\" class=\"col-sm-12\" id=\"images\"/>
            </form>

            <script type=\"text/javascript\">
              \$(\"#buClick\").click(function() {
                \$(\"#bu\").submit();
              });
            </script>
          </div>
        </a>
      </div>

      {% if bu %}
        <div id=\"modal_bibliotheque\" class=\"modal fade in\" role=\"dialog\" style=\"display:block;\">
          <div class=\"modal-dialog\">
            <div class=\"modal-content\">
              <div class=\"modal-body\">
                <p>
                  {% if time %}
                    Vos recherches ont été fructueuses.
                    <br>
                    Vous gagnez 7 points
                  {% else %}
                    Vous ne pouvez pas encore aller à la bibliothèque ! Attendez quelques minutes...
                  {% endif %}
                </p>
              </div>
              <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" onclick=\"fermeModal('modal_bibliotheque');\">Fermer</button>
              </div>
            </div>
          </div>
        </div>
      {% endif %}

      <div class=\"col-sm-4\">
        <a data-toggle=\"modal\" id=\"quidClick\">
          <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
            <form action=\"{{ path('pw_poudlard_accueil') }}\" name=\"form_quid\" method=\"post\" id=\"quid\">
              <input name=\"quid\" type=\"hidden\" value=\"\" id=\"input_value\">
              <script type=\"text/javascript\">
                if({{ niveau }} > 1) {
                  var r = Math.random();
                  if(r < 0.5) {
                    document.forms[\"form_quid\"].elements[\"quid\"].value = \"gain\";
                  } else {
                    document.forms[\"form_quid\"].elements[\"quid\"].value = \"perte\";
                  }
                } else {
                  document.forms[\"form_quid\"].elements[\"quid\"].value = \"niv\";
                }
              </script>
              <h2 class=\"text-center\">Jouer au Quidditch</h2>
              <br>
              <img src=\"{{ asset(\"image/quidditch.jpg\") }}\" alt=\"Quidditch\" class=\"col-sm-12\" id=\"images\"/>
            </form>

            <script type=\"text/javascript\">
              if({{ niveau }} > 1) {
                \$(\"#quidClick\").click(function() {
                  \$(\"#quid\").submit();
                });
              }
            </script>
          </div>
        </a>
      </div>

      {% if quid != 0 %}
        <div id=\"modal_quidditch\" class=\"modal fade in\" role=\"dialog\" style=\"display:block;\">
          <div class=\"modal-dialog\">
            <div class=\"modal-content\">
              <div class=\"modal-body\">
                <p>

                  {% if quid == 3 %}
                    {% set r = random(1) %}
                    {% if r == 0 %}
                      L'équipe de votre maison a gagné cette partie !
                    {% else %}
                      L'équipe de votre maison a perdu...
                    {% endif %}
                  {% else %}
                    {% if quid == 1 %}
                      Vous avez gagné cette partie !
                      <br>
                      Vous gagnez 5 points
                    {% endif %}
                    {% if quid == 2 %}
                      Vous avez perdu...
                      <br>
                      Vous gagnez 3 points
                    {% endif %}
                  {% endif %}

                </p>
              </div>
              <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" onclick=\"fermeModal('modal_quidditch');\">Fermer</button>
              </div>
            </div>
          </div>
        </div>
      {% endif %}

    </div>

    <div class=\"row\">
      <div class=\"col-sm-4\">
        <a href=\"{{ path(\"pw_poudlard_boutique\") }}\">
          <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
            <h2 class=\"text-center\">Aller à la boutique</h2>
            <br>
            <img src=\"{{ asset(\"image/boutique.jpg\") }}\" alt=\"Boutique\" class=\"col-sm-12\" id=\"images\"/>
          </div>
        </a>
      </div>

      <div class=\"col-sm-4\">
        <a href=\"{{ path(\"pw_poudlard_promener\") }}\">
          <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
            <h2 class=\"text-center\">Se promener</h2>
            <br>
            <img src=\"{{ asset(\"image/ecole.jpg\") }}\" alt=\"Promenade\" class=\"col-sm-12\" id=\"images\"/>
          </div>
        </a>
      </div>

      <div class=\"col-sm-4\">
        <a href=\"{{ path(\"pw_poudlard_service\") }}\">
          <div class=\"col-sm-10 col-sm-push-1\" id=\"border\">
            <h2 class=\"text-center\">Rendre un service à Hagrid</h2>
            <br>
            <img src=\"{{ asset(\"image/hagrid.jpg\") }}\" alt=\"Service à Hagrid\" class=\"col-sm-12\" id=\"images\"/>
          </div>
        </a>
      </div>
    </div>
  </div>

  <script type=\"text/javascript\">
    function fermeModal(idSupp) {
      \$(\"#\"+idSupp).css('display', 'none');
    }
  </script>
{% endblock %}
", "PWPoudlardBundle:Default:accueil.html.twig", "/home/betty/S6/PW6/projetweb/projetweb/src/PW/PoudlardBundle/Resources/views/Default/accueil.html.twig");
    }
}
