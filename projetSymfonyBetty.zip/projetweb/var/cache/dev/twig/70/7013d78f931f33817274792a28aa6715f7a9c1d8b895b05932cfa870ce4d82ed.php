<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_3f4c9cade32f53675f5d1507ee1007bd799aa5f57b44c2fc2f6931c09424bd7f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c536e0cdb66c8dea9bcce278b91762d7911c42fa3e4eb7c12aefcdd76788aa70 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c536e0cdb66c8dea9bcce278b91762d7911c42fa3e4eb7c12aefcdd76788aa70->enter($__internal_c536e0cdb66c8dea9bcce278b91762d7911c42fa3e4eb7c12aefcdd76788aa70_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        $__internal_0677c1bd5af295c4484088d6449aa212d81c97af66b3a130b45b85a83d41f4f3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0677c1bd5af295c4484088d6449aa212d81c97af66b3a130b45b85a83d41f4f3->enter($__internal_0677c1bd5af295c4484088d6449aa212d81c97af66b3a130b45b85a83d41f4f3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_c536e0cdb66c8dea9bcce278b91762d7911c42fa3e4eb7c12aefcdd76788aa70->leave($__internal_c536e0cdb66c8dea9bcce278b91762d7911c42fa3e4eb7c12aefcdd76788aa70_prof);

        
        $__internal_0677c1bd5af295c4484088d6449aa212d81c97af66b3a130b45b85a83d41f4f3->leave($__internal_0677c1bd5af295c4484088d6449aa212d81c97af66b3a130b45b85a83d41f4f3_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->widget(\$form) ?>
", "@Framework/Form/hidden_row.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/hidden_row.html.php");
    }
}
