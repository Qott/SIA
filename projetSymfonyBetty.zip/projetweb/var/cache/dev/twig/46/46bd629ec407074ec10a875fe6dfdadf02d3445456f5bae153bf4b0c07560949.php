<?php

/* ::base.html.twig */
class __TwigTemplate_f03a4114f3bbc06a5a70f78f5c825420debb072cd257afd9f5197056656666db extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_97b9975f9e0105a54c4ea3c2bccee9e14dcb046203c7b4184dfcf2e2b5ea9b87 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_97b9975f9e0105a54c4ea3c2bccee9e14dcb046203c7b4184dfcf2e2b5ea9b87->enter($__internal_97b9975f9e0105a54c4ea3c2bccee9e14dcb046203c7b4184dfcf2e2b5ea9b87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        $__internal_28a113f01119c78867362aba2548ed399b638582b9e7f7b52620b5bff03641fb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_28a113f01119c78867362aba2548ed399b638582b9e7f7b52620b5bff03641fb->enter($__internal_28a113f01119c78867362aba2548ed399b638582b9e7f7b52620b5bff03641fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_97b9975f9e0105a54c4ea3c2bccee9e14dcb046203c7b4184dfcf2e2b5ea9b87->leave($__internal_97b9975f9e0105a54c4ea3c2bccee9e14dcb046203c7b4184dfcf2e2b5ea9b87_prof);

        
        $__internal_28a113f01119c78867362aba2548ed399b638582b9e7f7b52620b5bff03641fb->leave($__internal_28a113f01119c78867362aba2548ed399b638582b9e7f7b52620b5bff03641fb_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_22a252770ebc0092b3bf1bcc8c900dd2ee038c9225cec530358ddf7692a98317 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_22a252770ebc0092b3bf1bcc8c900dd2ee038c9225cec530358ddf7692a98317->enter($__internal_22a252770ebc0092b3bf1bcc8c900dd2ee038c9225cec530358ddf7692a98317_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_236b4d74bb521c4106abaaf4494810be85fdbfa7d6f5b02451b4c67dd393aaa7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_236b4d74bb521c4106abaaf4494810be85fdbfa7d6f5b02451b4c67dd393aaa7->enter($__internal_236b4d74bb521c4106abaaf4494810be85fdbfa7d6f5b02451b4c67dd393aaa7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_236b4d74bb521c4106abaaf4494810be85fdbfa7d6f5b02451b4c67dd393aaa7->leave($__internal_236b4d74bb521c4106abaaf4494810be85fdbfa7d6f5b02451b4c67dd393aaa7_prof);

        
        $__internal_22a252770ebc0092b3bf1bcc8c900dd2ee038c9225cec530358ddf7692a98317->leave($__internal_22a252770ebc0092b3bf1bcc8c900dd2ee038c9225cec530358ddf7692a98317_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_1cbf7d5f2ee9df4663fe6cb4a188ec668da1f45708c33d7cdf01f6fb95d1fa4f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1cbf7d5f2ee9df4663fe6cb4a188ec668da1f45708c33d7cdf01f6fb95d1fa4f->enter($__internal_1cbf7d5f2ee9df4663fe6cb4a188ec668da1f45708c33d7cdf01f6fb95d1fa4f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_32fe2434434a41cc56bd78b04b90392d25bfbb5fc4ba72c74ebe665140c1de3e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_32fe2434434a41cc56bd78b04b90392d25bfbb5fc4ba72c74ebe665140c1de3e->enter($__internal_32fe2434434a41cc56bd78b04b90392d25bfbb5fc4ba72c74ebe665140c1de3e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_32fe2434434a41cc56bd78b04b90392d25bfbb5fc4ba72c74ebe665140c1de3e->leave($__internal_32fe2434434a41cc56bd78b04b90392d25bfbb5fc4ba72c74ebe665140c1de3e_prof);

        
        $__internal_1cbf7d5f2ee9df4663fe6cb4a188ec668da1f45708c33d7cdf01f6fb95d1fa4f->leave($__internal_1cbf7d5f2ee9df4663fe6cb4a188ec668da1f45708c33d7cdf01f6fb95d1fa4f_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_50b1ab1555d27f97ae469a53518059aad683ac0e6af6849fca9a2d97bdc08f87 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_50b1ab1555d27f97ae469a53518059aad683ac0e6af6849fca9a2d97bdc08f87->enter($__internal_50b1ab1555d27f97ae469a53518059aad683ac0e6af6849fca9a2d97bdc08f87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_82ba710ee71746f1d00da1754a9186e5870381bdbcfdd128bbb0e58efbdc42ed = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_82ba710ee71746f1d00da1754a9186e5870381bdbcfdd128bbb0e58efbdc42ed->enter($__internal_82ba710ee71746f1d00da1754a9186e5870381bdbcfdd128bbb0e58efbdc42ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_82ba710ee71746f1d00da1754a9186e5870381bdbcfdd128bbb0e58efbdc42ed->leave($__internal_82ba710ee71746f1d00da1754a9186e5870381bdbcfdd128bbb0e58efbdc42ed_prof);

        
        $__internal_50b1ab1555d27f97ae469a53518059aad683ac0e6af6849fca9a2d97bdc08f87->leave($__internal_50b1ab1555d27f97ae469a53518059aad683ac0e6af6849fca9a2d97bdc08f87_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_1e483ea114b2c0bdce78f7c51c0b8fc3742c1b7afbd6539476484d7304ae3278 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1e483ea114b2c0bdce78f7c51c0b8fc3742c1b7afbd6539476484d7304ae3278->enter($__internal_1e483ea114b2c0bdce78f7c51c0b8fc3742c1b7afbd6539476484d7304ae3278_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_56b740991acc7c3676e3cf0a0a7266841fe3cefad8ab9505d9d9769270cd96ac = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_56b740991acc7c3676e3cf0a0a7266841fe3cefad8ab9505d9d9769270cd96ac->enter($__internal_56b740991acc7c3676e3cf0a0a7266841fe3cefad8ab9505d9d9769270cd96ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_56b740991acc7c3676e3cf0a0a7266841fe3cefad8ab9505d9d9769270cd96ac->leave($__internal_56b740991acc7c3676e3cf0a0a7266841fe3cefad8ab9505d9d9769270cd96ac_prof);

        
        $__internal_1e483ea114b2c0bdce78f7c51c0b8fc3742c1b7afbd6539476484d7304ae3278->leave($__internal_1e483ea114b2c0bdce78f7c51c0b8fc3742c1b7afbd6539476484d7304ae3278_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 11,  100 => 10,  83 => 6,  65 => 5,  53 => 12,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "::base.html.twig", "/home/betty/S6/PW6/projetweb/projetweb/app/Resources/views/base.html.twig");
    }
}
