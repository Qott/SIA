<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_3a850b9d28cdb48dc986b07263c05526f4999b31edacc9ce6e365ca366872178 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5a3e9adf296c1732ee2876fe40e810e4872d3b58a51d2399995cc056e9b5266a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5a3e9adf296c1732ee2876fe40e810e4872d3b58a51d2399995cc056e9b5266a->enter($__internal_5a3e9adf296c1732ee2876fe40e810e4872d3b58a51d2399995cc056e9b5266a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        $__internal_296d3117208c5982f627e60d65bcdc92433f8f07ad6839cd84d284c0384d7599 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_296d3117208c5982f627e60d65bcdc92433f8f07ad6839cd84d284c0384d7599->enter($__internal_296d3117208c5982f627e60d65bcdc92433f8f07ad6839cd84d284c0384d7599_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_5a3e9adf296c1732ee2876fe40e810e4872d3b58a51d2399995cc056e9b5266a->leave($__internal_5a3e9adf296c1732ee2876fe40e810e4872d3b58a51d2399995cc056e9b5266a_prof);

        
        $__internal_296d3117208c5982f627e60d65bcdc92433f8f07ad6839cd84d284c0384d7599->leave($__internal_296d3117208c5982f627e60d65bcdc92433f8f07ad6839cd84d284c0384d7599_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
", "@Framework/Form/collection_widget.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/collection_widget.html.php");
    }
}
