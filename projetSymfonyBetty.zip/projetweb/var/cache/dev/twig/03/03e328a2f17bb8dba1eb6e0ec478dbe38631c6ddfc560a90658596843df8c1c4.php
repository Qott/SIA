<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_bd9138c75d34683d1be6dab69d393fcdf5948f03f5be714a6a2d77b604181883 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_94da5279f465e1ac79d0e4b3b4a124d1a74d9f376d3ea091982b3866e54381f6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_94da5279f465e1ac79d0e4b3b4a124d1a74d9f376d3ea091982b3866e54381f6->enter($__internal_94da5279f465e1ac79d0e4b3b4a124d1a74d9f376d3ea091982b3866e54381f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        $__internal_c55e71a0d56faa9cc04440f161e620baac2506295cac2d1448e50b601f5277db = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c55e71a0d56faa9cc04440f161e620baac2506295cac2d1448e50b601f5277db->enter($__internal_c55e71a0d56faa9cc04440f161e620baac2506295cac2d1448e50b601f5277db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_94da5279f465e1ac79d0e4b3b4a124d1a74d9f376d3ea091982b3866e54381f6->leave($__internal_94da5279f465e1ac79d0e4b3b4a124d1a74d9f376d3ea091982b3866e54381f6_prof);

        
        $__internal_c55e71a0d56faa9cc04440f161e620baac2506295cac2d1448e50b601f5277db->leave($__internal_c55e71a0d56faa9cc04440f161e620baac2506295cac2d1448e50b601f5277db_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/form_row.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/FormTable/form_row.html.php");
    }
}
