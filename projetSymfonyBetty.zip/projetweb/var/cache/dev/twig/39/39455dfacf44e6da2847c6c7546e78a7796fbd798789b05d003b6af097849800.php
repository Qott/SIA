<?php

/* PWPoudlardBundle:Default:choixPerso.html.twig */
class __TwigTemplate_cab4ac556f38b7c2ebc5bc02ae75f846f12060d89d63e7fb1435da1ddf25288a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cad23f5295ee6f34c1d9c7de9ad931f185bbec6e356f5e9791c2adada478f379 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cad23f5295ee6f34c1d9c7de9ad931f185bbec6e356f5e9791c2adada478f379->enter($__internal_cad23f5295ee6f34c1d9c7de9ad931f185bbec6e356f5e9791c2adada478f379_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PWPoudlardBundle:Default:choixPerso.html.twig"));

        $__internal_97e847514f491a69e7d2d88f1a580552b00d7dda8737b4473b267e76109cc384 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_97e847514f491a69e7d2d88f1a580552b00d7dda8737b4473b267e76109cc384->enter($__internal_97e847514f491a69e7d2d88f1a580552b00d7dda8737b4473b267e76109cc384_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PWPoudlardBundle:Default:choixPerso.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
  <head>
    <meta charset=\"utf-8\">
    <script src=\"http://code.jquery.com/jquery-1.11.3.js\"></script>
    <link rel=\"stylesheet\"
      href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\"
      integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\"
      crossorigin=\"anonymous\">
    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>
    <link rel=\"stylesheet\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/choixPerso.css"), "html", null, true);
        echo "\"/>
    <link rel=\"stylesheet\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\"/>
    <title>Poudlard Academy</title>
  </head>
  <body>
    <h1 class=\"text-center\">Choisis ton personnage</h1>
    <br>

    <div class=\"container-fluid\">
      ";
        // line 20
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["persos"] ?? $this->getContext($context, "persos")));
        foreach ($context['_seq'] as $context["_key"] => $context["perso"]) {
            // line 21
            echo "        <div class=\"col-sm-3\" id=\"border\">
          <a>
            <form action=\"";
            // line 23
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pw_poudlard_accueil");
            echo "\" method=\"post\"  id=\"choix";
            echo twig_escape_filter($this->env, $this->getAttribute($context["perso"], "id", array()), "html", null, true);
            echo "\">
              <input name=\"perso\" type=\"hidden\" value=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["perso"], "id", array()), "html", null, true);
            echo "\" id=\"perso\">
              <h2 class=\"text-center\">";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($context["perso"], "nom", array()), "html", null, true);
            echo "</h2>
              <img src=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($context["perso"], "image", array()), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["perso"], "nom", array()), "html", null, true);
            echo "\" class=\"col-sm-12\" id=\"image";
            echo twig_escape_filter($this->env, $this->getAttribute($context["perso"], "id", array()), "html", null, true);
            echo "\"/>
              ";
            // line 27
            if (($this->getAttribute($context["perso"], "maison", array()) == 1)) {
                // line 28
                echo "                ";
                $context["maison"] = "Gryffondor";
                // line 29
                echo "              ";
            } elseif (($this->getAttribute($context["perso"], "maison", array()) == 2)) {
                // line 30
                echo "                ";
                $context["maison"] = "Poufsouffle";
                // line 31
                echo "              ";
            } elseif (($this->getAttribute($context["perso"], "maison", array()) == 3)) {
                // line 32
                echo "                ";
                $context["maison"] = "Serpentard";
                // line 33
                echo "              ";
            } elseif (($this->getAttribute($context["perso"], "maison", array()) == 4)) {
                // line 34
                echo "                ";
                $context["maison"] = "Serdaigle";
                // line 35
                echo "              ";
            }
            // line 36
            echo "              <p class=\"text-center\">Maison : ";
            echo twig_escape_filter($this->env, ($context["maison"] ?? $this->getContext($context, "maison")), "html", null, true);
            echo "</p>
            </form>

            <script type=\"text/javascript\">
              \$(\"#image";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($context["perso"], "id", array()), "html", null, true);
            echo "\").click(function() {
                \$(\"#choix";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute($context["perso"], "id", array()), "html", null, true);
            echo "\").submit();
              });
            </script>
          </a>
        </div>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['perso'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 47
        echo "    </div>
  </body>
</html>
";
        
        $__internal_cad23f5295ee6f34c1d9c7de9ad931f185bbec6e356f5e9791c2adada478f379->leave($__internal_cad23f5295ee6f34c1d9c7de9ad931f185bbec6e356f5e9791c2adada478f379_prof);

        
        $__internal_97e847514f491a69e7d2d88f1a580552b00d7dda8737b4473b267e76109cc384->leave($__internal_97e847514f491a69e7d2d88f1a580552b00d7dda8737b4473b267e76109cc384_prof);

    }

    public function getTemplateName()
    {
        return "PWPoudlardBundle:Default:choixPerso.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  132 => 47,  120 => 41,  116 => 40,  108 => 36,  105 => 35,  102 => 34,  99 => 33,  96 => 32,  93 => 31,  90 => 30,  87 => 29,  84 => 28,  82 => 27,  74 => 26,  70 => 25,  66 => 24,  60 => 23,  56 => 21,  52 => 20,  41 => 12,  37 => 11,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
  <head>
    <meta charset=\"utf-8\">
    <script src=\"http://code.jquery.com/jquery-1.11.3.js\"></script>
    <link rel=\"stylesheet\"
      href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\"
      integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\"
      crossorigin=\"anonymous\">
    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>
    <link rel=\"stylesheet\" href=\"{{ asset(\"css/choixPerso.css\") }}\"/>
    <link rel=\"stylesheet\" href=\"{{ asset(\"css/style.css\") }}\"/>
    <title>Poudlard Academy</title>
  </head>
  <body>
    <h1 class=\"text-center\">Choisis ton personnage</h1>
    <br>

    <div class=\"container-fluid\">
      {% for perso in persos %}
        <div class=\"col-sm-3\" id=\"border\">
          <a>
            <form action=\"{{ path('pw_poudlard_accueil') }}\" method=\"post\"  id=\"choix{{perso.id}}\">
              <input name=\"perso\" type=\"hidden\" value=\"{{perso.id}}\" id=\"perso\">
              <h2 class=\"text-center\">{{perso.nom}}</h2>
              <img src=\"{{perso.image}}\" alt=\"{{perso.nom}}\" class=\"col-sm-12\" id=\"image{{perso.id}}\"/>
              {% if perso.maison == 1 %}
                {% set maison = \"Gryffondor\" %}
              {% elseif perso.maison == 2 %}
                {% set maison = \"Poufsouffle\" %}
              {% elseif perso.maison == 3 %}
                {% set maison = \"Serpentard\" %}
              {% elseif perso.maison == 4 %}
                {% set maison = \"Serdaigle\" %}
              {% endif %}
              <p class=\"text-center\">Maison : {{maison}}</p>
            </form>

            <script type=\"text/javascript\">
              \$(\"#image{{perso.id}}\").click(function() {
                \$(\"#choix{{perso.id}}\").submit();
              });
            </script>
          </a>
        </div>
      {% endfor %}
    </div>
  </body>
</html>
", "PWPoudlardBundle:Default:choixPerso.html.twig", "/home/betty/S6/PW6/projetweb/projetweb/src/PW/PoudlardBundle/Resources/views/Default/choixPerso.html.twig");
    }
}
