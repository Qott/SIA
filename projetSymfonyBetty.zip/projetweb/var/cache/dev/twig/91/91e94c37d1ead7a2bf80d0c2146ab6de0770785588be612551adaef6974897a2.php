<?php

/* PWPoudlardBundle:Default:compte.html.twig */
class __TwigTemplate_d60ea631915c95c85226656a185cccca80dd3fddf44b480d1cc31ebfb327a0af extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("menu.html.twig", "PWPoudlardBundle:Default:compte.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "menu.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b316c12a0face099a093dd278a3155345feae5991241bd47fdc54abb2950c352 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b316c12a0face099a093dd278a3155345feae5991241bd47fdc54abb2950c352->enter($__internal_b316c12a0face099a093dd278a3155345feae5991241bd47fdc54abb2950c352_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PWPoudlardBundle:Default:compte.html.twig"));

        $__internal_da2ba445c200394d57a204b3e01f628c981617df2c9c2dd51ae7ee18ac1fd4f1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_da2ba445c200394d57a204b3e01f628c981617df2c9c2dd51ae7ee18ac1fd4f1->enter($__internal_da2ba445c200394d57a204b3e01f628c981617df2c9c2dd51ae7ee18ac1fd4f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PWPoudlardBundle:Default:compte.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b316c12a0face099a093dd278a3155345feae5991241bd47fdc54abb2950c352->leave($__internal_b316c12a0face099a093dd278a3155345feae5991241bd47fdc54abb2950c352_prof);

        
        $__internal_da2ba445c200394d57a204b3e01f628c981617df2c9c2dd51ae7ee18ac1fd4f1->leave($__internal_da2ba445c200394d57a204b3e01f628c981617df2c9c2dd51ae7ee18ac1fd4f1_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_a90a3de0167ccb98e2d49105cd51ddbde8b8b86c76ae40e7b208eff105916852 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a90a3de0167ccb98e2d49105cd51ddbde8b8b86c76ae40e7b208eff105916852->enter($__internal_a90a3de0167ccb98e2d49105cd51ddbde8b8b86c76ae40e7b208eff105916852_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_161b57657e7a3c7db7c42a2225c807cb109f28e181893f065e780ba387537a7b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_161b57657e7a3c7db7c42a2225c807cb109f28e181893f065e780ba387537a7b->enter($__internal_161b57657e7a3c7db7c42a2225c807cb109f28e181893f065e780ba387537a7b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "username", array()), "html", null, true);
        
        $__internal_161b57657e7a3c7db7c42a2225c807cb109f28e181893f065e780ba387537a7b->leave($__internal_161b57657e7a3c7db7c42a2225c807cb109f28e181893f065e780ba387537a7b_prof);

        
        $__internal_a90a3de0167ccb98e2d49105cd51ddbde8b8b86c76ae40e7b208eff105916852->leave($__internal_a90a3de0167ccb98e2d49105cd51ddbde8b8b86c76ae40e7b208eff105916852_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_02de5d24cea4b009a7155191426f8852bcf5494f4faaab32be1aa299df4a6741 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_02de5d24cea4b009a7155191426f8852bcf5494f4faaab32be1aa299df4a6741->enter($__internal_02de5d24cea4b009a7155191426f8852bcf5494f4faaab32be1aa299df4a6741_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_e878279e16adff04f5a8d712339a4848fbfe1afbe039c1f70e6afe5ca44bc42d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e878279e16adff04f5a8d712339a4848fbfe1afbe039c1f70e6afe5ca44bc42d->enter($__internal_e878279e16adff04f5a8d712339a4848fbfe1afbe039c1f70e6afe5ca44bc42d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "  <div class=\"container-fluid\">
    <div class=\"col-sm-4 col-sm-push-4 text-center\">
      <h2>Personnage actuel</h2>
      <br>
      <p>
        ";
        // line 11
        echo twig_escape_filter($this->env, $this->getAttribute(($context["actuel"] ?? $this->getContext($context, "actuel")), "nom", array()), "html", null, true);
        echo "
        <br><br>
        <img src=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute(($context["actuel"] ?? $this->getContext($context, "actuel")), "image", array()), "html", null, true);
        echo "\" alt=\"Photo du personnage\" id=\"photo_perso\"/>
      </p>
    </div>
    <div class=\"col-sm-4 col-sm-push-4 text-center\">
      <img src=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "avatar", array()), "html", null, true);
        echo "\" alt=\"Avatar de ";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "username", array()), "html", null, true);
        echo "\" id=\"photo_perso\"/>
      <br><br>
      <a href=\"";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pw_poudlard_changerAvatar");
        echo "\">
        <button type=\"button\">Changer d'avatar</button>
      </a>
    </div>
  </div>
  <a href=\"";
        // line 24
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pw_poudlard_changerPerso");
        echo "\">
    <button type=\"button\" id=\"changer_perso\">Changer de personnage</button>
  </a>
";
        
        $__internal_e878279e16adff04f5a8d712339a4848fbfe1afbe039c1f70e6afe5ca44bc42d->leave($__internal_e878279e16adff04f5a8d712339a4848fbfe1afbe039c1f70e6afe5ca44bc42d_prof);

        
        $__internal_02de5d24cea4b009a7155191426f8852bcf5494f4faaab32be1aa299df4a6741->leave($__internal_02de5d24cea4b009a7155191426f8852bcf5494f4faaab32be1aa299df4a6741_prof);

    }

    public function getTemplateName()
    {
        return "PWPoudlardBundle:Default:compte.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  102 => 24,  94 => 19,  87 => 17,  80 => 13,  75 => 11,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"menu.html.twig\" %}

{% block title %}{{ app.user.username }}{% endblock %}

{% block body %}
  <div class=\"container-fluid\">
    <div class=\"col-sm-4 col-sm-push-4 text-center\">
      <h2>Personnage actuel</h2>
      <br>
      <p>
        {{actuel.nom}}
        <br><br>
        <img src=\"{{ actuel.image}}\" alt=\"Photo du personnage\" id=\"photo_perso\"/>
      </p>
    </div>
    <div class=\"col-sm-4 col-sm-push-4 text-center\">
      <img src=\"{{ app.user.avatar }}\" alt=\"Avatar de {{ app.user.username }}\" id=\"photo_perso\"/>
      <br><br>
      <a href=\"{{ path(\"pw_poudlard_changerAvatar\") }}\">
        <button type=\"button\">Changer d'avatar</button>
      </a>
    </div>
  </div>
  <a href=\"{{ path(\"pw_poudlard_changerPerso\") }}\">
    <button type=\"button\" id=\"changer_perso\">Changer de personnage</button>
  </a>
{% endblock %}
", "PWPoudlardBundle:Default:compte.html.twig", "/home/betty/S6/PW6/projetweb/projetweb/src/PW/PoudlardBundle/Resources/views/Default/compte.html.twig");
    }
}
