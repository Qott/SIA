<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_4474f74cada0a5e75a6dd5b3cdda12cf897c90f75a32f1281201f0c9fa22ecb9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ed184925e605c339e7b7fdc93754a2b41de874a87a8f60cfd8737d50dc42ae41 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ed184925e605c339e7b7fdc93754a2b41de874a87a8f60cfd8737d50dc42ae41->enter($__internal_ed184925e605c339e7b7fdc93754a2b41de874a87a8f60cfd8737d50dc42ae41_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        $__internal_177f19b62eaaf3c97e5fe5d01d42fb27b3a67f868a84494280da84fe023afc19 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_177f19b62eaaf3c97e5fe5d01d42fb27b3a67f868a84494280da84fe023afc19->enter($__internal_177f19b62eaaf3c97e5fe5d01d42fb27b3a67f868a84494280da84fe023afc19_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_ed184925e605c339e7b7fdc93754a2b41de874a87a8f60cfd8737d50dc42ae41->leave($__internal_ed184925e605c339e7b7fdc93754a2b41de874a87a8f60cfd8737d50dc42ae41_prof);

        
        $__internal_177f19b62eaaf3c97e5fe5d01d42fb27b3a67f868a84494280da84fe023afc19->leave($__internal_177f19b62eaaf3c97e5fe5d01d42fb27b3a67f868a84494280da84fe023afc19_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/button_row.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/FormTable/button_row.html.php");
    }
}
