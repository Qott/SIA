<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_9b7e91467a98ec3bfd0c0a15bf5a691f95618817514bacd939803090eeb923df extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9f6c3c704f56506393a0ffeaf6a3288147f233abca70da58e8e0f878c7e7113f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9f6c3c704f56506393a0ffeaf6a3288147f233abca70da58e8e0f878c7e7113f->enter($__internal_9f6c3c704f56506393a0ffeaf6a3288147f233abca70da58e8e0f878c7e7113f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        $__internal_a199160070f654abe8ab41c9d45649038037c85657ea8c5afb108ffdb3ae3b1a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a199160070f654abe8ab41c9d45649038037c85657ea8c5afb108ffdb3ae3b1a->enter($__internal_a199160070f654abe8ab41c9d45649038037c85657ea8c5afb108ffdb3ae3b1a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_9f6c3c704f56506393a0ffeaf6a3288147f233abca70da58e8e0f878c7e7113f->leave($__internal_9f6c3c704f56506393a0ffeaf6a3288147f233abca70da58e8e0f878c7e7113f_prof);

        
        $__internal_a199160070f654abe8ab41c9d45649038037c85657ea8c5afb108ffdb3ae3b1a->leave($__internal_a199160070f654abe8ab41c9d45649038037c85657ea8c5afb108ffdb3ae3b1a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/button_row.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_row.html.php");
    }
}
