<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_ff91a568cd45297ad6ddeca97ebca6d3330951cbc4769f18119be76f4df36f5c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f49252ada0b727375115e7a8ef63f9e0f72f2c9aa222f7cbca9ce1773760bf3e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f49252ada0b727375115e7a8ef63f9e0f72f2c9aa222f7cbca9ce1773760bf3e->enter($__internal_f49252ada0b727375115e7a8ef63f9e0f72f2c9aa222f7cbca9ce1773760bf3e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        $__internal_7d08eaaebe3655991355d31a4d6bc0e862fdf5b7c9020e821416fbcac7da3698 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7d08eaaebe3655991355d31a4d6bc0e862fdf5b7c9020e821416fbcac7da3698->enter($__internal_7d08eaaebe3655991355d31a4d6bc0e862fdf5b7c9020e821416fbcac7da3698_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_f49252ada0b727375115e7a8ef63f9e0f72f2c9aa222f7cbca9ce1773760bf3e->leave($__internal_f49252ada0b727375115e7a8ef63f9e0f72f2c9aa222f7cbca9ce1773760bf3e_prof);

        
        $__internal_7d08eaaebe3655991355d31a4d6bc0e862fdf5b7c9020e821416fbcac7da3698->leave($__internal_7d08eaaebe3655991355d31a4d6bc0e862fdf5b7c9020e821416fbcac7da3698_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
", "@Framework/Form/textarea_widget.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/textarea_widget.html.php");
    }
}
