<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_8cffbb1fe8b1699a05e879eb7aef88e3bd574f3762956b7656e4af077bb583d3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_65ff8ae0609d3dff30c16c8bfad3938991d76196cc9fbead3ca9c88ae80cec3b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_65ff8ae0609d3dff30c16c8bfad3938991d76196cc9fbead3ca9c88ae80cec3b->enter($__internal_65ff8ae0609d3dff30c16c8bfad3938991d76196cc9fbead3ca9c88ae80cec3b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        $__internal_d846cecd9e5d37a3b4d178b3db963be606d2d1d66599a05302c68836d5a1b4e5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d846cecd9e5d37a3b4d178b3db963be606d2d1d66599a05302c68836d5a1b4e5->enter($__internal_d846cecd9e5d37a3b4d178b3db963be606d2d1d66599a05302c68836d5a1b4e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_65ff8ae0609d3dff30c16c8bfad3938991d76196cc9fbead3ca9c88ae80cec3b->leave($__internal_65ff8ae0609d3dff30c16c8bfad3938991d76196cc9fbead3ca9c88ae80cec3b_prof);

        
        $__internal_d846cecd9e5d37a3b4d178b3db963be606d2d1d66599a05302c68836d5a1b4e5->leave($__internal_d846cecd9e5d37a3b4d178b3db963be606d2d1d66599a05302c68836d5a1b4e5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
", "@Framework/Form/form_errors.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_errors.html.php");
    }
}
