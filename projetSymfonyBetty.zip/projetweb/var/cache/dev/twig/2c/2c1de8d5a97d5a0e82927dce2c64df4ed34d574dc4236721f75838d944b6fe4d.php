<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_8bbc625140afc72c8b19f38f0f24da0557ba3863bbb77bb63a619b97bc881b85 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1a4d12a304cb67b68877dd42f9194b46922f1f6ded2eeab06e1488c2b37c3af8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1a4d12a304cb67b68877dd42f9194b46922f1f6ded2eeab06e1488c2b37c3af8->enter($__internal_1a4d12a304cb67b68877dd42f9194b46922f1f6ded2eeab06e1488c2b37c3af8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        $__internal_46fa2a7292d365179188483ee86485ac97e60c2b55e7cc528c2977f3d16c19a5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_46fa2a7292d365179188483ee86485ac97e60c2b55e7cc528c2977f3d16c19a5->enter($__internal_46fa2a7292d365179188483ee86485ac97e60c2b55e7cc528c2977f3d16c19a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_1a4d12a304cb67b68877dd42f9194b46922f1f6ded2eeab06e1488c2b37c3af8->leave($__internal_1a4d12a304cb67b68877dd42f9194b46922f1f6ded2eeab06e1488c2b37c3af8_prof);

        
        $__internal_46fa2a7292d365179188483ee86485ac97e60c2b55e7cc528c2977f3d16c19a5->leave($__internal_46fa2a7292d365179188483ee86485ac97e60c2b55e7cc528c2977f3d16c19a5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
", "@Framework/Form/form_widget.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_widget.html.php");
    }
}
