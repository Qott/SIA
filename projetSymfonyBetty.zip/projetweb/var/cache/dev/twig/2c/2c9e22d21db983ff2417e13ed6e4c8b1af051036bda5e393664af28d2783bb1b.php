<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_ed598f64c3eaa249ab8e1cd012263774744fd2aae7a0bb9f4357007b645c5fd8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e282e53998ca3beb3ea34871d138ca0144c09090fec1df455301499e7fdb5727 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e282e53998ca3beb3ea34871d138ca0144c09090fec1df455301499e7fdb5727->enter($__internal_e282e53998ca3beb3ea34871d138ca0144c09090fec1df455301499e7fdb5727_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        $__internal_0b9256797e5cdf46fa545a9ebd93028506c0871a18e202840e6f9d4a025a1ea3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0b9256797e5cdf46fa545a9ebd93028506c0871a18e202840e6f9d4a025a1ea3->enter($__internal_0b9256797e5cdf46fa545a9ebd93028506c0871a18e202840e6f9d4a025a1ea3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_e282e53998ca3beb3ea34871d138ca0144c09090fec1df455301499e7fdb5727->leave($__internal_e282e53998ca3beb3ea34871d138ca0144c09090fec1df455301499e7fdb5727_prof);

        
        $__internal_0b9256797e5cdf46fa545a9ebd93028506c0871a18e202840e6f9d4a025a1ea3->leave($__internal_0b9256797e5cdf46fa545a9ebd93028506c0871a18e202840e6f9d4a025a1ea3_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "TwigBundle:Exception:error.rdf.twig", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.rdf.twig");
    }
}
