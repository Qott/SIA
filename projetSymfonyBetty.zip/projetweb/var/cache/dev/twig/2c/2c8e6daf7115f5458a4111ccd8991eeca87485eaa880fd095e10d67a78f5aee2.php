<?php

/* TwigBundle:Exception:error.css.twig */
class __TwigTemplate_73735ef2de69645ebcdeac65c950fbb0f088f50adae5df3c40ef4d9100a786c6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3871eeea1ad209e3ea64cef93c622cda76a68d327679d70e86d8f657c4c1fe7a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3871eeea1ad209e3ea64cef93c622cda76a68d327679d70e86d8f657c4c1fe7a->enter($__internal_3871eeea1ad209e3ea64cef93c622cda76a68d327679d70e86d8f657c4c1fe7a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        $__internal_7369432268e69389d8045ed76bb961ad3888d2642bfea2bc8d6b349424afbda8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7369432268e69389d8045ed76bb961ad3888d2642bfea2bc8d6b349424afbda8->enter($__internal_7369432268e69389d8045ed76bb961ad3888d2642bfea2bc8d6b349424afbda8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_3871eeea1ad209e3ea64cef93c622cda76a68d327679d70e86d8f657c4c1fe7a->leave($__internal_3871eeea1ad209e3ea64cef93c622cda76a68d327679d70e86d8f657c4c1fe7a_prof);

        
        $__internal_7369432268e69389d8045ed76bb961ad3888d2642bfea2bc8d6b349424afbda8->leave($__internal_7369432268e69389d8045ed76bb961ad3888d2642bfea2bc8d6b349424afbda8_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "TwigBundle:Exception:error.css.twig", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.css.twig");
    }
}
