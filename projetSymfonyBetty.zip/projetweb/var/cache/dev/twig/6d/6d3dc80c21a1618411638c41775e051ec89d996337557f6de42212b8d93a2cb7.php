<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_613178b24aef7e1dee0e3cd93f8393d1524d06bae56091fd1630ad3aeb8204b3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cc6976b1696047bd46c79fcdf153cb62ddab6744cba03bd2cb9d071f645efe7b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cc6976b1696047bd46c79fcdf153cb62ddab6744cba03bd2cb9d071f645efe7b->enter($__internal_cc6976b1696047bd46c79fcdf153cb62ddab6744cba03bd2cb9d071f645efe7b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        $__internal_43aff828f84c3a42f65158d469663329ca64710b860c0065d33dc7802885972e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_43aff828f84c3a42f65158d469663329ca64710b860c0065d33dc7802885972e->enter($__internal_43aff828f84c3a42f65158d469663329ca64710b860c0065d33dc7802885972e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.rdf.twig", 1)->display(array_merge($context, array("exception" => ($context["exception"] ?? $this->getContext($context, "exception")))));
        
        $__internal_cc6976b1696047bd46c79fcdf153cb62ddab6744cba03bd2cb9d071f645efe7b->leave($__internal_cc6976b1696047bd46c79fcdf153cb62ddab6744cba03bd2cb9d071f645efe7b_prof);

        
        $__internal_43aff828f84c3a42f65158d469663329ca64710b860c0065d33dc7802885972e->leave($__internal_43aff828f84c3a42f65158d469663329ca64710b860c0065d33dc7802885972e_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}
", "TwigBundle:Exception:exception.rdf.twig", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.rdf.twig");
    }
}
