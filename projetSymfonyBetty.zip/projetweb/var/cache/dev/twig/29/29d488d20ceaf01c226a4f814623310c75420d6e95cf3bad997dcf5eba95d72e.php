<?php

/* @Framework/Form/form_rows.html.php */
class __TwigTemplate_76bf0ac26a99047ff29b3263e88c04869e0cc34ac959f274dce6eaae3620a324 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ccb0d9351e9ef4379a2cca343d3b4b9ed3b34d3477a2e2770f11355fb5353f12 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ccb0d9351e9ef4379a2cca343d3b4b9ed3b34d3477a2e2770f11355fb5353f12->enter($__internal_ccb0d9351e9ef4379a2cca343d3b4b9ed3b34d3477a2e2770f11355fb5353f12_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        $__internal_6d8ddaf6a5dc707ee62d00fe2f0d263c3bc55c6e7ef4b729050a3c890983c813 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6d8ddaf6a5dc707ee62d00fe2f0d263c3bc55c6e7ef4b729050a3c890983c813->enter($__internal_6d8ddaf6a5dc707ee62d00fe2f0d263c3bc55c6e7ef4b729050a3c890983c813_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
";
        
        $__internal_ccb0d9351e9ef4379a2cca343d3b4b9ed3b34d3477a2e2770f11355fb5353f12->leave($__internal_ccb0d9351e9ef4379a2cca343d3b4b9ed3b34d3477a2e2770f11355fb5353f12_prof);

        
        $__internal_6d8ddaf6a5dc707ee62d00fe2f0d263c3bc55c6e7ef4b729050a3c890983c813->leave($__internal_6d8ddaf6a5dc707ee62d00fe2f0d263c3bc55c6e7ef4b729050a3c890983c813_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rows.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
", "@Framework/Form/form_rows.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_rows.html.php");
    }
}
