<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_8379bf755200ba199f8eb9a135bc2640ad66bbe1df70a5c176ed8cec89bf1992 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4d6aa72b06998236ee766265c466493bb07b1218e0f4271fc363ccb802de9933 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4d6aa72b06998236ee766265c466493bb07b1218e0f4271fc363ccb802de9933->enter($__internal_4d6aa72b06998236ee766265c466493bb07b1218e0f4271fc363ccb802de9933_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        $__internal_a79e675a89f70c370db6dbcdd7bede00e4911c6ccbf449ce416d2acd72e4bdcd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a79e675a89f70c370db6dbcdd7bede00e4911c6ccbf449ce416d2acd72e4bdcd->enter($__internal_a79e675a89f70c370db6dbcdd7bede00e4911c6ccbf449ce416d2acd72e4bdcd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_4d6aa72b06998236ee766265c466493bb07b1218e0f4271fc363ccb802de9933->leave($__internal_4d6aa72b06998236ee766265c466493bb07b1218e0f4271fc363ccb802de9933_prof);

        
        $__internal_a79e675a89f70c370db6dbcdd7bede00e4911c6ccbf449ce416d2acd72e4bdcd->leave($__internal_a79e675a89f70c370db6dbcdd7bede00e4911c6ccbf449ce416d2acd72e4bdcd_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
", "@Framework/Form/choice_widget_expanded.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_widget_expanded.html.php");
    }
}
