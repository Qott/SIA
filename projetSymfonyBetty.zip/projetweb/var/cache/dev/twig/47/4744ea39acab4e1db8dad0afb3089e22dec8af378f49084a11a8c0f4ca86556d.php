<?php

/* PWPoudlardBundle:Default:connexion.html.twig */
class __TwigTemplate_2674e1e1974b863bbb7bcc6dc55ba78a1761e89ab6a8b89097fbfec80a48a25f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_13fa4aba995ff72f160f88bba21a7c226ec60f9fcd5dd25f2a2a5b5bb4802337 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_13fa4aba995ff72f160f88bba21a7c226ec60f9fcd5dd25f2a2a5b5bb4802337->enter($__internal_13fa4aba995ff72f160f88bba21a7c226ec60f9fcd5dd25f2a2a5b5bb4802337_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PWPoudlardBundle:Default:connexion.html.twig"));

        $__internal_6fba9e02d2e6584059bca8b08a6d3ad9fdf0bb86db1a47c8b734289914dbb100 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6fba9e02d2e6584059bca8b08a6d3ad9fdf0bb86db1a47c8b734289914dbb100->enter($__internal_6fba9e02d2e6584059bca8b08a6d3ad9fdf0bb86db1a47c8b734289914dbb100_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PWPoudlardBundle:Default:connexion.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
  <head>
    <meta charset=\"utf-8\">
    <script src=\"http://code.jquery.com/jquery-1.11.3.js\"></script>
    <link rel=\"stylesheet\"
      href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\"
      integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\"
      crossorigin=\"anonymous\">
    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>
    <link rel=\"stylesheet\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\"/>
    <title>Poudlard Academy</title>
  </head>
  <body>
    <div class=\"container-fluid\">
      <h1 class=\"text-center\">Poudlard Academy</h1>
      <br><br><br><br>
      ";
        // line 19
        echo "      ";
        if (($context["error"] ?? $this->getContext($context, "error"))) {
            // line 20
            echo "        <div class=\"alert alert-danger\">";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["error"] ?? $this->getContext($context, "error")), "message", array()), "html", null, true);
            echo "</div>
      ";
        }
        // line 22
        echo "
      ";
        // line 24
        echo "      <form class=\"well col-sm-4 col-sm-push-1\" action=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("login_check");
        echo "\" method=\"post\">
        <h2 class=\"text-center\">Connexion</h2>
        <label for=\"username\">Login :</label>
        <input type=\"text\" id=\"username\" name=\"_username\" value=\"";
        // line 27
        echo twig_escape_filter($this->env, ($context["last_username"] ?? $this->getContext($context, "last_username")), "html", null, true);
        echo "\" />
        <br>
        <label for=\"password\">Mot de passe :</label>
        <input type=\"password\" id=\"password\" name=\"_password\" />
        <br />
        <input type=\"submit\" value=\"Connexion\" />
      </form>
      <div class=\"well col-sm-5 col-sm-push-2\">
        <h2 class=\"text-center\">Inscription</h2>

        ";
        // line 37
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["formI"] ?? $this->getContext($context, "formI")), 'form_start');
        echo "
          ";
        // line 38
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["formI"] ?? $this->getContext($context, "formI")), "username", array()), 'row', array("label" => "Pseudo"));
        echo "
          ";
        // line 39
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["formI"] ?? $this->getContext($context, "formI")), "mail", array()), 'row', array("label" => "Mail"));
        echo "
          ";
        // line 40
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["formI"] ?? $this->getContext($context, "formI")), "password", array()), 'row', array("label" => "Mot de passe"));
        echo "
        ";
        // line 41
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["formI"] ?? $this->getContext($context, "formI")), 'form_end');
        echo "
      </div>
    </div>
  </body>
</html>
";
        
        $__internal_13fa4aba995ff72f160f88bba21a7c226ec60f9fcd5dd25f2a2a5b5bb4802337->leave($__internal_13fa4aba995ff72f160f88bba21a7c226ec60f9fcd5dd25f2a2a5b5bb4802337_prof);

        
        $__internal_6fba9e02d2e6584059bca8b08a6d3ad9fdf0bb86db1a47c8b734289914dbb100->leave($__internal_6fba9e02d2e6584059bca8b08a6d3ad9fdf0bb86db1a47c8b734289914dbb100_prof);

    }

    public function getTemplateName()
    {
        return "PWPoudlardBundle:Default:connexion.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  95 => 41,  91 => 40,  87 => 39,  83 => 38,  79 => 37,  66 => 27,  59 => 24,  56 => 22,  50 => 20,  47 => 19,  37 => 11,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
  <head>
    <meta charset=\"utf-8\">
    <script src=\"http://code.jquery.com/jquery-1.11.3.js\"></script>
    <link rel=\"stylesheet\"
      href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\"
      integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\"
      crossorigin=\"anonymous\">
    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>
    <link rel=\"stylesheet\" href=\"{{ asset(\"css/style.css\") }}\"/>
    <title>Poudlard Academy</title>
  </head>
  <body>
    <div class=\"container-fluid\">
      <h1 class=\"text-center\">Poudlard Academy</h1>
      <br><br><br><br>
      {# S'il y a une erreur, on l'affiche dans un joli cadre #}
      {% if error %}
        <div class=\"alert alert-danger\">{{ error.message }}</div>
      {% endif %}

      {# Le formulaire, avec URL de soumission vers la route « login_check » comme on l'a vu #}
      <form class=\"well col-sm-4 col-sm-push-1\" action=\"{{ path('login_check') }}\" method=\"post\">
        <h2 class=\"text-center\">Connexion</h2>
        <label for=\"username\">Login :</label>
        <input type=\"text\" id=\"username\" name=\"_username\" value=\"{{ last_username }}\" />
        <br>
        <label for=\"password\">Mot de passe :</label>
        <input type=\"password\" id=\"password\" name=\"_password\" />
        <br />
        <input type=\"submit\" value=\"Connexion\" />
      </form>
      <div class=\"well col-sm-5 col-sm-push-2\">
        <h2 class=\"text-center\">Inscription</h2>

        {{ form_start(formI) }}
          {{ form_row(formI.username, { 'label' : 'Pseudo'}) }}
          {{ form_row(formI.mail, { 'label' : 'Mail'}) }}
          {{ form_row(formI.password, { 'label' : 'Mot de passe'}) }}
        {{ form_end(formI) }}
      </div>
    </div>
  </body>
</html>
", "PWPoudlardBundle:Default:connexion.html.twig", "/home/betty/S6/PW6/projetweb/projetweb/src/PW/PoudlardBundle/Resources/views/Default/connexion.html.twig");
    }
}
