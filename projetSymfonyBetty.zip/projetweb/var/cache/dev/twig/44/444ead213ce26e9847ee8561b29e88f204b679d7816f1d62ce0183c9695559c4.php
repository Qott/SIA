<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_b899594e1a4af6ec732f205dc84f98eb52b7baa8fd2d88f5bc1115b4936d23ad extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_54ef8298232fd0bfc92453f91ab769acb4c69d58db71440b1088a15c11f91ac8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_54ef8298232fd0bfc92453f91ab769acb4c69d58db71440b1088a15c11f91ac8->enter($__internal_54ef8298232fd0bfc92453f91ab769acb4c69d58db71440b1088a15c11f91ac8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        $__internal_9f1b4764a5297c855994001872541606d5864bf64dbcfa28e5c8646f07bb9c93 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9f1b4764a5297c855994001872541606d5864bf64dbcfa28e5c8646f07bb9c93->enter($__internal_9f1b4764a5297c855994001872541606d5864bf64dbcfa28e5c8646f07bb9c93_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_54ef8298232fd0bfc92453f91ab769acb4c69d58db71440b1088a15c11f91ac8->leave($__internal_54ef8298232fd0bfc92453f91ab769acb4c69d58db71440b1088a15c11f91ac8_prof);

        
        $__internal_9f1b4764a5297c855994001872541606d5864bf64dbcfa28e5c8646f07bb9c93->leave($__internal_9f1b4764a5297c855994001872541606d5864bf64dbcfa28e5c8646f07bb9c93_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/hidden_row.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/FormTable/hidden_row.html.php");
    }
}
