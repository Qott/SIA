<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_3f95cc52884f1e1fc3f59cf29d804ae00326e9c7855e29cd2cb9bf7f2b0bd4ed extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7115441c8c5f42e9b12eeee1e17a7b382a0d89660a75ac0cda4326f90ac13a66 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7115441c8c5f42e9b12eeee1e17a7b382a0d89660a75ac0cda4326f90ac13a66->enter($__internal_7115441c8c5f42e9b12eeee1e17a7b382a0d89660a75ac0cda4326f90ac13a66_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        $__internal_a81cc90f16d9e47c608ac8c3270a53f01388c7fb6d70f983f0d1d57bc94b793f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a81cc90f16d9e47c608ac8c3270a53f01388c7fb6d70f983f0d1d57bc94b793f->enter($__internal_a81cc90f16d9e47c608ac8c3270a53f01388c7fb6d70f983f0d1d57bc94b793f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_7115441c8c5f42e9b12eeee1e17a7b382a0d89660a75ac0cda4326f90ac13a66->leave($__internal_7115441c8c5f42e9b12eeee1e17a7b382a0d89660a75ac0cda4326f90ac13a66_prof);

        
        $__internal_a81cc90f16d9e47c608ac8c3270a53f01388c7fb6d70f983f0d1d57bc94b793f->leave($__internal_a81cc90f16d9e47c608ac8c3270a53f01388c7fb6d70f983f0d1d57bc94b793f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
", "@Framework/Form/password_widget.html.php", "/home/betty/S6/PW6/projetweb/projetweb/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/password_widget.html.php");
    }
}
