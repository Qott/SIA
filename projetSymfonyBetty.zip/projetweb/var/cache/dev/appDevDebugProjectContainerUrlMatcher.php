<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appDevDebugProjectContainerUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_wdt')), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if (rtrim($pathinfo, '/') === '/_profiler') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_profiler_home');
                    }

                    return array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                }

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ($pathinfo === '/_profiler/search') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ($pathinfo === '/_profiler/search_bar') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_info
                if (0 === strpos($pathinfo, '/_profiler/info') && preg_match('#^/_profiler/info/(?P<about>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_info')), array (  '_controller' => 'web_profiler.controller.profiler:infoAction',));
                }

                // _profiler_phpinfo
                if ($pathinfo === '/_profiler/phpinfo') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_search_results')), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler_open_file
                if ($pathinfo === '/_profiler/open') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:openAction',  '_route' => '_profiler_open_file',);
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler')), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_router')), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception')), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception_css')), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_twig_error_test')), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        // pw_poudlard_connexion
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'pw_poudlard_connexion');
            }

            return array (  '_controller' => 'PW\\PoudlardBundle\\Controller\\DefaultController::connexionAction',  '_route' => 'pw_poudlard_connexion',);
        }

        // pw_poudlard_accueil
        if ($pathinfo === '/accueil') {
            return array (  '_controller' => 'PW\\PoudlardBundle\\Controller\\DefaultController::accueilAction',  '_route' => 'pw_poudlard_accueil',);
        }

        // pw_poudlard_boutique
        if ($pathinfo === '/boutique') {
            return array (  '_controller' => 'PW\\PoudlardBundle\\Controller\\DefaultController::boutiqueAction',  '_route' => 'pw_poudlard_boutique',);
        }

        // pw_poudlard_service
        if ($pathinfo === '/service') {
            return array (  '_controller' => 'PW\\PoudlardBundle\\Controller\\DefaultController::serviceAction',  '_route' => 'pw_poudlard_service',);
        }

        // pw_poudlard_promener
        if ($pathinfo === '/promener') {
            return array (  '_controller' => 'PW\\PoudlardBundle\\Controller\\DefaultController::promenerAction',  '_route' => 'pw_poudlard_promener',);
        }

        if (0 === strpos($pathinfo, '/c')) {
            // pw_poudlard_compte
            if ($pathinfo === '/compte') {
                return array (  '_controller' => 'PW\\PoudlardBundle\\Controller\\DefaultController::compteAction',  '_route' => 'pw_poudlard_compte',);
            }

            if (0 === strpos($pathinfo, '/ch')) {
                // pw_poudlard_choixPerso
                if ($pathinfo === '/choixPerso') {
                    return array (  '_controller' => 'PW\\PoudlardBundle\\Controller\\DefaultController::choixPersoAction',  '_route' => 'pw_poudlard_choixPerso',);
                }

                if (0 === strpos($pathinfo, '/changer')) {
                    // pw_poudlard_changerPerso
                    if ($pathinfo === '/changerPerso') {
                        return array (  '_controller' => 'PW\\PoudlardBundle\\Controller\\DefaultController::changerPersoAction',  '_route' => 'pw_poudlard_changerPerso',);
                    }

                    // pw_poudlard_changerAvatar
                    if ($pathinfo === '/changerAvatar') {
                        return array (  '_controller' => 'PW\\PoudlardBundle\\Controller\\DefaultController::changerAvatarAction',  '_route' => 'pw_poudlard_changerAvatar',);
                    }

                }

            }

        }

        // pw_poudlard_infosPerso
        if ($pathinfo === '/infosPerso') {
            return array (  '_controller' => 'PW\\PoudlardBundle\\Controller\\DefaultController::infosPersoAction',  '_route' => 'pw_poudlard_infosPerso',);
        }

        // pw_poudlard_affichagePerso
        if ($pathinfo === '/affichagePerso') {
            return array (  '_controller' => 'PW\\PoudlardBundle\\Controller\\DefaultController::affichagePersoAction',  '_route' => 'pw_poudlard_affichagePerso',);
        }

        // login
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'login');
            }

            return array (  '_controller' => 'PW\\PoudlardBundle\\Controller\\DefaultController::connexionAction',  '_route' => 'login',);
        }

        if (0 === strpos($pathinfo, '/log')) {
            // login_check
            if ($pathinfo === '/login_check') {
                return array('_route' => 'login_check');
            }

            // logout
            if ($pathinfo === '/logout') {
                return array('_route' => 'logout');
            }

        }

        // homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
